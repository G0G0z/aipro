/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient;

import com.aiclient.Terminal;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

public class AnthropicClient {
    private static final String DEFAULT_BASE_URL = "https://api.anthropic.com";
    private static final String API_VERSION = "2023-06-01";
    private final AtomicReference<String> activeKey;
    private final String fallbackKey;
    private final AtomicBoolean usingFallback = new AtomicBoolean(false);
    private final String baseUrl;
    private final HttpClient httpClient;
    private final Gson gson;
    private static final String DEFAULT_AEROLINK_URL = "https://capi.aerolink.lat";

    public AnthropicClient(String apiKey, String baseUrl) {
        this(apiKey, baseUrl, null);
    }

    public AnthropicClient(String apiKey, String baseUrl, String fallbackKey) {
        this.activeKey = new AtomicReference<String>(apiKey);
        this.fallbackKey = fallbackKey != null && !fallbackKey.isBlank() ? fallbackKey : null;
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        this.httpClient = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(30L)).build();
        this.gson = new GsonBuilder().create();
    }

    public boolean isUsingFallback() {
        return this.usingFallback.get();
    }

    private boolean switchToFallback() {
        if (this.fallbackKey == null) {
            return false;
        }
        if (this.usingFallback.compareAndSet(false, true)) {
            this.activeKey.set(this.fallbackKey);
            return true;
        }
        return false;
    }

    private static boolean isRateLimitMessage(String msg) {
        String lower = msg.toLowerCase();
        return lower.contains("rate") || lower.contains("limit") || lower.contains("quota") || lower.contains("overloaded") || lower.contains("capacity");
    }

    public static AnthropicClient fromEnvironment() {
        String customBase;
        String apiKey = System.getenv("AEROLINK_API_KEY");
        String baseUrl = DEFAULT_AEROLINK_URL;
        String anthropicKey = System.getenv("ANTHROPIC_API_KEY");
        if (anthropicKey != null && !anthropicKey.isBlank()) {
            apiKey = anthropicKey;
            baseUrl = DEFAULT_BASE_URL;
        }
        if ((customBase = System.getenv("ANTHROPIC_BASE_URL")) != null && !customBase.isBlank()) {
            baseUrl = customBase;
        }
        if (apiKey == null || apiKey.isBlank()) {
            Terminal.printError("API anahtar\u0131 bulunamad\u0131. AEROLINK_API_KEY veya ANTHROPIC_API_KEY ayarlay\u0131n.");
            System.exit(1);
        }
        return new AnthropicClient(apiKey, baseUrl);
    }

    public String getBaseUrl() {
        return this.baseUrl;
    }

    public ApiResponse sendMessages(String model, String systemPrompt, List<JsonObject> messages, JsonArray tools, int maxTokens) throws Exception {
        JsonObject requestBody = new JsonObject();
        requestBody.addProperty("model", model);
        requestBody.addProperty("max_tokens", maxTokens);
        if (systemPrompt != null && !systemPrompt.isBlank()) {
            requestBody.addProperty("system", systemPrompt);
        }
        if (tools != null && tools.size() > 0) {
            requestBody.add("tools", tools);
        }
        JsonArray messagesArray = new JsonArray();
        for (JsonObject msg : messages) {
            messagesArray.add(msg);
        }
        requestBody.add("messages", messagesArray);
        String requestJson = this.gson.toJson(requestBody);
        String endpoint = this.baseUrl + "/v1/messages";
        String currentKey = this.activeKey.get();
        HttpRequest.Builder reqBuilder = HttpRequest.newBuilder().uri(URI.create(endpoint)).header("Content-Type", "application/json").header("anthropic-version", API_VERSION).POST(HttpRequest.BodyPublishers.ofString(requestJson)).timeout(Duration.ofSeconds(120L));
        reqBuilder.header("x-api-key", currentKey);
        if (!this.baseUrl.contains("aerolink.lat")) {
            reqBuilder.header("Authorization", "Bearer " + currentKey);
        }
        HttpRequest request = reqBuilder.build();
        HttpResponse<String> response = this.httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        String responseBody = response.body();
        if ((response.statusCode() == 429 || response.statusCode() == 529) && this.switchToFallback()) {
            return this.sendMessages(model, systemPrompt, messages, tools, maxTokens);
        }
        if (response.statusCode() != 200) {
            try {
                String errorMsg;
                JsonObject errorObj = JsonParser.parseString(responseBody).getAsJsonObject();
                if (!errorObj.has("error")) {
                    errorMsg = responseBody;
                } else if (errorObj.get("error").isJsonObject()) {
                    JsonObject errDetail = errorObj.getAsJsonObject("error");
                    errorMsg = errDetail.has("message") ? errDetail.get("message").getAsString() : errDetail.toString();
                } else {
                    errorMsg = errorObj.get("error").getAsString();
                }
                if (AnthropicClient.isRateLimitMessage(errorMsg) && this.switchToFallback()) {
                    return this.sendMessages(model, systemPrompt, messages, tools, maxTokens);
                }
                throw new RuntimeException("API Hatas\u0131 [" + response.statusCode() + "]: " + errorMsg);
            }
            catch (JsonSyntaxException e) {
                if (AnthropicClient.isRateLimitMessage(responseBody) && this.switchToFallback()) {
                    return this.sendMessages(model, systemPrompt, messages, tools, maxTokens);
                }
                throw new RuntimeException("API Hatas\u0131 [" + response.statusCode() + "]: " + responseBody);
            }
        }
        JsonObject responseJson = JsonParser.parseString(responseBody).getAsJsonObject();
        JsonArray content = responseJson.getAsJsonArray("content");
        String stopReason = responseJson.get("stop_reason").getAsString();
        TokenUsage usage = new TokenUsage(0, 0);
        if (responseJson.has("usage")) {
            JsonObject usageObj = responseJson.getAsJsonObject("usage");
            int inputTokens = usageObj.has("input_tokens") ? usageObj.get("input_tokens").getAsInt() : 0;
            int outputTokens = usageObj.has("output_tokens") ? usageObj.get("output_tokens").getAsInt() : 0;
            usage = new TokenUsage(inputTokens, outputTokens);
        }
        return new ApiResponse(content, stopReason, usage);
    }

    public record ApiResponse(JsonArray content, String stopReason, TokenUsage usage) {
    }

    public record TokenUsage(int inputTokens, int outputTokens) {
        public int total() {
            return this.inputTokens + this.outputTokens;
        }
    }
}

