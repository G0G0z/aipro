/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient;

import com.aiclient.Agent;
import com.aiclient.AnthropicClient;
import com.aiclient.Terminal;
import com.aiclient.tools.AskUserQuestionTool;
import com.aiclient.tools.ConsoleUserInteractionHandler;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        AnthropicClient client = AnthropicClient.fromEnvironment();
        Agent agent = new Agent(client);
        Terminal.printBanner();
        System.out.println("\u001b[2m  Model : " + agent.getModel() + "\u001b[0m");
        System.out.println("\u001b[2m  API   : " + client.getBaseUrl() + "\u001b[0m");
        System.out.println();
        Scanner scanner = new Scanner(System.in);
        AskUserQuestionTool.setHandler(new ConsoleUserInteractionHandler(scanner));
        while (true) {
            String input;
            Terminal.printUserPrompt();
            try {
                input = scanner.nextLine();
            }
            catch (Exception e) {
                System.out.println();
                Terminal.printInfo("Girdi ak\u0131\u015f\u0131 kapand\u0131. \u00c7\u0131k\u0131l\u0131yor...");
                break;
            }
            if (input == null) break;
            if ((input = input.trim()).isEmpty()) continue;
            String lower = input.toLowerCase();
            if ("exit".equals(lower) || "quit".equals(lower) || "\u00e7\u0131k\u0131\u015f".equals(lower)) {
                System.out.println();
                Terminal.printInfo("G\u00f6r\u00fc\u015fmek \u00fczere!");
                break;
            }
            if ("clear".equals(lower) || "cls".equals(lower)) {
                System.out.print("\u001b[H\u001b[2J");
                System.out.flush();
                Terminal.printBanner();
                continue;
            }
            if ("help".equals(lower) || "yard\u0131m".equals(lower)) {
                Terminal.printHelp();
                continue;
            }
            if ("reset".equals(lower) || "s\u0131f\u0131rla".equals(lower)) {
                agent.resetHistory();
                continue;
            }
            if ("history".equals(lower) || "ge\u00e7mi\u015f".equals(lower)) {
                agent.printHistory();
                continue;
            }
            if ("tokens".equals(lower)) {
                agent.printTokenUsage();
                continue;
            }
            if (lower.startsWith("model ")) {
                String modelName = input.substring(6).trim();
                if (!modelName.isEmpty()) {
                    agent.setModel(modelName);
                    continue;
                }
                Terminal.printError("Model ad\u0131 girin. \u00d6rnek: model claude-sonnet-4-6");
                continue;
            }
            try {
                Terminal.printAssistantHeader();
                System.out.println();
                String response = agent.chat(input);
                if (response != null && !response.isBlank()) {
                    for (String line : response.split("\n")) {
                        System.out.println("  " + line);
                    }
                }
                System.out.println();
                Terminal.printSeparator();
                agent.printTokenUsage();
                System.out.println();
            }
            catch (Exception e) {
                System.out.println();
                Terminal.printError(e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName());
                if (System.getenv("DEBUG") == null) continue;
                e.printStackTrace();
            }
        }
        scanner.close();
    }
}

