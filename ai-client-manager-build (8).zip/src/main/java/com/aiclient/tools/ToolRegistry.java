/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.ClaudeCodeBashTool;
import com.aiclient.tools.ClaudeCodeEditTool;
import com.aiclient.tools.ClaudeCodeGlobTool;
import com.aiclient.tools.ClaudeCodeGrepTool;
import com.aiclient.tools.ClaudeCodeLsTool;
import com.aiclient.tools.ClaudeCodeMultiEditTool;
import com.aiclient.tools.ClaudeCodeNotebookEditTool;
import com.aiclient.tools.ClaudeCodeNotebookReadTool;
import com.aiclient.tools.ClaudeCodeReadTool;
import com.aiclient.tools.ClaudeCodeWriteTool;
import com.aiclient.tools.ExecuteCommandTool;
import com.aiclient.tools.FileDeleteTool;
import com.aiclient.tools.FileEditTool;
import com.aiclient.tools.FileInfoTool;
import com.aiclient.tools.FileReadTool;
import com.aiclient.tools.FileWriteTool;
import com.aiclient.tools.ListDirectoryTool;
import com.aiclient.tools.MakeDirectoryTool;
import com.aiclient.tools.MoveFileTool;
import com.aiclient.tools.SearchFilesTool;
import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class ToolRegistry {
    private final Map<String, Tool> tools = new LinkedHashMap<String, Tool>();
    private final Map<String, Tool> normalizedLookup = new LinkedHashMap<String, Tool>();

    public ToolRegistry() {
        this.register(new FileReadTool());
        this.register(new FileWriteTool());
        this.register(new FileEditTool());
        this.register(new FileDeleteTool());
        this.register(new ListDirectoryTool());
        this.register(new SearchFilesTool());
        this.register(new ExecuteCommandTool());
        this.register(new MakeDirectoryTool());
        this.register(new MoveFileTool());
        this.register(new FileInfoTool());
        this.register(new ClaudeCodeBashTool());
        this.register(new ClaudeCodeReadTool());
        this.register(new ClaudeCodeWriteTool());
        this.register(new ClaudeCodeEditTool());
        this.register(new ClaudeCodeLsTool());
        this.register(new ClaudeCodeGlobTool());
        this.register(new ClaudeCodeGrepTool());
        this.register(new ClaudeCodeMultiEditTool());
        this.register(new ClaudeCodeNotebookReadTool());
        this.register(new ClaudeCodeNotebookEditTool());
        this.register(new TodoReadTool());
        this.register(new TodoWriteTool());
        this.register(new WebSearchTool());
        this.register(new WebFetchTool());
        this.register(new AskUserQuestionTool());
        this.register(new NullTool("query_registry_agentry"));
        this.register(new NullTool("worker_tree_monitorset"));
    }

    private void register(Tool tool) {
        this.tools.put(tool.getName(), tool);
        String normalized = tool.getName().toLowerCase().replaceAll("[^a-z]", "");
        this.normalizedLookup.put(normalized, tool);
    }

    public Tool get(String name) {
        if (name == null) {
            return null;
        }
        Tool exact = this.tools.get(name);
        if (exact != null) {
            return exact;
        }
        for (Map.Entry<String, Tool> e : this.tools.entrySet()) {
            if (!e.getKey().equalsIgnoreCase(name)) continue;
            return e.getValue();
        }
        String incoming = name.toLowerCase().replaceAll("[^a-z]", "");
        for (Map.Entry<String, Tool> entry : this.normalizedLookup.entrySet()) {
            if (!incoming.contains(entry.getKey()) && !entry.getKey().contains(incoming)) continue;
            return entry.getValue();
        }
        return null;
    }

    public List<Tool> getAll() {
        return new ArrayList<Tool>(this.tools.values());
    }

    public JsonArray toApiFormat() {
        JsonArray array = new JsonArray();
        for (Tool tool : this.tools.values()) {
            JsonObject obj = new JsonObject();
            obj.addProperty("name", tool.getName());
            obj.addProperty("description", tool.getDescription());
            obj.add("input_schema", tool.getInputSchema());
            array.add(obj);
        }
        return array;
    }
}

