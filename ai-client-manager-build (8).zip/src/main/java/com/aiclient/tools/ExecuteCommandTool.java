/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;

public class ExecuteCommandTool
implements Tool {
    private static final int DEFAULT_TIMEOUT = 30;
    private static final int MAX_OUTPUT_CHARS = 8000;

    @Override
    public String getName() {
        return "execute_command";
    }

    @Override
    public String getDescription() {
        return "Bir kabuk (shell) komutunu \u00e7al\u0131\u015ft\u0131r\u0131r ve \u00e7\u0131kt\u0131s\u0131n\u0131 d\u00f6nd\u00fcr\u00fcr. stdout ve stderr ayr\u0131 ayr\u0131 g\u00f6sterilir. \u00c7al\u0131\u015fma dizini belirtilebilir. Zaman a\u015f\u0131m\u0131 varsay\u0131lan 30 saniyedir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject command = new JsonObject();
        command.addProperty("type", "string");
        command.addProperty("description", "\u00c7al\u0131\u015ft\u0131r\u0131lacak kabuk komutu (bash -c ile \u00e7al\u0131\u015ft\u0131r\u0131l\u0131r)");
        props.add("command", command);
        JsonObject workingDir = new JsonObject();
        workingDir.addProperty("type", "string");
        workingDir.addProperty("description", "Komutun \u00e7al\u0131\u015ft\u0131r\u0131laca\u011f\u0131 dizin (varsay\u0131lan: mevcut dizin)");
        props.add("working_directory", workingDir);
        JsonObject timeout = new JsonObject();
        timeout.addProperty("type", "integer");
        timeout.addProperty("description", "Zaman a\u015f\u0131m\u0131 saniye olarak (varsay\u0131lan: 30, maksimum: 120)");
        props.add("timeout_seconds", timeout);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("command");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String command = input.get("command").getAsString();
        String workingDir = input.has("working_directory") && !input.get("working_directory").isJsonNull() ? input.get("working_directory").getAsString() : null;
        int timeoutSeconds = input.has("timeout_seconds") && !input.get("timeout_seconds").isJsonNull() ? Math.min(120, input.get("timeout_seconds").getAsInt()) : 30;
        String os = System.getProperty("os.name", "").toLowerCase();
        ProcessBuilder pb = os.contains("win") ? new ProcessBuilder("cmd.exe", "/c", command) : new ProcessBuilder("bash", "-c", command);
        pb.redirectErrorStream(false);
        if (workingDir != null) {
            pb.directory(Path.of(workingDir, new String[0]).toFile());
        }
        if (!os.contains("win")) {
            pb.environment().put("TERM", "xterm-256color");
        }
        long startTime = System.currentTimeMillis();
        Process process = pb.start();
        StringBuilder stdout = new StringBuilder();
        StringBuilder stderr = new StringBuilder();
        Thread stdoutThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));){
                String line;
                while ((line = reader.readLine()) != null) {
                    if (stdout.length() >= 8000) continue;
                    stdout.append(line).append("\n");
                }
            }
            catch (IOException iOException) {
                // empty catch block
            }
        });
        Thread stderrThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()));){
                String line;
                while ((line = reader.readLine()) != null) {
                    if (stderr.length() >= 8000) continue;
                    stderr.append(line).append("\n");
                }
            }
            catch (IOException iOException) {
                // empty catch block
            }
        });
        stdoutThread.start();
        stderrThread.start();
        boolean finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS);
        stdoutThread.join(1000L);
        stderrThread.join(1000L);
        long elapsed = System.currentTimeMillis() - startTime;
        StringBuilder result = new StringBuilder();
        result.append("Komut: ").append(command).append("\n");
        if (workingDir != null) {
            result.append("Dizin: ").append(workingDir).append("\n");
        }
        result.append("S\u00fcre: ").append(elapsed).append(" ms\n");
        if (!finished) {
            process.destroyForcibly();
            result.append("Durum: ZAMAN A\u015eIMI (").append(timeoutSeconds).append("s)\n");
        } else {
            int exitCode = process.exitValue();
            result.append("\u00c7\u0131k\u0131\u015f kodu: ").append(exitCode).append(exitCode == 0 ? " (ba\u015far\u0131l\u0131)" : " (hata)").append("\n");
        }
        result.append("\u2500".repeat(50)).append("\n");
        if (!stdout.isEmpty()) {
            result.append("STDOUT:\n");
            Object out = stdout.toString();
            if (((String)out).length() > 8000) {
                out = ((String)out).substring(0, 8000) + "\n... (\u00e7\u0131kt\u0131 kesildi)";
            }
            result.append((String)out);
        } else {
            result.append("STDOUT: (bo\u015f)\n");
        }
        if (!stderr.isEmpty()) {
            result.append("\nSTDERR:\n").append((CharSequence)stderr);
        }
        return result.toString();
    }
}

