/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ListDirectoryTool
implements Tool {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.systemDefault());

    @Override
    public String getName() {
        return "list_directory";
    }

    @Override
    public String getDescription() {
        return "Bir dizinin i\u00e7eri\u011fini listeler. Dosya boyutlar\u0131, t\u00fcrleri ve de\u011fi\u015ftirilme tarihleri g\u00f6sterilir. \u00d6zyinelemeli listeleme ve gizli dosyalar\u0131 g\u00f6sterme desteklenir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Listelenecek dizinin yolu (varsay\u0131lan: mevcut dizin '.')");
        props.add("path", path);
        JsonObject recursive = new JsonObject();
        recursive.addProperty("type", "boolean");
        recursive.addProperty("description", "Alt dizinleri de listele (varsay\u0131lan: false)");
        props.add("recursive", recursive);
        JsonObject showHidden = new JsonObject();
        showHidden.addProperty("type", "boolean");
        showHidden.addProperty("description", "Nokta ile ba\u015flayan gizli dosyalar\u0131 g\u00f6ster (varsay\u0131lan: false)");
        props.add("show_hidden", showHidden);
        JsonObject maxDepth = new JsonObject();
        maxDepth.addProperty("type", "integer");
        maxDepth.addProperty("description", "Maksimum derinlik (recursive=true i\u00e7in, varsay\u0131lan: 3)");
        props.add("max_depth", maxDepth);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("path");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String dirPath = input.has("path") && !input.get("path").isJsonNull() ? input.get("path").getAsString() : ".";
        boolean recursive = input.has("recursive") && !input.get("recursive").isJsonNull() && input.get("recursive").getAsBoolean();
        boolean showHidden = input.has("show_hidden") && !input.get("show_hidden").isJsonNull() && input.get("show_hidden").getAsBoolean();
        int maxDepth = input.has("max_depth") && !input.get("max_depth").isJsonNull() ? input.get("max_depth").getAsInt() : 3;
        Path path = Path.of(dirPath, new String[0]);
        if (!Files.exists(path, new LinkOption[0])) {
            return "HATA: Dizin bulunamad\u0131: " + dirPath;
        }
        if (!Files.isDirectory(path, new LinkOption[0])) {
            return "HATA: Bu bir dosya, dizin de\u011fil: " + dirPath;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Dizin: ").append(path.toAbsolutePath()).append("\n");
        sb.append("\u2500".repeat(70)).append("\n");
        sb.append(String.format("%-6s %-10s %-17s %s%n", "T\u00dcR", "BOYUT", "TAR\u0130H", "\u0130S\u0130M"));
        sb.append("\u2500".repeat(70)).append("\n");
        int[] counts = new int[]{0, 0};
        if (recursive) {
            this.listRecursive(path, path, sb, showHidden, maxDepth, 0, counts);
        } else {
            this.listFlat(path, sb, showHidden, counts);
        }
        sb.append("\u2500".repeat(70)).append("\n");
        sb.append(String.format("Toplam: %d dosya, %d klas\u00f6r", counts[0], counts[1]));
        return sb.toString();
    }

    private void listFlat(Path dir, StringBuilder sb, boolean showHidden, int[] counts) throws Exception {
        List<Path> entries;
        try (Stream<Path> stream = Files.list(dir);){
            entries = stream.filter(p -> showHidden || !p.getFileName().toString().startsWith(".")).sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase())).collect(Collectors.toList());
        }
        List<Path> dirs = entries.stream().filter(x$0 -> Files.isDirectory(x$0, new LinkOption[0])).toList();
        List<Path> files = entries.stream().filter(p -> !Files.isDirectory(p, new LinkOption[0])).toList();
        for (Path p2 : dirs) {
            this.appendEntry(p2, sb, 0);
            counts[1] = counts[1] + 1;
        }
        for (Path p2 : files) {
            this.appendEntry(p2, sb, 0);
            counts[0] = counts[0] + 1;
        }
    }

    private void listRecursive(Path base, Path dir, StringBuilder sb, boolean showHidden, int maxDepth, int depth, int[] counts) throws Exception {
        List<Path> entries;
        if (depth > maxDepth) {
            return;
        }
        try (Stream<Path> stream = Files.list(dir);){
            entries = stream.filter(p -> showHidden || !p.getFileName().toString().startsWith(".")).sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase())).collect(Collectors.toList());
        }
        List<Path> dirs = entries.stream().filter(x$0 -> Files.isDirectory(x$0, new LinkOption[0])).toList();
        List<Path> files = entries.stream().filter(p -> !Files.isDirectory(p, new LinkOption[0])).toList();
        for (Path p2 : dirs) {
            this.appendEntry(p2, sb, depth);
            counts[1] = counts[1] + 1;
            this.listRecursive(base, p2, sb, showHidden, maxDepth, depth + 1, counts);
        }
        for (Path p2 : files) {
            this.appendEntry(p2, sb, depth);
            counts[0] = counts[0] + 1;
        }
    }

    private void appendEntry(Path p, StringBuilder sb, int depth) throws Exception {
        String modified;
        boolean isDir = Files.isDirectory(p, new LinkOption[0]);
        String type = isDir ? "\ud83d\udcc1 D\u0130Z" : "\ud83d\udcc4 DOS";
        String size = isDir ? "\u2014" : this.formatSize(Files.size(p));
        try {
            BasicFileAttributes attrs = Files.readAttributes(p, BasicFileAttributes.class, new LinkOption[0]);
            modified = FMT.format(attrs.lastModifiedTime().toInstant());
        }
        catch (Exception e) {
            modified = "\u2014";
        }
        String indent = "  ".repeat(depth);
        String name = indent + p.getFileName().toString() + (isDir ? "/" : "");
        sb.append(String.format("%-6s %-10s %-17s %s%n", type, size, modified, name));
    }

    private String formatSize(long bytes) {
        if (bytes < 1024L) {
            return bytes + " B";
        }
        if (bytes < 0x100000L) {
            return String.format("%.1f KB", (double)bytes / 1024.0);
        }
        if (bytes < 0x40000000L) {
            return String.format("%.1f MB", (double)bytes / 1048576.0);
        }
        return String.format("%.1f GB", (double)bytes / 1.073741824E9);
    }
}

