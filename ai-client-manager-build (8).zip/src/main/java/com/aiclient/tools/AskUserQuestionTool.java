package com.aiclient.tools;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;

public class AskUserQuestionTool implements Tool {

    private static volatile UserInteractionHandler handler;

    public static void setHandler(UserInteractionHandler h) {
        handler = h;
    }

    @Override
    public String getName() {
        return "AskUserQuestion";
    }

    @Override
    public String getDescription() {
        return "Kullan\u0131c\u0131ya bir veya daha fazla netle\u015ftirme sorusu sorar ve cevaplar\u0131 bekler. Belirsizlik oldu\u011funda veya kullan\u0131c\u0131n\u0131n tercihini se\u00e7mesi gerekti\u011finde kullan\u0131l\u0131r.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject properties = new JsonObject();

        JsonObject questions = new JsonObject();
        questions.addProperty("type", "array");
        questions.addProperty("description", "Kullan\u0131c\u0131ya sorulacak soru(lar)");

        JsonObject questionItem = new JsonObject();
        questionItem.addProperty("type", "object");
        JsonObject questionProps = new JsonObject();

        JsonObject questionText = new JsonObject();
        questionText.addProperty("type", "string");
        questionText.addProperty("description", "Sorulacak soru metni");
        questionProps.add("question", questionText);

        JsonObject header = new JsonObject();
        header.addProperty("type", "string");
        header.addProperty("description", "Soru i\u00e7in k\u0131sa ba\u015fl\u0131k");
        questionProps.add("header", header);

        JsonObject multiSelect = new JsonObject();
        multiSelect.addProperty("type", "boolean");
        multiSelect.addProperty("description", "Birden fazla se\u00e7ene\u011fin se\u00e7ilebilir olup olmad\u0131\u011f\u0131");
        questionProps.add("multiSelect", multiSelect);

        JsonObject options = new JsonObject();
        options.addProperty("type", "array");
        options.addProperty("description", "Kullan\u0131c\u0131ya sunulacak se\u00e7enekler");
        JsonObject optionItem = new JsonObject();
        optionItem.addProperty("type", "object");
        JsonObject optionProps = new JsonObject();
        JsonObject label = new JsonObject();
        label.addProperty("type", "string");
        optionProps.add("label", label);
        JsonObject description = new JsonObject();
        description.addProperty("type", "string");
        optionProps.add("description", description);
        optionItem.add("properties", optionProps);
        JsonArray optionRequired = new JsonArray();
        optionRequired.add("label");
        optionItem.add("required", optionRequired);
        options.add("items", optionItem);
        questionProps.add("options", options);

        questionItem.add("properties", questionProps);
        JsonArray questionRequired = new JsonArray();
        questionRequired.add("question");
        questionRequired.add("options");
        questionItem.add("required", questionRequired);
        questions.add("items", questionItem);

        properties.add("questions", questions);
        schema.add("properties", properties);
        JsonArray required = new JsonArray();
        required.add("questions");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        UserInteractionHandler h = handler;
        if (h == null) {
            return "{\"success\":false,\"error\":\"Kullan\u0131c\u0131 etkile\u015fim aray\u00fcz\u00fc bu ortamda kullan\u0131lam\u0131yor.\"}";
        }
        if (input == null || !input.has("questions") || !input.get("questions").isJsonArray()) {
            return "{\"success\":false,\"error\":\"'questions' alan\u0131 zorunludur.\"}";
        }
        JsonArray questions = input.getAsJsonArray("questions");
        JsonArray resultArray = new JsonArray();
        for (JsonElement qEl : questions) {
            String questionText;
            String header = "";
            boolean multiSelect = false;
            List<UserInteractionHandler.Option> options = new ArrayList<UserInteractionHandler.Option>();
            if (qEl != null && qEl.isJsonObject()) {
                JsonObject q = qEl.getAsJsonObject();
                questionText = q.has("question") && !q.get("question").isJsonNull() ? q.get("question").getAsString() : "";
                header = q.has("header") && !q.get("header").isJsonNull() ? q.get("header").getAsString() : "";
                multiSelect = q.has("multiSelect") && !q.get("multiSelect").isJsonNull() && q.get("multiSelect").getAsBoolean();
                if (q.has("options") && q.get("options").isJsonArray()) {
                    for (JsonElement oEl : q.getAsJsonArray("options")) {
                        if (oEl == null) {
                            continue;
                        }
                        if (oEl.isJsonObject()) {
                            JsonObject o = oEl.getAsJsonObject();
                            String label = o.has("label") && !o.get("label").isJsonNull() ? o.get("label").getAsString() : "";
                            String desc = o.has("description") && !o.get("description").isJsonNull() ? o.get("description").getAsString() : "";
                            options.add(new UserInteractionHandler.Option(label, desc));
                        } else if (oEl.isJsonPrimitive()) {
                            options.add(new UserInteractionHandler.Option(oEl.getAsString(), ""));
                        }
                    }
                }
            } else if (qEl != null && qEl.isJsonPrimitive()) {
                questionText = qEl.getAsString();
            } else {
                questionText = "";
            }
            List<String> answers = h.ask(header, questionText, options, multiSelect);
            JsonObject qResult = new JsonObject();
            qResult.addProperty("question", questionText);
            JsonArray answerArray = new JsonArray();
            for (String a : answers) {
                answerArray.add(a);
            }
            qResult.add("answers", answerArray);
            resultArray.add(qResult);
        }
        JsonObject result = new JsonObject();
        result.addProperty("success", true);
        result.add("result", resultArray);
        return result.toString();
    }
}
