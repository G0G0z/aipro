package com.aiclient.tools;

import com.google.gson.JsonObject;

import java.util.List;

public class TodoReadTool implements Tool {

    @Override
    public String getName() {
        return "TodoRead";
    }

    @Override
    public String getDescription() {
        return "Mevcut g\u00f6rev listesini (todo) okur.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        schema.add("properties", new JsonObject());
        return schema;
    }

    @Override
    public String execute(JsonObject input) {
        List<TodoStore.TodoItem> items = TodoStore.getAll();
        if (items.isEmpty()) {
            return "G\u00f6rev listesi bo\u015f.";
        }
        StringBuilder sb = new StringBuilder();
        int i = 1;
        for (TodoStore.TodoItem item : items) {
            String marker = switch (item.status) {
                case "completed" -> "[x]";
                case "in_progress" -> "[~]";
                default -> "[ ]";
            };
            sb.append(i++).append(". ").append(marker).append(" ").append(item.content).append("\n");
        }
        return sb.toString().trim();
    }
}
