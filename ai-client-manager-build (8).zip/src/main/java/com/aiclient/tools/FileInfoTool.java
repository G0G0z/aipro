/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class FileInfoTool
implements Tool {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault());

    @Override
    public String getName() {
        return "file_info";
    }

    @Override
    public String getDescription() {
        return "Bir dosya veya dizin hakk\u0131nda ayr\u0131nt\u0131l\u0131 bilgi g\u00f6sterir: boyut, olu\u015fturma tarihi, de\u011fi\u015ftirilme tarihi, izinler, sembolik link durumu vb.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Bilgi al\u0131nacak dosya veya dizinin yolu");
        props.add("path", path);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("path");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String filePath = input.get("path").getAsString();
        Path path = Path.of(filePath, new String[0]);
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) {
            return "HATA: Dosya/dizin bulunamad\u0131: " + filePath;
        }
        BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        StringBuilder sb = new StringBuilder();
        sb.append("Yol: ").append(path.toAbsolutePath()).append("\n");
        sb.append("T\u00fcr: ");
        if (attrs.isDirectory()) {
            sb.append("Dizin");
        } else if (attrs.isSymbolicLink()) {
            sb.append("Sembolik ba\u011flant\u0131");
        } else if (attrs.isRegularFile()) {
            sb.append("Normal dosya");
        } else {
            sb.append("Di\u011fer");
        }
        sb.append("\n");
        if (attrs.isSymbolicLink()) {
            sb.append("Hedef: ").append(Files.readSymbolicLink(path)).append("\n");
        }
        if (!attrs.isDirectory()) {
            sb.append("Boyut: ").append(this.formatSize(attrs.size())).append(" (").append(attrs.size()).append(" bayt)\n");
        } else {
            long[] dirSize = new long[]{0L};
            long[] fileCount = new long[]{0L};
            try {
                Files.walk(path, new FileVisitOption[0]).forEach(p -> {
                    if (Files.isRegularFile(p, new LinkOption[0])) {
                        try {
                            dirSize[0] = dirSize[0] + Files.size(p);
                            fileCount[0] = fileCount[0] + 1L;
                        }
                        catch (Exception exception) {
                            // empty catch block
                        }
                    }
                });
            }
            catch (Exception exception) {
                // empty catch block
            }
            sb.append("Dizin boyutu: ").append(this.formatSize(dirSize[0])).append(" (").append(fileCount[0]).append(" dosya)\n");
        }
        sb.append("Olu\u015fturulma: ").append(FMT.format(attrs.creationTime().toInstant())).append("\n");
        sb.append("De\u011fi\u015ftirilme: ").append(FMT.format(attrs.lastModifiedTime().toInstant())).append("\n");
        sb.append("Son eri\u015fim: ").append(FMT.format(attrs.lastAccessTime().toInstant())).append("\n");
        sb.append("Okunabilir: ").append(Files.isReadable(path) ? "Evet" : "Hay\u0131r").append("\n");
        sb.append("Yaz\u0131labilir: ").append(Files.isWritable(path) ? "Evet" : "Hay\u0131r").append("\n");
        sb.append("\u00c7al\u0131\u015ft\u0131r\u0131labilir: ").append(Files.isExecutable(path) ? "Evet" : "Hay\u0131r").append("\n");
        sb.append("Gizli: ").append(Files.isHidden(path) ? "Evet" : "Hay\u0131r").append("\n");
        return sb.toString();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024L) {
            return bytes + " B";
        }
        if (bytes < 0x100000L) {
            return String.format("%.2f KB", (double)bytes / 1024.0);
        }
        if (bytes < 0x40000000L) {
            return String.format("%.2f MB", (double)bytes / 1048576.0);
        }
        return String.format("%.2f GB", (double)bytes / 1.073741824E9);
    }
}

