/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.ListDirectoryTool;
import com.aiclient.tools.Tool;
import com.google.gson.JsonObject;

public class ClaudeCodeLsTool
implements Tool {
    private final ListDirectoryTool delegate = new ListDirectoryTool();

    @Override
    public String getName() {
        return "LS";
    }

    @Override
    public String getDescription() {
        return "List directory";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        return this.delegate.execute(input);
    }
}

