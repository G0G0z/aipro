/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.nio.file.CopyOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.attribute.FileAttribute;

public class MoveFileTool
implements Tool {
    @Override
    public String getName() {
        return "move_file";
    }

    @Override
    public String getDescription() {
        return "Bir dosyay\u0131 veya dizini ta\u015f\u0131r ya da yeniden adland\u0131r\u0131r. Kaynak ve hedef farkl\u0131 dizinlerde olabilir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject source = new JsonObject();
        source.addProperty("type", "string");
        source.addProperty("description", "Kaynak dosya/dizin yolu");
        props.add("source", source);
        JsonObject destination = new JsonObject();
        destination.addProperty("type", "string");
        destination.addProperty("description", "Hedef dosya/dizin yolu");
        props.add("destination", destination);
        JsonObject overwrite = new JsonObject();
        overwrite.addProperty("type", "boolean");
        overwrite.addProperty("description", "Hedef dosya varsa \u00fczerine yaz (varsay\u0131lan: false)");
        props.add("overwrite", overwrite);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("source");
        required.add("destination");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        CopyOption[] copyOptionArray;
        String sourcePath = input.get("source").getAsString();
        String destPath = input.get("destination").getAsString();
        boolean overwrite = input.has("overwrite") && !input.get("overwrite").isJsonNull() && input.get("overwrite").getAsBoolean();
        Path source = Path.of(sourcePath, new String[0]);
        Path dest = Path.of(destPath, new String[0]);
        if (!Files.exists(source, new LinkOption[0])) {
            return "HATA: Kaynak bulunamad\u0131: " + sourcePath;
        }
        if (Files.exists(dest, new LinkOption[0]) && !overwrite) {
            return "HATA: Hedef zaten mevcut: " + destPath + ". \u00dczerine yazmak i\u00e7in overwrite=true kullan\u0131n.";
        }
        if (dest.getParent() != null) {
            Files.createDirectories(dest.getParent(), new FileAttribute[0]);
        }
        if (overwrite) {
            CopyOption[] copyOptionArray2 = new CopyOption[1];
            copyOptionArray = copyOptionArray2;
            copyOptionArray2[0] = StandardCopyOption.REPLACE_EXISTING;
        } else {
            copyOptionArray = new CopyOption[]{};
        }
        CopyOption[] options = copyOptionArray;
        Files.move(source, dest, options);
        return String.format("Ta\u015f\u0131nd\u0131: %s \u2192 %s", sourcePath, destPath);
    }
}

