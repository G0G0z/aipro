/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;

public class MakeDirectoryTool
implements Tool {
    @Override
    public String getName() {
        return "make_directory";
    }

    @Override
    public String getDescription() {
        return "Bir veya daha fazla i\u00e7 i\u00e7e klas\u00f6r olu\u015fturur. Ara dizinler otomatik olarak olu\u015fturulur (mkdir -p gibi).";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Olu\u015fturulacak dizinin yolu");
        props.add("path", path);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("path");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String dirPath = input.get("path").getAsString();
        Path path = Path.of(dirPath, new String[0]);
        if (Files.exists(path, new LinkOption[0])) {
            return Files.isDirectory(path, new LinkOption[0]) ? "Dizin zaten mevcut: " + dirPath : "HATA: Ayn\u0131 isimde bir dosya mevcut: " + dirPath;
        }
        Files.createDirectories(path, new FileAttribute[0]);
        return "Dizin olu\u015fturuldu: " + String.valueOf(path.toAbsolutePath());
    }
}

