/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.google.gson.JsonObject;

public interface Tool {
    public String getName();

    public String getDescription();

    public JsonObject getInputSchema();

    public String execute(JsonObject var1) throws Exception;
}

