/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.nio.file.attribute.FileAttribute;

public class FileWriteTool
implements Tool {
    @Override
    public String getName() {
        return "write_file";
    }

    @Override
    public String getDescription() {
        return "Bir dosyaya i\u00e7erik yazar. Dosya yoksa olu\u015fturur, varsa \u00fczerine yazar veya ekler. \u00dcst klas\u00f6rler otomatik olu\u015fturulur.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Yaz\u0131lacak dosyan\u0131n yolu");
        props.add("path", path);
        JsonObject content = new JsonObject();
        content.addProperty("type", "string");
        content.addProperty("description", "Dosyaya yaz\u0131lacak i\u00e7erik");
        props.add("content", content);
        JsonObject append = new JsonObject();
        append.addProperty("type", "boolean");
        append.addProperty("description", "true ise dosyan\u0131n sonuna ekle, false ise \u00fczerine yaz (varsay\u0131lan: false)");
        props.add("append", append);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("path");
        required.add("content");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String filePath = input.get("path").getAsString();
        String content = input.get("content").getAsString();
        boolean append = input.has("append") && !input.get("append").isJsonNull() && input.get("append").getAsBoolean();
        Path path = Path.of(filePath, new String[0]);
        if (path.getParent() != null) {
            Files.createDirectories(path.getParent(), new FileAttribute[0]);
        }
        boolean existed = Files.exists(path, new LinkOption[0]);
        if (append) {
            Files.writeString(path, (CharSequence)content, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } else {
            Files.writeString(path, (CharSequence)content, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        }
        long fileSize = Files.size(path);
        int lineCount = content.split("\n", -1).length;
        return String.format("%s: %s\n\u0130\u015flem: %s\nSat\u0131r say\u0131s\u0131: %d\nDosya boyutu: %s", existed ? "G\u00fcncellendi" : "Olu\u015fturuldu", filePath, append ? "Eklendi (append)" : "\u00dczerine yaz\u0131ld\u0131 (overwrite)", lineCount, this.formatSize(fileSize));
    }

    private String formatSize(long bytes) {
        if (bytes < 1024L) {
            return bytes + " B";
        }
        if (bytes < 0x100000L) {
            return String.format("%.1f KB", (double)bytes / 1024.0);
        }
        return String.format("%.1f MB", (double)bytes / 1048576.0);
    }
}

