/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.FileEditTool;
import com.aiclient.tools.Tool;
import com.google.gson.JsonObject;

public class ClaudeCodeEditTool
implements Tool {
    private final FileEditTool delegate = new FileEditTool();

    @Override
    public String getName() {
        return "Edit";
    }

    @Override
    public String getDescription() {
        return "Edit a file";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        JsonObject mapped = new JsonObject();
        String path = input.has("file_path") ? input.get("file_path").getAsString() : (input.has("path") ? input.get("path").getAsString() : null);
        if (path != null) {
            mapped.addProperty("path", path);
        }
        mapped.addProperty("mode", "replace");
        if (input.has("old_string")) {
            mapped.addProperty("old_text", input.get("old_string").getAsString());
        }
        if (input.has("new_string")) {
            mapped.addProperty("new_text", input.get("new_string").getAsString());
        }
        if (input.has("old_text")) {
            mapped.addProperty("old_text", input.get("old_text").getAsString());
        }
        if (input.has("new_text")) {
            mapped.addProperty("new_text", input.get("new_text").getAsString());
        }
        return this.delegate.execute(mapped);
    }
}

