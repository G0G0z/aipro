package com.aiclient.tools;

import java.util.List;

public interface UserInteractionHandler {

    List<String> ask(String header, String question, List<Option> options, boolean multiSelect) throws Exception;

    class Option {
        public final String label;
        public final String description;

        public Option(String label, String description) {
            this.label = label;
            this.description = description;
        }
    }
}
