/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class SearchFilesTool
implements Tool {
    @Override
    public String getName() {
        return "search_files";
    }

    @Override
    public String getDescription() {
        return "Dosyalar i\u00e7inde metin veya regex pattern arar. grep benzeri i\u015flevsellik. Belirli uzant\u0131lar\u0131 filtreler, context sat\u0131rlar\u0131 g\u00f6sterir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject directory = new JsonObject();
        directory.addProperty("type", "string");
        directory.addProperty("description", "Arama yap\u0131lacak dizin (varsay\u0131lan: mevcut dizin)");
        props.add("directory", directory);
        JsonObject pattern = new JsonObject();
        pattern.addProperty("type", "string");
        pattern.addProperty("description", "Aranacak metin veya regex pattern");
        props.add("pattern", pattern);
        JsonObject filePattern = new JsonObject();
        filePattern.addProperty("type", "string");
        filePattern.addProperty("description", "Dosya ad\u0131 filtresi, glob format\u0131nda (\u00f6rn: *.java, *.py). Varsay\u0131lan: t\u00fcm dosyalar");
        props.add("file_pattern", filePattern);
        JsonObject ignoreCase = new JsonObject();
        ignoreCase.addProperty("type", "boolean");
        ignoreCase.addProperty("description", "B\u00fcy\u00fck/k\u00fc\u00e7\u00fck harf fark\u0131n\u0131 g\u00f6rmezden gel (varsay\u0131lan: false)");
        props.add("ignore_case", ignoreCase);
        JsonObject contextLines = new JsonObject();
        contextLines.addProperty("type", "integer");
        contextLines.addProperty("description", "E\u015fle\u015fme etraf\u0131nda g\u00f6sterilecek ba\u011flam sat\u0131r\u0131 say\u0131s\u0131 (varsay\u0131lan: 2)");
        props.add("context_lines", contextLines);
        JsonObject maxResults = new JsonObject();
        maxResults.addProperty("type", "integer");
        maxResults.addProperty("description", "Maksimum sonu\u00e7 say\u0131s\u0131 (varsay\u0131lan: 50)");
        props.add("max_results", maxResults);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("pattern");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        List<Path> allFiles;
        Pattern searchPattern;
        String directory = input.has("directory") && !input.get("directory").isJsonNull() ? input.get("directory").getAsString() : ".";
        String patternStr = input.get("pattern").getAsString();
        String fileGlob = input.has("file_pattern") && !input.get("file_pattern").isJsonNull() ? input.get("file_pattern").getAsString() : null;
        boolean ignoreCase = input.has("ignore_case") && !input.get("ignore_case").isJsonNull() && input.get("ignore_case").getAsBoolean();
        int contextLines = input.has("context_lines") && !input.get("context_lines").isJsonNull() ? input.get("context_lines").getAsInt() : 2;
        int maxResults = input.has("max_results") && !input.get("max_results").isJsonNull() ? input.get("max_results").getAsInt() : 50;
        Path searchDir = Path.of(directory, new String[0]);
        if (!Files.exists(searchDir, new LinkOption[0])) {
            return "HATA: Dizin bulunamad\u0131: " + directory;
        }
        int flags = ignoreCase ? 2 : 0;
        try {
            searchPattern = Pattern.compile(Pattern.quote(patternStr), flags);
        }
        catch (PatternSyntaxException e) {
            try {
                searchPattern = Pattern.compile(patternStr, flags);
            }
            catch (PatternSyntaxException e2) {
                return "HATA: Ge\u00e7ersiz regex pattern: " + e2.getMessage();
            }
        }
        Pattern finalPattern = searchPattern;
        PathMatcher matcher = fileGlob != null ? FileSystems.getDefault().getPathMatcher("glob:" + fileGlob) : null;
        try (Stream<Path> stream = Files.walk(searchDir, new FileVisitOption[0]);){
            allFiles = stream.filter(x$0 -> Files.isRegularFile(x$0, new LinkOption[0])).filter(p -> {
                if (matcher == null) {
                    return true;
                }
                return matcher.matches(p.getFileName());
            }).collect(Collectors.toList());
        }
        ArrayList<String> results = new ArrayList<String>();
        int totalMatches = 0;
        for (Path file : allFiles) {
            if (totalMatches >= maxResults) break;
            try {
                if (Files.size(file) > 0x500000L) continue;
                List<String> lines = Files.readAllLines(file);
                for (int i = 0; i < lines.size() && totalMatches < maxResults; ++i) {
                    if (!finalPattern.matcher(lines.get(i)).find()) continue;
                    StringBuilder sb = new StringBuilder();
                    sb.append("\n").append("\u2500".repeat(50)).append("\n");
                    sb.append(file).append(":").append(i + 1).append("\n");
                    int start = Math.max(0, i - contextLines);
                    int end = Math.min(lines.size() - 1, i + contextLines);
                    for (int j = start; j <= end; ++j) {
                        String prefix = j == i ? "\u2192 " : "  ";
                        sb.append(String.format("%s%4d \u2502 %s%n", prefix, j + 1, lines.get(j)));
                    }
                    results.add(sb.toString());
                    ++totalMatches;
                }
            }
            catch (Exception lines) {
            }
        }
        if (results.isEmpty()) {
            return "Sonu\u00e7 bulunamad\u0131: \"" + patternStr + "\" \u2014 " + directory + " dizininde";
        }
        StringBuilder sb = new StringBuilder();
        sb.append("Arama: \"").append(patternStr).append("\"  Dizin: ").append(directory).append("\n");
        sb.append("Bulunan e\u015fle\u015fme: ").append(totalMatches);
        if (totalMatches >= maxResults) {
            sb.append(" (s\u0131n\u0131ra ula\u015f\u0131ld\u0131)");
        }
        sb.append("\n");
        for (String r : results) {
            sb.append(r);
        }
        return sb.toString();
    }
}

