package com.aiclient.tools;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ConsoleUserInteractionHandler implements UserInteractionHandler {

    private final Scanner scanner;

    public ConsoleUserInteractionHandler(Scanner scanner) {
        this.scanner = scanner;
    }

    @Override
    public List<String> ask(String header, String question, List<Option> options, boolean multiSelect) {
        System.out.println();
        System.out.println("\u001b[36m\u2753  " + (header != null && !header.isBlank() ? header : "Soru") + "\u001b[0m");
        System.out.println("  " + question);
        for (int i = 0; i < options.size(); i++) {
            Option opt = options.get(i);
            System.out.println("  " + (i + 1) + ") " + opt.label + (opt.description != null && !opt.description.isBlank() ? "  \u2014 " + opt.description : ""));
        }
        System.out.print(multiSelect ? "  Se\u00e7iminiz (numaralar\u0131 virg\u00fclle ay\u0131r\u0131n, veya serbest metin yaz\u0131n) \u276f " : "  Se\u00e7iminiz (numara veya serbest metin) \u276f ");
        String line = "";
        try {
            line = this.scanner.nextLine();
        } catch (Exception e) {
            line = "";
        }
        line = line == null ? "" : line.trim();
        List<String> selected = new ArrayList<String>();
        if (!line.isEmpty()) {
            String[] parts = line.split(",");
            boolean allNumeric = true;
            List<String> byIndex = new ArrayList<String>();
            for (String part : parts) {
                String p = part.trim();
                try {
                    int idx = Integer.parseInt(p);
                    if (idx >= 1 && idx <= options.size()) {
                        byIndex.add(options.get(idx - 1).label);
                    } else {
                        allNumeric = false;
                        break;
                    }
                } catch (NumberFormatException e) {
                    allNumeric = false;
                    break;
                }
            }
            if (allNumeric && !byIndex.isEmpty()) {
                selected.addAll(byIndex);
                if (!multiSelect && selected.size() > 1) {
                    selected = selected.subList(0, 1);
                }
            } else {
                selected.add(line);
            }
        }
        System.out.println();
        return selected;
    }
}
