/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FileEditTool
implements Tool {
    @Override
    public String getName() {
        return "edit_file";
    }

    @Override
    public String getDescription() {
        return "Bir dosyadaki belirli sat\u0131r aral\u0131\u011f\u0131n\u0131 yeni i\u00e7erikle de\u011fi\u015ftirir. Sat\u0131rlar\u0131 silmek i\u00e7in new_content bo\u015f b\u0131rak\u0131n. Ayr\u0131ca eski metni yeni metinle bul-de\u011fi\u015ftir yapabilir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "D\u00fczenlenecek dosyan\u0131n yolu");
        props.add("path", path);
        JsonObject mode = new JsonObject();
        mode.addProperty("type", "string");
        mode.addProperty("description", "D\u00fczenleme modu: 'lines' (sat\u0131r aral\u0131\u011f\u0131 de\u011fi\u015ftir) veya 'replace' (metin bul-de\u011fi\u015ftir)");
        JsonArray modeEnum = new JsonArray();
        modeEnum.add("lines");
        modeEnum.add("replace");
        mode.add("enum", modeEnum);
        props.add("mode", mode);
        JsonObject startLine = new JsonObject();
        startLine.addProperty("type", "integer");
        startLine.addProperty("description", "Ba\u015flang\u0131\u00e7 sat\u0131r\u0131 (mode=lines i\u00e7in zorunlu, 1'den ba\u015flar)");
        props.add("start_line", startLine);
        JsonObject endLine = new JsonObject();
        endLine.addProperty("type", "integer");
        endLine.addProperty("description", "Biti\u015f sat\u0131r\u0131 (mode=lines i\u00e7in zorunlu, dahil)");
        props.add("end_line", endLine);
        JsonObject newContent = new JsonObject();
        newContent.addProperty("type", "string");
        newContent.addProperty("description", "De\u011fi\u015ftirilecek yeni i\u00e7erik (mode=lines i\u00e7in). Bo\u015f ise sat\u0131rlar silinir.");
        props.add("new_content", newContent);
        JsonObject oldText = new JsonObject();
        oldText.addProperty("type", "string");
        oldText.addProperty("description", "Aranacak metin (mode=replace i\u00e7in zorunlu)");
        props.add("old_text", oldText);
        JsonObject newText = new JsonObject();
        newText.addProperty("type", "string");
        newText.addProperty("description", "Yerine yaz\u0131lacak metin (mode=replace i\u00e7in zorunlu)");
        props.add("new_text", newText);
        JsonObject replaceAll = new JsonObject();
        replaceAll.addProperty("type", "boolean");
        replaceAll.addProperty("description", "T\u00fcm e\u015fle\u015fmeleri de\u011fi\u015ftir (mode=replace i\u00e7in, varsay\u0131lan: false = sadece ilk e\u015fle\u015fme)");
        props.add("replace_all", replaceAll);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("path");
        required.add("mode");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String filePath = input.get("path").getAsString();
        String mode = input.has("mode") ? input.get("mode").getAsString() : "lines";
        Path path = Path.of(filePath, new String[0]);
        if (!Files.exists(path, new LinkOption[0])) {
            return "HATA: Dosya bulunamad\u0131: " + filePath;
        }
        if ("replace".equals(mode)) {
            return this.executeReplace(path, filePath, input);
        }
        return this.executeLines(path, filePath, input);
    }

    private String executeLines(Path path, String filePath, JsonObject input) throws Exception {
        if (!input.has("start_line") || !input.has("end_line")) {
            return "HATA: mode=lines i\u00e7in start_line ve end_line zorunludur.";
        }
        int startLine = input.get("start_line").getAsInt();
        int endLine = input.get("end_line").getAsInt();
        String newContent = input.has("new_content") && !input.get("new_content").isJsonNull() ? input.get("new_content").getAsString() : "";
        ArrayList<String> lines = new ArrayList<String>(Files.readAllLines(path));
        int total = lines.size();
        if (startLine < 1 || startLine > total) {
            return "HATA: Ge\u00e7ersiz start_line=" + startLine + " (Toplam sat\u0131r: " + total + ")";
        }
        if (endLine < startLine || endLine > total) {
            return "HATA: Ge\u00e7ersiz end_line=" + endLine;
        }
        List before = lines.subList(0, startLine - 1);
        List after = lines.subList(endLine, lines.size());
        List replacement = newContent.isEmpty() ? List.of() : List.of(newContent.split("\n", -1));
        ArrayList result = new ArrayList();
        result.addAll(before);
        result.addAll(replacement);
        result.addAll(after);
        Files.write(path, result, new OpenOption[0]);
        int removed = endLine - startLine + 1;
        int added = replacement.size();
        return String.format("D\u00fczenlendi: %s\nSat\u0131r %d-%d de\u011fi\u015ftirildi (%d sat\u0131r silindi, %d sat\u0131r eklendi)\nYeni toplam: %d sat\u0131r", filePath, startLine, endLine, removed, added, result.size());
    }

    private String executeReplace(Path path, String filePath, JsonObject input) throws Exception {
        String result;
        if (!input.has("old_text") || !input.has("new_text")) {
            return "HATA: mode=replace i\u00e7in old_text ve new_text zorunludur.";
        }
        String oldText = input.get("old_text").getAsString();
        String newText = input.get("new_text").getAsString();
        boolean replaceAll = input.has("replace_all") && !input.get("replace_all").isJsonNull() && input.get("replace_all").getAsBoolean();
        String content = Files.readString(path);
        if (!content.contains(oldText)) {
            return "HATA: Metin bulunamad\u0131: \"" + this.truncate(oldText, 50) + "\"";
        }
        int count = 0;
        if (replaceAll) {
            count = this.countOccurrences(content, oldText);
            result = content.replace(oldText, newText);
        } else {
            count = 1;
            result = content.replaceFirst(Pattern.quote(oldText), Matcher.quoteReplacement(newText));
        }
        Files.writeString(path, (CharSequence)result, new OpenOption[0]);
        return String.format("De\u011fi\u015ftirildi: %s\n%d adet \"%s\" \u2192 \"%s\" olarak de\u011fi\u015ftirildi", filePath, count, this.truncate(oldText, 30), this.truncate(newText, 30));
    }

    private int countOccurrences(String text, String pattern) {
        int count = 0;
        int idx = 0;
        while ((idx = text.indexOf(pattern, idx)) != -1) {
            ++count;
            idx += pattern.length();
        }
        return count;
    }

    private String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}

