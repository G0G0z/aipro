/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.FileReadTool;
import com.aiclient.tools.Tool;
import com.google.gson.JsonObject;

public class ClaudeCodeReadTool
implements Tool {
    private final FileReadTool delegate = new FileReadTool();

    @Override
    public String getName() {
        return "Read";
    }

    @Override
    public String getDescription() {
        return "Read a file";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        JsonObject mapped = new JsonObject();
        String path = null;
        if (input.has("file_path")) {
            path = input.get("file_path").getAsString();
        } else if (input.has("path")) {
            path = input.get("path").getAsString();
        }
        if (path != null) {
            mapped.addProperty("path", path);
        }
        if (input.has("offset")) {
            mapped.addProperty("start_line", input.get("offset").getAsInt() + 1);
        }
        if (input.has("limit") && input.has("offset")) {
            int offset = input.get("offset").getAsInt();
            int limit = input.get("limit").getAsInt();
            mapped.addProperty("end_line", offset + limit);
        }
        return this.delegate.execute(mapped);
    }
}

