/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.FileReadTool;
import com.aiclient.tools.Tool;
import com.google.gson.JsonObject;

public class ClaudeCodeNotebookReadTool
implements Tool {
    private final FileReadTool delegate = new FileReadTool();

    @Override
    public String getName() {
        return "NotebookRead";
    }

    @Override
    public String getDescription() {
        return "Read a notebook file";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject s = new JsonObject();
        s.addProperty("type", "object");
        return s;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        JsonObject mapped = new JsonObject();
        if (input.has("notebook_path")) {
            mapped.addProperty("path", input.get("notebook_path").getAsString());
        } else if (input.has("file_path")) {
            mapped.addProperty("path", input.get("file_path").getAsString());
        } else if (input.has("path")) {
            mapped.addProperty("path", input.get("path").getAsString());
        }
        return this.delegate.execute(mapped);
    }
}

