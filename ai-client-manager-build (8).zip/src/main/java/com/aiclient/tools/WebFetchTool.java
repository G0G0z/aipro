package com.aiclient.tools;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

public class WebFetchTool implements Tool {

    private static final int MAX_OUTPUT_CHARS = 8000;
    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    @Override
    public String getName() {
        return "WebFetch";
    }

    @Override
    public String getDescription() {
        return "Bir URL'nin i\u00e7eri\u011fini indirir ve d\u00fcz metin olarak d\u00f6nd\u00fcr\u00fcr. HTML etiketleri temizlenir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject url = new JsonObject();
        url.addProperty("type", "string");
        url.addProperty("description", "\u0130ndirilecek URL (http:// veya https://)");
        props.add("url", url);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("url");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String urlStr = input.get("url").getAsString().trim();
        if (!urlStr.startsWith("http://") && !urlStr.startsWith("https://")) {
            urlStr = "https://" + urlStr;
        }
        URI uri = URI.create(urlStr);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .header("User-Agent", "Mozilla/5.0 (compatible; AIClientManager/2.0)")
                .timeout(Duration.ofSeconds(20))
                .GET()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        String contentType = response.headers().firstValue("content-type").orElse("");
        String body = response.body();

        String text;
        if (contentType.contains("text/html") || body.trim().startsWith("<")) {
            text = stripHtml(body);
        } else {
            text = body;
        }

        if (text.length() > MAX_OUTPUT_CHARS) {
            text = text.substring(0, MAX_OUTPUT_CHARS) + "\n... (i\u00e7erik kesildi)";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("URL: ").append(uri).append("\n");
        sb.append("Durum kodu: ").append(response.statusCode()).append("\n");
        sb.append("\u2500".repeat(50)).append("\n");
        sb.append(text);
        return sb.toString();
    }

    private String stripHtml(String html) {
        String noScripts = html.replaceAll("(?is)<script.*?>.*?</script>", " ")
                .replaceAll("(?is)<style.*?>.*?</style>", " ");
        String noTags = noScripts.replaceAll("(?is)<br\\s*/?>", "\n")
                .replaceAll("(?is)</p>", "\n\n")
                .replaceAll("(?is)<[^>]+>", " ");
        String decoded = noTags
                .replace("&nbsp;", " ")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&#39;", "'");
        return decoded.replaceAll("[ \\t]+", " ")
                .replaceAll("\\n\\s*\\n\\s*\\n+", "\n\n")
                .trim();
    }
}
