package com.aiclient.tools;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class WebSearchTool implements Tool {

    private static final int MAX_RESULTS = 8;
    private static final Pattern RESULT_PATTERN = Pattern.compile(
            "(?is)<a[^>]+class=\"result__a\"[^>]+href=\"(.*?)\"[^>]*>(.*?)</a>.*?class=\"result__snippet\"[^>]*>(.*?)</a>"
    );

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(15))
            .followRedirects(HttpClient.Redirect.NORMAL)
            .build();

    @Override
    public String getName() {
        return "WebSearch";
    }

    @Override
    public String getDescription() {
        return "Web'de arama yapar ve en alakal\u0131 sonu\u00e7lar\u0131n ba\u015fl\u0131k, URL ve k\u0131sa \u00f6zetini d\u00f6nd\u00fcr\u00fcr.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject query = new JsonObject();
        query.addProperty("type", "string");
        query.addProperty("description", "Arama sorgusu");
        props.add("query", query);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("query");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String query = input.get("query").getAsString().trim();
        if (query.isEmpty()) {
            return "HATA: Arama sorgusu bo\u015f olamaz.";
        }
        String encoded = URLEncoder.encode(query, StandardCharsets.UTF_8);
        URI uri = URI.create("https://html.duckduckgo.com/html/?q=" + encoded);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(uri)
                .header("User-Agent", "Mozilla/5.0 (compatible; AIClientManager/2.0)")
                .timeout(Duration.ofSeconds(20))
                .GET()
                .build();

        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
        if (response.statusCode() != 200) {
            return "HATA: Arama motoru " + response.statusCode() + " kodu d\u00f6nd\u00fcrd\u00fc.";
        }

        String html = response.body();
        Matcher matcher = RESULT_PATTERN.matcher(html);
        StringBuilder sb = new StringBuilder();
        sb.append("Arama sorgusu: ").append(query).append("\n");
        sb.append("\u2500".repeat(50)).append("\n");

        int count = 0;
        while (matcher.find() && count < MAX_RESULTS) {
            String link = decodeDuckDuckGoUrl(matcher.group(1).trim());
            String title = stripTags(matcher.group(2)).trim();
            String snippet = stripTags(matcher.group(3)).trim();
            if (title.isEmpty()) {
                continue;
            }
            count++;
            sb.append(count).append(". ").append(title).append("\n");
            sb.append("   ").append(link).append("\n");
            if (!snippet.isEmpty()) {
                sb.append("   ").append(snippet).append("\n");
            }
            sb.append("\n");
        }

        if (count == 0) {
            sb.append("Sonu\u00e7 bulunamad\u0131.");
        }

        return sb.toString().trim();
    }

    private String decodeDuckDuckGoUrl(String href) {
        String url = href.replace("&amp;", "&");
        int idx = url.indexOf("uddg=");
        if (idx >= 0) {
            String encodedPart = url.substring(idx + 5);
            int amp = encodedPart.indexOf('&');
            if (amp >= 0) {
                encodedPart = encodedPart.substring(0, amp);
            }
            try {
                return java.net.URLDecoder.decode(encodedPart, StandardCharsets.UTF_8);
            } catch (Exception e) {
                return url;
            }
        }
        if (url.startsWith("//")) {
            return "https:" + url;
        }
        return url;
    }

    private String stripTags(String s) {
        return s.replaceAll("(?is)<[^>]+>", "")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&#39;", "'")
                .replace("&nbsp;", " ");
    }
}
