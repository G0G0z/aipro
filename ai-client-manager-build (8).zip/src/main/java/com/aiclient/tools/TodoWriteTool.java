package com.aiclient.tools;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.util.ArrayList;
import java.util.List;

public class TodoWriteTool implements Tool {

    @Override
    public String getName() {
        return "TodoWrite";
    }

    @Override
    public String getDescription() {
        return "G\u00f6rev listesini (todo) olu\u015fturur veya g\u00fcnceller. Her g\u00f6revin bir i\u00e7eri\u011fi (content) ve durumu (status: pending, in_progress, completed) vard\u0131r.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject todos = new JsonObject();
        todos.addProperty("type", "array");
        JsonObject items = new JsonObject();
        items.addProperty("type", "object");
        JsonObject itemProps = new JsonObject();
        JsonObject content = new JsonObject();
        content.addProperty("type", "string");
        itemProps.add("content", content);
        JsonObject status = new JsonObject();
        status.addProperty("type", "string");
        JsonArray enumArr = new JsonArray();
        enumArr.add("pending");
        enumArr.add("in_progress");
        enumArr.add("completed");
        status.add("enum", enumArr);
        itemProps.add("status", status);
        items.add("properties", itemProps);
        todos.add("items", items);
        todos.addProperty("description", "G\u00f6rev listesi");
        props.add("todos", todos);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("todos");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) {
        if (!input.has("todos") || !input.get("todos").isJsonArray()) {
            return "HATA: 'todos' dizisi gerekli.";
        }
        JsonArray todosArray = input.getAsJsonArray("todos");
        List<TodoStore.TodoItem> newItems = new ArrayList<>();
        for (JsonElement e : todosArray) {
            if (!e.isJsonObject()) {
                continue;
            }
            JsonObject obj = e.getAsJsonObject();
            String content = obj.has("content") ? obj.get("content").getAsString() : "";
            String status = obj.has("status") ? obj.get("status").getAsString() : "pending";
            if (!content.isBlank()) {
                newItems.add(new TodoStore.TodoItem(content, status));
            }
        }
        TodoStore.replaceAll(newItems);
        return "G\u00f6rev listesi g\u00fcncellendi (" + newItems.size() + " g\u00f6rev).";
    }
}
