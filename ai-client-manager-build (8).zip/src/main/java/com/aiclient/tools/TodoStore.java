package com.aiclient.tools;

import java.util.ArrayList;
import java.util.List;

public class TodoStore {

    public static class TodoItem {
        public String content;
        public String status;

        public TodoItem(String content, String status) {
            this.content = content;
            this.status = status;
        }
    }

    private static final List<TodoItem> items = new ArrayList<>();

    public static synchronized List<TodoItem> getAll() {
        return new ArrayList<>(items);
    }

    public static synchronized void replaceAll(List<TodoItem> newItems) {
        items.clear();
        items.addAll(newItems);
    }

    private TodoStore() {
    }
}
