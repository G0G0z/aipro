/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.FileWriteTool;
import com.aiclient.tools.Tool;
import com.google.gson.JsonObject;

public class ClaudeCodeWriteTool
implements Tool {
    private final FileWriteTool delegate = new FileWriteTool();

    @Override
    public String getName() {
        return "Write";
    }

    @Override
    public String getDescription() {
        return "Write a file";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        JsonObject mapped = new JsonObject();
        String path = input.has("file_path") ? input.get("file_path").getAsString() : (input.has("path") ? input.get("path").getAsString() : null);
        if (path != null) {
            mapped.addProperty("path", path);
        }
        String content = input.has("content") ? input.get("content").getAsString() : "";
        mapped.addProperty("content", content);
        return this.delegate.execute(mapped);
    }
}

