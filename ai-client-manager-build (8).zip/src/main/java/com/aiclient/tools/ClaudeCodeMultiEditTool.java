/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.FileEditTool;
import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class ClaudeCodeMultiEditTool
implements Tool {
    private final FileEditTool delegate = new FileEditTool();

    @Override
    public String getName() {
        return "MultiEdit";
    }

    @Override
    public String getDescription() {
        return "Apply multiple edits to a file";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String path = input.has("file_path") ? input.get("file_path").getAsString() : (input.has("path") ? input.get("path").getAsString() : null);
        if (path == null) {
            return "HATA: file_path belirtilmedi";
        }
        JsonArray edits = input.has("edits") ? input.getAsJsonArray("edits") : new JsonArray();
        StringBuilder results = new StringBuilder();
        int i = 0;
        for (JsonElement elem : edits) {
            ++i;
            if (elem == null || !elem.isJsonObject()) {
                results.append("D\u00fczenleme ").append(i).append(": HATA: ge\u00e7ersiz d\u00fczenleme girdisi\n");
                continue;
            }
            JsonObject edit = elem.getAsJsonObject();
            JsonObject mapped = new JsonObject();
            mapped.addProperty("path", path);
            mapped.addProperty("mode", "replace");
            if (edit.has("old_string")) {
                mapped.addProperty("old_text", edit.get("old_string").getAsString());
            }
            if (edit.has("new_string")) {
                mapped.addProperty("new_text", edit.get("new_string").getAsString());
            }
            results.append("D\u00fczenleme ").append(i).append(": ").append(this.delegate.execute(mapped)).append("\n");
        }
        return results.toString().trim();
    }
}

