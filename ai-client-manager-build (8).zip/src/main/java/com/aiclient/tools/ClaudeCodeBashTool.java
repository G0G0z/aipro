/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.ExecuteCommandTool;
import com.aiclient.tools.Tool;
import com.google.gson.JsonObject;

public class ClaudeCodeBashTool
implements Tool {
    private final ExecuteCommandTool delegate = new ExecuteCommandTool();

    @Override
    public String getName() {
        return "Bash";
    }

    @Override
    public String getDescription() {
        return "Execute a bash command";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject cmd = new JsonObject();
        cmd.addProperty("type", "string");
        props.add("command", cmd);
        schema.add("properties", props);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        JsonObject mapped = new JsonObject();
        if (input.has("command")) {
            mapped.addProperty("command", input.get("command").getAsString());
        } else if (input.has("cmd")) {
            mapped.addProperty("command", input.get("cmd").getAsString());
        }
        if (input.has("timeout")) {
            int timeoutMs = input.get("timeout").getAsInt();
            mapped.addProperty("timeout_seconds", Math.min(120, timeoutMs / 1000));
        }
        return this.delegate.execute(mapped);
    }
}

