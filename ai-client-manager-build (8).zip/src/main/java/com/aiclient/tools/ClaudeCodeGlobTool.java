/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonObject;
import java.nio.file.FileSystems;
import java.nio.file.FileVisitOption;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.PathMatcher;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ClaudeCodeGlobTool
implements Tool {
    @Override
    public String getName() {
        return "Glob";
    }

    @Override
    public String getDescription() {
        return "Find files matching a glob pattern";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        List<String> matches;
        String pattern = input.has("pattern") ? input.get("pattern").getAsString() : "**/*";
        String base = input.has("path") ? input.get("path").getAsString() : ".";
        Path basePath = Path.of(base, new String[0]);
        PathMatcher matcher = FileSystems.getDefault().getPathMatcher("glob:" + pattern);
        try (Stream<Path> stream = Files.walk(basePath, new FileVisitOption[0]);){
            matches = stream.filter(x$0 -> Files.isRegularFile(x$0, new LinkOption[0])).filter(p -> matcher.matches(basePath.relativize((Path)p))).map(Path::toString).sorted().limit(200L).collect(Collectors.toList());
        }
        if (matches.isEmpty()) {
            return "E\u015fle\u015fen dosya bulunamad\u0131: " + pattern;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("E\u015fle\u015fen ").append(matches.size()).append(" dosya (pattern: ").append(pattern).append("):\n");
        for (String m : matches) {
            sb.append(m).append("\n");
        }
        return sb.toString();
    }
}

