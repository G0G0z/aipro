/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.List;

public class FileReadTool
implements Tool {
    @Override
    public String getName() {
        return "read_file";
    }

    @Override
    public String getDescription() {
        return "Bir dosyan\u0131n i\u00e7eri\u011fini okur. \u0130ste\u011fe ba\u011fl\u0131 olarak belirli sat\u0131r aral\u0131\u011f\u0131n\u0131 okuyabilir. B\u00fcy\u00fck dosyalar i\u00e7in sat\u0131r aral\u0131\u011f\u0131 belirtmek tavsiye edilir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Okunacak dosyan\u0131n yolu (mutlak veya g\u00f6reli)");
        props.add("path", path);
        JsonObject startLine = new JsonObject();
        startLine.addProperty("type", "integer");
        startLine.addProperty("description", "Ba\u015flang\u0131\u00e7 sat\u0131r\u0131 (1'den ba\u015flar, iste\u011fe ba\u011fl\u0131)");
        props.add("start_line", startLine);
        JsonObject endLine = new JsonObject();
        endLine.addProperty("type", "integer");
        endLine.addProperty("description", "Biti\u015f sat\u0131r\u0131 (dahil, iste\u011fe ba\u011fl\u0131)");
        props.add("end_line", endLine);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("path");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String filePath = input.get("path").getAsString();
        Path path = Path.of(filePath, new String[0]);
        if (!Files.exists(path, new LinkOption[0])) {
            return "HATA: Dosya bulunamad\u0131: " + filePath;
        }
        if (Files.isDirectory(path, new LinkOption[0])) {
            return "HATA: Bu bir dizin, dosya de\u011fil: " + filePath;
        }
        List<String> lines = Files.readAllLines(path);
        int totalLines = lines.size();
        int startLine = 1;
        int endLine = totalLines;
        if (input.has("start_line") && !input.get("start_line").isJsonNull()) {
            startLine = input.get("start_line").getAsInt();
        }
        if (input.has("end_line") && !input.get("end_line").isJsonNull()) {
            endLine = input.get("end_line").getAsInt();
        }
        startLine = Math.max(1, startLine);
        endLine = Math.min(totalLines, endLine);
        StringBuilder sb = new StringBuilder();
        sb.append("Dosya: ").append(filePath).append("\n");
        sb.append("Toplam sat\u0131r: ").append(totalLines).append("\n");
        if (startLine != 1 || endLine != totalLines) {
            sb.append("G\u00f6sterilen sat\u0131rlar: ").append(startLine).append("-").append(endLine).append("\n");
        }
        sb.append("\u2500".repeat(60)).append("\n");
        for (int i = startLine - 1; i < endLine && i < lines.size(); ++i) {
            sb.append(String.format("%4d \u2502 %s%n", i + 1, lines.get(i)));
        }
        long fileSize = Files.size(path);
        sb.append("\u2500".repeat(60)).append("\n");
        sb.append("Dosya boyutu: ").append(this.formatSize(fileSize));
        return sb.toString();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024L) {
            return bytes + " B";
        }
        if (bytes < 0x100000L) {
            return String.format("%.1f KB", (double)bytes / 1024.0);
        }
        return String.format("%.1f MB", (double)bytes / 1048576.0);
    }
}

