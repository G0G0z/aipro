/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.tools;

import com.aiclient.tools.Tool;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.FileVisitor;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.stream.Stream;

public class FileDeleteTool
implements Tool {
    @Override
    public String getName() {
        return "delete_file";
    }

    @Override
    public String getDescription() {
        return "Bir dosyay\u0131 veya bo\u015f olmayan bir dizini siler. recursive=true ile dolu dizinleri de silebilir (dikkatli kullan\u0131n!).";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Silinecek dosya veya dizinin yolu");
        props.add("path", path);
        JsonObject recursive = new JsonObject();
        recursive.addProperty("type", "boolean");
        recursive.addProperty("description", "Dizini t\u00fcm i\u00e7eri\u011fiyle birlikte sil (varsay\u0131lan: false)");
        props.add("recursive", recursive);
        schema.add("properties", props);
        JsonArray required = new JsonArray();
        required.add("path");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String type;
        String filePath = input.get("path").getAsString();
        boolean recursive = input.has("recursive") && !input.get("recursive").isJsonNull() && input.get("recursive").getAsBoolean();
        Path path = Path.of(filePath, new String[0]);
        if (!Files.exists(path, new LinkOption[0])) {
            return "HATA: Dosya/dizin bulunamad\u0131: " + filePath;
        }
        String string = type = Files.isDirectory(path, new LinkOption[0]) ? "Dizin" : "Dosya";
        if (Files.isDirectory(path, new LinkOption[0])) {
            if (!recursive) {
                try (Stream<Path> stream = Files.list(path);){
                    if (stream.findAny().isPresent()) {
                        String string2 = "HATA: Dizin bo\u015f de\u011fil. Silmek i\u00e7in recursive=true kullan\u0131n: " + filePath;
                        return string2;
                    }
                }
            }
            this.deleteRecursively(path);
        } else {
            Files.delete(path);
        }
        return type + " silindi: " + filePath;
    }

    private void deleteRecursively(Path path) throws IOException {
        Files.walkFileTree(path, (FileVisitor<? super Path>)new SimpleFileVisitor<Path>(){

            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }

            @Override
            public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                Files.delete(dir);
                return FileVisitResult.CONTINUE;
            }
        });
    }
}

