/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient;

import com.aiclient.AnthropicClient;
import com.aiclient.Terminal;
import com.aiclient.tools.Tool;
import com.aiclient.tools.ToolRegistry;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Agent {
    private static final String DEFAULT_MODEL = "claude-opus-4-8";
    private static final int MAX_TOKENS = 8096;
    private static final int MAX_TOOL_ITERATIONS = 50;
    private static final String SYSTEM_PROMPT = "Sen geli\u015fmi\u015f bir yapay zeka asistan\u0131s\u0131n ve tam dosya sistemi ile kabuk eri\u015fimine sahipsin.\n\nSahip oldu\u011fun yetenekler:\n- Dosya okuma, yazma, olu\u015fturma, d\u00fczenleme ve silme\n- Dizin olu\u015fturma, listeleme ve gezinme\n- Dosyalar i\u00e7inde metin/regex arama\n- Kabuk komutlar\u0131 \u00e7al\u0131\u015ft\u0131rma (bash)\n- Dosya/dizin ta\u015f\u0131ma ve yeniden adland\u0131rma\n- Dosya meta bilgilerini g\u00f6r\u00fcnt\u00fcleme\n\nKullan\u0131c\u0131ya T\u00fcrk\u00e7e olarak yan\u0131t ver.\n\n\u00d6nemli kurallar:\n1. Kod yazmadan \u00f6nce mevcut kodu oku (okuma arac\u0131n\u0131 kullan)\n2. De\u011fi\u015fiklik yaparken dikkatli ve \u00f6zenli ol\n3. Silme i\u015flemlerinden \u00f6nce kullan\u0131c\u0131y\u0131 uyar\n4. Uzun \u00e7\u0131kt\u0131lar\u0131 \u00f6zetle ve en \u00f6nemli k\u0131s\u0131mlar\u0131 vurgula\n5. Hata durumunda hatan\u0131n sebebini a\u00e7\u0131kla ve \u00e7\u00f6z\u00fcm \u00f6ner\n6. Birden fazla ad\u0131m gerektiren g\u00f6revlerde ad\u0131m ad\u0131m ilerle\n7. Ara\u00e7lar\u0131 etkin kullan, gereksiz ara\u00e7 \u00e7a\u011fr\u0131s\u0131ndan ka\u00e7\u0131n\n\nMevcut \u00e7al\u0131\u015fma dizini: kullan\u0131c\u0131n\u0131n ba\u015flatt\u0131\u011f\u0131 dizin.\n";
    private final AnthropicClient client;
    private final ToolRegistry toolRegistry;
    private final List<JsonObject> conversationHistory;
    private String currentModel;
    private int totalInputTokens;
    private int totalOutputTokens;
    private final Gson gson;

    public Agent(AnthropicClient client) {
        this.client = client;
        this.toolRegistry = new ToolRegistry();
        this.conversationHistory = new ArrayList<JsonObject>();
        this.currentModel = DEFAULT_MODEL;
        this.totalInputTokens = 0;
        this.totalOutputTokens = 0;
        this.gson = new GsonBuilder().create();
    }

    public String chat(String userMessage) throws Exception {
        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", userMessage);
        this.conversationHistory.add(userMsg);
        StringBuilder finalResponse = new StringBuilder();
        int iterations = 0;
        while (iterations < 50) {
            ++iterations;
            AnthropicClient.ApiResponse response = this.client.sendMessages(this.currentModel, SYSTEM_PROMPT, this.conversationHistory, this.toolRegistry.toApiFormat(), 8096);
            this.totalInputTokens += response.usage().inputTokens();
            this.totalOutputTokens += response.usage().outputTokens();
            JsonObject assistantMsg = new JsonObject();
            assistantMsg.addProperty("role", "assistant");
            assistantMsg.add("content", response.content());
            this.conversationHistory.add(assistantMsg);
            boolean hasText = false;
            for (JsonElement elem : response.content()) {
                String text;
                if (elem == null || !elem.isJsonObject()) {
                    if (elem != null && elem.isJsonPrimitive()) {
                        text = elem.getAsString();
                        if (!text.isBlank()) {
                            if (hasText) {
                                finalResponse.append("\n");
                            }
                            finalResponse.append(text);
                            hasText = true;
                        }
                    }
                    continue;
                }
                JsonObject block = elem.getAsJsonObject();
                String type = block.has("type") ? block.get("type").getAsString() : "";
                if (!"text".equals(type) || !block.has("text") || (text = block.get("text").getAsString()).isBlank()) continue;
                if (hasText) {
                    finalResponse.append("\n");
                }
                finalResponse.append(text);
                hasText = true;
            }
            String stopReason = response.stopReason();
            if ("max_tokens".equals(stopReason)) {
                JsonObject continueMsg = new JsonObject();
                continueMsg.addProperty("role", "user");
                continueMsg.addProperty("content", "Devam et (yanıtın kesildi, kaldığın yerden devam et).");
                this.conversationHistory.add(continueMsg);
                continue;
            }
            if (!"tool_use".equals(stopReason)) break;
            ArrayList<JsonObject> toolResults = new ArrayList<JsonObject>();
            for (JsonElement elem3 : response.content()) {
                Object toolResult;
                if (elem3 == null || !elem3.isJsonObject()) {
                    continue;
                }
                JsonObject block = elem3.getAsJsonObject();
                if (!block.has("type") || !"tool_use".equals(block.get("type").getAsString())) continue;
                String toolId = block.get("id").getAsString();
                String toolName = block.get("name").getAsString();
                JsonObject toolInput = block.has("input") && block.get("input").isJsonObject() ? block.getAsJsonObject("input") : new JsonObject();
                Terminal.printToolUse(toolName, toolId);
                boolean success = true;
                try {
                    Tool tool = this.toolRegistry.get(toolName);
                    if (tool == null) {
                        toolResult = "HATA: Bilinmeyen ara\u00e7: " + toolName;
                        success = false;
                    } else {
                        toolResult = tool.execute(toolInput);
                    }
                }
                catch (Exception e) {
                    toolResult = "HATA: " + e.getMessage();
                    success = false;
                }
                Terminal.printToolResult(toolName, success);
                JsonObject resultContent = new JsonObject();
                resultContent.addProperty("type", "tool_result");
                resultContent.addProperty("tool_use_id", toolId);
                resultContent.addProperty("content", (String)toolResult);
                toolResults.add(resultContent);
            }
            if (toolResults.isEmpty()) continue;
            JsonObject toolResultMsg = new JsonObject();
            toolResultMsg.addProperty("role", "user");
            JsonArray contentArray = new JsonArray();
            for (JsonObject r : toolResults) {
                contentArray.add(r);
            }
            toolResultMsg.add("content", contentArray);
            this.conversationHistory.add(toolResultMsg);
        }
        if (iterations >= 50) {
            finalResponse.append("\n[Uyar\u0131: Maksimum ara\u00e7 d\u00f6ng\u00fcs\u00fcne ula\u015f\u0131ld\u0131]");
        }
        return finalResponse.toString().trim();
    }

    public void resetHistory() {
        this.conversationHistory.clear();
        Terminal.printInfo("Sohbet ge\u00e7mi\u015fi temizlendi.");
    }

    public void printHistory() {
        if (this.conversationHistory.isEmpty()) {
            Terminal.printInfo("Sohbet ge\u00e7mi\u015fi bo\u015f.");
            return;
        }
        System.out.println();
        int msgNum = 0;
        for (JsonObject msg : this.conversationHistory) {
            Object content;
            String role = msg.get("role").getAsString();
            if ("user".equals(role) && msg.get("content").isJsonPrimitive()) {
                content = msg.get("content").getAsString();
                System.out.println("\u001b[1m\u001b[32m  [" + ++msgNum + "] Siz: \u001b[0m" + ((String)content).substring(0, Math.min(80, ((String)content).length())) + (((String)content).length() > 80 ? "..." : ""));
                continue;
            }
            if (!"assistant".equals(role) || (content = msg.getAsJsonArray("content")) == null) continue;
            Iterator<JsonElement> iterator = ((JsonArray)content).iterator();
            while (iterator.hasNext()) {
                JsonElement e = iterator.next();
                JsonObject block = e.getAsJsonObject();
                if (!"text".equals(block.get("type").getAsString())) continue;
                String text = block.get("text").getAsString();
                System.out.println("\u001b[1m\u001b[34m  Claude: \u001b[0m" + text.substring(0, Math.min(80, text.length())) + (text.length() > 80 ? "..." : ""));
            }
        }
        System.out.println();
    }

    public void printTokenUsage() {
        Terminal.printTokenUsage(this.totalInputTokens, this.totalOutputTokens, this.totalInputTokens + this.totalOutputTokens);
    }

    public void setModel(String model) {
        this.currentModel = model;
        Terminal.printInfo("Model de\u011fi\u015ftirildi: " + model);
    }

    public String getModel() {
        return this.currentModel;
    }

    public int getHistorySize() {
        return this.conversationHistory.size();
    }
}

