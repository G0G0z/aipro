/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient;

public class Terminal {
    public static final String RESET = "\u001b[0m";
    public static final String BOLD = "\u001b[1m";
    public static final String DIM = "\u001b[2m";
    public static final String ITALIC = "\u001b[3m";
    public static final String BLACK = "\u001b[30m";
    public static final String RED = "\u001b[31m";
    public static final String GREEN = "\u001b[32m";
    public static final String YELLOW = "\u001b[33m";
    public static final String BLUE = "\u001b[34m";
    public static final String MAGENTA = "\u001b[35m";
    public static final String CYAN = "\u001b[36m";
    public static final String WHITE = "\u001b[37m";
    public static final String BG_BLACK = "\u001b[40m";
    public static final String BG_BLUE = "\u001b[44m";
    public static final String BG_MAGENTA = "\u001b[45m";

    public static void printBanner() {
        System.out.println();
        System.out.println("\u001b[1m\u001b[36m  \u2554\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2557\u001b[0m");
        System.out.println("\u001b[1m\u001b[36m  \u2551\u001b[0m\u001b[1m\u001b[37m        Java AI Client  v1.0.0             \u001b[0m\u001b[1m\u001b[36m\u2551\u001b[0m");
        System.out.println("\u001b[1m\u001b[36m  \u2551\u001b[0m\u001b[2m  Claude destekli dosya & shell arac\u0131      \u001b[0m\u001b[1m\u001b[36m\u2551\u001b[0m");
        System.out.println("\u001b[1m\u001b[36m  \u255a\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u2550\u255d\u001b[0m");
        System.out.println();
        System.out.println("\u001b[2m  Ara\u00e7lar: dosya okuma/yazma/d\u00fczenleme/silme,\u001b[0m");
        System.out.println("\u001b[2m           dizin listeleme, dosya arama, komut \u00e7al\u0131\u015ft\u0131rma\u001b[0m");
        System.out.println();
        System.out.println("\u001b[2m  Komutlar: \u001b[0m\u001b[36mexit\u001b[0m\u001b[2m - \u00e7\u0131k  |  \u001b[0m\u001b[36mclear\u001b[0m\u001b[2m - ekran\u0131 temizle  |  \u001b[0m\u001b[36mhelp\u001b[0m\u001b[2m - yard\u0131m\u001b[0m");
        System.out.println("\u001b[2m            \u001b[0m\u001b[36mhistory\u001b[0m\u001b[2m - ge\u00e7mi\u015f  |  \u001b[0m\u001b[36mreset\u001b[0m\u001b[2m - sohbeti s\u0131f\u0131rla\u001b[0m");
        System.out.println();
    }

    public static void printHelp() {
        System.out.println();
        System.out.println("\u001b[1m\u001b[33m  \u2500\u2500\u2500 Kullan\u0131labilir Komutlar \u2500\u2500\u2500\u001b[0m");
        System.out.println("\u001b[32m  exit / quit\u001b[0m    : Uygulamadan \u00e7\u0131k");
        System.out.println("\u001b[32m  clear\u001b[0m          : Ekran\u0131 temizle");
        System.out.println("\u001b[32m  reset\u001b[0m          : Sohbet ge\u00e7mi\u015fini s\u0131f\u0131rla");
        System.out.println("\u001b[32m  history\u001b[0m        : Sohbet ge\u00e7mi\u015fini g\u00f6ster");
        System.out.println("\u001b[32m  model <isim>\u001b[0m   : Modeli de\u011fi\u015ftir (\u00f6rn: claude-opus-4-5)");
        System.out.println("\u001b[32m  tokens\u001b[0m         : Kullan\u0131lan token say\u0131s\u0131n\u0131 g\u00f6ster");
        System.out.println();
        System.out.println("\u001b[1m\u001b[33m  \u2500\u2500\u2500 Sahip Oldu\u011fu Ara\u00e7lar \u2500\u2500\u2500\u001b[0m");
        System.out.println("\u001b[36m  read_file\u001b[0m      : Dosya i\u00e7eri\u011fini oku");
        System.out.println("\u001b[36m  write_file\u001b[0m      : Dosyaya yaz (olu\u015ftur/\u00fczerine yaz)");
        System.out.println("\u001b[36m  edit_file\u001b[0m       : Dosyada belirli sat\u0131rlar\u0131 de\u011fi\u015ftir");
        System.out.println("\u001b[36m  delete_file\u001b[0m     : Dosyay\u0131 sil");
        System.out.println("\u001b[36m  list_directory\u001b[0m  : Dizin i\u00e7eri\u011fini listele");
        System.out.println("\u001b[36m  search_files\u001b[0m    : Dosyalarda metin ara");
        System.out.println("\u001b[36m  execute_command\u001b[0m  : Kabuk komutu \u00e7al\u0131\u015ft\u0131r");
        System.out.println("\u001b[36m  make_directory\u001b[0m  : Klas\u00f6r olu\u015ftur");
        System.out.println("\u001b[36m  move_file\u001b[0m       : Dosya ta\u015f\u0131/yeniden adland\u0131r");
        System.out.println("\u001b[36m  file_info\u001b[0m       : Dosya bilgilerini g\u00f6r\u00fcnt\u00fcle");
        System.out.println();
    }

    public static void printUserPrompt() {
        System.out.print("\u001b[1m\u001b[32m  Siz\u001b[0m\u001b[1m\u001b[37m \u276f \u001b[0m");
    }

    public static void printAssistantHeader() {
        System.out.println();
        System.out.println("\u001b[1m\u001b[34m  Claude\u001b[0m\u001b[1m\u001b[37m \u276f\u001b[0m");
    }

    public static void printToolUse(String toolName, String toolId) {
        System.out.println("\u001b[1m\u001b[35m  \u2699  Ara\u00e7 \u00e7a\u011fr\u0131s\u0131: \u001b[0m\u001b[33m" + toolName + "\u001b[0m\u001b[2m [" + toolId.substring(0, Math.min(8, toolId.length())) + "...]\u001b[0m");
    }

    public static void printToolResult(String toolName, boolean success) {
        if (success) {
            System.out.println("\u001b[32m  \u2713  " + toolName + " tamamland\u0131\u001b[0m");
        } else {
            System.out.println("\u001b[31m  \u2717  " + toolName + " ba\u015far\u0131s\u0131z\u001b[0m");
        }
    }

    public static void printError(String message) {
        System.out.println("\u001b[31m  \u2717  Hata: " + message + RESET);
    }

    public static void printInfo(String message) {
        System.out.println("\u001b[2m  \u2139  " + message + RESET);
    }

    public static void printSeparator() {
        System.out.println("\u001b[2m  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u001b[0m");
    }

    public static void printTokenUsage(int inputTokens, int outputTokens, int totalTokens) {
        System.out.println("\u001b[2m  Tokenlar \u2014 Girdi: " + inputTokens + "  \u00c7\u0131kt\u0131: " + outputTokens + "  Toplam: " + totalTokens + RESET);
    }
}

