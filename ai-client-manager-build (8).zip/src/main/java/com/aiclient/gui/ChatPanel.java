/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import com.aiclient.gui.ChatMessage;
import com.aiclient.gui.MessageBubble;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

public class ChatPanel
extends JPanel {
    private final JPanel messagesContainer;
    private final JScrollPane scrollPane;
    private final List<MessageBubble> bubbles = new ArrayList<MessageBubble>();
    private MessageBubble streamingBubble;

    public ChatPanel() {
        this.setLayout(new BorderLayout());
        this.messagesContainer = new JPanel();
        this.messagesContainer.setLayout(new BoxLayout(this.messagesContainer, 1));
        this.messagesContainer.setOpaque(false);
        this.messagesContainer.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        this.scrollPane = new JScrollPane(this.messagesContainer, 20, 31);
        this.scrollPane.setBorder(null);
        this.scrollPane.getViewport().setOpaque(false);
        this.scrollPane.setOpaque(false);
        this.scrollPane.getVerticalScrollBar().setUnitIncrement(20);
        this.add((Component)this.scrollPane, "Center");
        this.showWelcome();
    }

    private void showWelcome() {
        ChatMessage welcome = new ChatMessage(ChatMessage.Type.SYSTEM, "Merhaba! Ben Claude destekli AI Client Manager.\n\nDosya sistemi i\u015flemleri, komut \u00e7al\u0131\u015ft\u0131rma ve \u00e7ok daha fazlas\u0131 i\u00e7in buraday\u0131m.\nBa\u015flamak i\u00e7in sa\u011f \u00fcstteki \u2699 Ayarlar butonuna t\u0131klayarak API anahtar\u0131n\u0131z\u0131 girin.");
        this.addMessage(welcome);
    }

    public void clearWelcome() {
        this.messagesContainer.removeAll();
        this.bubbles.clear();
        this.streamingBubble = null;
        this.revalidate();
        this.repaint();
    }

    public void addMessage(ChatMessage message) {
        MessageBubble bubble = new MessageBubble(message);
        this.bubbles.add(bubble);
        bubble.setAlignmentX(0.0f);
        this.messagesContainer.add(bubble);
        this.messagesContainer.add(Box.createRigidArea(new Dimension(0, 6)));
        this.revalidate();
        this.repaint();
        this.scrollToBottom();
    }

    public MessageBubble startStreamingMessage() {
        ChatMessage msg = new ChatMessage(ChatMessage.Type.ASSISTANT, "");
        this.streamingBubble = new MessageBubble(msg);
        this.streamingBubble.setAlignmentX(0.0f);
        this.messagesContainer.add(this.streamingBubble);
        this.messagesContainer.add(Box.createRigidArea(new Dimension(0, 6)));
        this.bubbles.add(this.streamingBubble);
        this.revalidate();
        this.repaint();
        return this.streamingBubble;
    }

    public MessageBubble getStreamingBubble() {
        return this.streamingBubble;
    }

    public void finalizeStreamingMessage() {
        this.streamingBubble = null;
        this.revalidate();
        this.repaint();
        this.scrollToBottom();
    }

    public void clearMessages() {
        this.messagesContainer.removeAll();
        this.bubbles.clear();
        this.streamingBubble = null;
        this.revalidate();
        this.repaint();
    }

    public void scrollToBottom() {
        SwingUtilities.invokeLater(() -> {
            JScrollBar vert = this.scrollPane.getVerticalScrollBar();
            vert.setValue(vert.getMaximum());
        });
    }
}

