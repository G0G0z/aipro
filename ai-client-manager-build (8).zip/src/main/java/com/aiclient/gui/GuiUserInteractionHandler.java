package com.aiclient.gui;

import com.aiclient.tools.UserInteractionHandler;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

public class GuiUserInteractionHandler implements UserInteractionHandler {

    private final Frame parent;

    public GuiUserInteractionHandler(Frame parent) {
        this.parent = parent;
    }

    @Override
    public List<String> ask(String header, String question, List<Option> options, boolean multiSelect) throws Exception {
        final List<String>[] resultHolder = new List[]{new ArrayList<String>()};
        Runnable showDialog = () -> resultHolder[0] = this.showDialogBlocking(header, question, options, multiSelect);
        if (SwingUtilities.isEventDispatchThread()) {
            showDialog.run();
        } else {
            SwingUtilities.invokeAndWait(showDialog);
        }
        return resultHolder[0];
    }

    private List<String> showDialogBlocking(String header, String question, List<Option> options, boolean multiSelect) {
        Color bg = new Color(1448738);
        Color fg = new Color(15264502);
        Color dim = new Color(0x9E9E9E);

        JDialog dialog = new JDialog(this.parent, header != null && !header.isBlank() ? header : "Soru", true);
        dialog.getContentPane().setBackground(bg);
        dialog.setLayout(new BorderLayout(0, 0));

        JPanel content = new JPanel();
        content.setBackground(bg);
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setBorder(BorderFactory.createEmptyBorder(18, 20, 18, 20));

        JLabel questionLabel = new JLabel("<html><body style='width: 380px'>" + escape(question) + "</body></html>");
        questionLabel.setForeground(fg);
        questionLabel.setFont(questionLabel.getFont().deriveFont(Font.BOLD, 15f));
        questionLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(questionLabel);
        content.add(javax.swing.Box.createRigidArea(new Dimension(0, 14)));

        List<AbstractButton> buttons = new ArrayList<AbstractButton>();
        ButtonGroup group = multiSelect ? null : new ButtonGroup();
        for (Option opt : options) {
            AbstractButton btn = multiSelect ? new JCheckBox(opt.label) : new JRadioButton(opt.label);
            btn.setForeground(fg);
            btn.setBackground(bg);
            btn.setFocusPainted(false);
            btn.setAlignmentX(Component.LEFT_ALIGNMENT);
            if (group != null) {
                group.add(btn);
            }
            buttons.add(btn);
            content.add(btn);
            if (opt.description != null && !opt.description.isBlank()) {
                JLabel desc = new JLabel("<html><body style='width: 360px'>" + escape(opt.description) + "</body></html>");
                desc.setForeground(dim);
                desc.setFont(desc.getFont().deriveFont(11f));
                desc.setBorder(BorderFactory.createEmptyBorder(0, 26, 6, 0));
                desc.setAlignmentX(Component.LEFT_ALIGNMENT);
                content.add(desc);
            }
        }

        content.add(javax.swing.Box.createRigidArea(new Dimension(0, 8)));
        JLabel otherLabel = new JLabel("Di\u011fer (serbest metin):");
        otherLabel.setForeground(dim);
        otherLabel.setFont(otherLabel.getFont().deriveFont(11f));
        otherLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(otherLabel);
        JTextField otherField = new JTextField();
        otherField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 28));
        otherField.setAlignmentX(Component.LEFT_ALIGNMENT);
        content.add(otherField);

        JScrollPane scroll = new JScrollPane(content);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(bg);
        scroll.setPreferredSize(new Dimension(440, Math.min(520, 140 + options.size() * 50)));

        JPanel buttonRow = new JPanel();
        buttonRow.setBackground(bg);
        JButton okBtn = new JButton("Tamam");
        buttonRow.add(okBtn);

        dialog.add(scroll, BorderLayout.CENTER);
        dialog.add(buttonRow, BorderLayout.SOUTH);

        List<String> selected = new ArrayList<String>();
        okBtn.addActionListener(e -> {
            for (int i = 0; i < buttons.size(); i++) {
                if (buttons.get(i).isSelected()) {
                    selected.add(options.get(i).label);
                }
            }
            String other = otherField.getText() != null ? otherField.getText().trim() : "";
            if (!other.isEmpty()) {
                selected.add(other);
            }
            dialog.dispose();
        });

        dialog.pack();
        dialog.setLocationRelativeTo(this.parent);
        dialog.setResizable(true);
        dialog.setVisible(true);

        return selected;
    }

    private static String escape(String s) {
        if (s == null) {
            return "";
        }
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
    }
}
