/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import com.aiclient.gui.ChatMessage;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.OpenOption;
import java.nio.file.Path;
import java.nio.file.attribute.FileAttribute;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class ConversationHistory {
    private static final String HISTORY_DIR = System.getProperty("user.home") + File.separator + ".ai-client-manager" + File.separator + "conversations";
    private String id = ConversationHistory.generateId();
    private String title = "Yeni Sohbet";
    private LocalDateTime createdAt = LocalDateTime.now();
    private LocalDateTime updatedAt = LocalDateTime.now();
    private List<ChatMessage> messages = new ArrayList<ChatMessage>();

    private static String generateId() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS"));
    }

    public void addMessage(ChatMessage msg) {
        this.messages.add(msg);
        this.updatedAt = LocalDateTime.now();
        if (this.title.equals("Yeni Sohbet") && msg.getType() == ChatMessage.Type.USER) {
            String content = msg.getContent();
            this.title = content.length() > 50 ? content.substring(0, 50) + "..." : content;
        }
    }

    public void save() {
        try {
            Files.createDirectories(Path.of(HISTORY_DIR, new String[0]), new FileAttribute[0]);
            JsonObject obj = new JsonObject();
            obj.addProperty("id", this.id);
            obj.addProperty("title", this.title);
            obj.addProperty("createdAt", this.createdAt.toString());
            obj.addProperty("updatedAt", this.updatedAt.toString());
            JsonArray msgs = new JsonArray();
            for (ChatMessage m : this.messages) {
                JsonObject mo = new JsonObject();
                mo.addProperty("type", m.getType().name());
                mo.addProperty("content", m.getContent());
                mo.addProperty("timestamp", m.getTimestamp().toString());
                if (m.getToolName() != null) {
                    mo.addProperty("toolName", m.getToolName());
                }
                mo.addProperty("toolSuccess", m.isToolSuccess());
                msgs.add(mo);
            }
            obj.add("messages", msgs);
            String json = new GsonBuilder().setPrettyPrinting().create().toJson(obj);
            Files.writeString(Path.of(HISTORY_DIR, this.id + ".json"), (CharSequence)json, new OpenOption[0]);
        }
        catch (Exception e) {
            System.err.println("Ge\u00e7mi\u015f kaydedilemedi: " + e.getMessage());
        }
    }

    public static List<ConversationHistory> loadAll() {
        ArrayList<ConversationHistory> list = new ArrayList<ConversationHistory>();
        try {
            Path dir = Path.of(HISTORY_DIR, new String[0]);
            if (!Files.exists(dir, new LinkOption[0])) {
                return list;
            }
            try (Stream<Path> stream = Files.list(dir);){
                stream.filter(p -> p.toString().endsWith(".json")).sorted(Comparator.reverseOrder()).forEach(p -> {
                    ConversationHistory h = ConversationHistory.loadFromFile(p);
                    if (h != null) {
                        list.add(h);
                    }
                });
            }
        }
        catch (Exception e) {
            System.err.println("Ge\u00e7mi\u015f y\u00fcklenemedi: " + e.getMessage());
        }
        return list;
    }

    private static ConversationHistory loadFromFile(Path path) {
        try {
            String json = Files.readString(path);
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            ConversationHistory h = new ConversationHistory();
            h.id = obj.get("id").getAsString();
            h.title = obj.get("title").getAsString();
            h.createdAt = LocalDateTime.parse(obj.get("createdAt").getAsString());
            h.updatedAt = LocalDateTime.parse(obj.get("updatedAt").getAsString());
            h.messages = new ArrayList<ChatMessage>();
            JsonArray msgs = obj.getAsJsonArray("messages");
            for (JsonElement e : msgs) {
                JsonObject mo = e.getAsJsonObject();
                ChatMessage.Type type = ChatMessage.Type.valueOf(mo.get("type").getAsString());
                String content = mo.get("content").getAsString();
                String toolName = mo.has("toolName") ? mo.get("toolName").getAsString() : null;
                boolean toolSuccess = mo.has("toolSuccess") && mo.get("toolSuccess").getAsBoolean();
                ChatMessage msg = new ChatMessage(type, content, toolName, toolSuccess);
                h.messages.add(msg);
            }
            return h;
        }
        catch (Exception e) {
            return null;
        }
    }

    public void delete() {
        try {
            Files.deleteIfExists(Path.of(HISTORY_DIR, this.id + ".json"));
        }
        catch (Exception exception) {
            // empty catch block
        }
    }

    public String getId() {
        return this.id;
    }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public LocalDateTime getCreatedAt() {
        return this.createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return this.updatedAt;
    }

    public List<ChatMessage> getMessages() {
        return this.messages;
    }

    public void clearMessages() {
        this.messages.clear();
    }

    public String toString() {
        return this.title;
    }
}

