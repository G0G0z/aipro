/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ChatMessage {
    private final Type type;
    private String content;
    private final LocalDateTime timestamp;
    private String toolName;
    private boolean toolSuccess;

    public ChatMessage(Type type, String content) {
        this.type = type;
        this.content = content;
        this.timestamp = LocalDateTime.now();
    }

    public ChatMessage(Type type, String content, String toolName, boolean toolSuccess) {
        this(type, content);
        this.toolName = toolName;
        this.toolSuccess = toolSuccess;
    }

    public Type getType() {
        return this.type;
    }

    public String getContent() {
        return this.content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public LocalDateTime getTimestamp() {
        return this.timestamp;
    }

    public String getToolName() {
        return this.toolName;
    }

    public boolean isToolSuccess() {
        return this.toolSuccess;
    }

    public String getFormattedTime() {
        return this.timestamp.format(DateTimeFormatter.ofPattern("HH:mm:ss"));
    }

    public static enum Type {
        USER,
        ASSISTANT,
        TOOL_USE,
        TOOL_RESULT,
        SYSTEM,
        ERROR;

    }
}

