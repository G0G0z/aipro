/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import com.aiclient.gui.ChatMessage;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JTextArea;
import javax.swing.UIManager;

public class MessageBubble
extends JPanel {
    private static final Color USER_BG = new Color(2976335);
    private static final Color ASSISTANT_BG = new Color(1976890);
    private static final Color TOOL_USE_BG = new Color(0x2A2000);
    private static final Color TOOL_OK_BG = new Color(1716256);
    private static final Color TOOL_ERR_BG = new Color(0x3A1A1A);
    private static final Color SYSTEM_BG = new Color(1710638);
    private static final Color ERROR_BG = new Color(4853776);
    private static final Color TEXT_COLOR = new Color(15264502);
    private static final Color DIM_COLOR = new Color(0x9E9E9E);
    private static final Color TIME_COLOR = new Color(0x757575);
    private final ChatMessage message;
    private JTextArea textArea;

    public MessageBubble(ChatMessage message) {
        this.message = message;
        this.setLayout(new BorderLayout(6, 4));
        this.setOpaque(false);
        this.buildContent();
    }

    private void buildContent() {
        Object prefix;
        Color bg;
        Color prefixColor = switch (this.message.getType()) {
            case USER -> {
                bg = USER_BG;
                prefix = "\ud83d\udc64  Siz";
                yield new Color(6942894);
            }
            case ASSISTANT -> {
                bg = ASSISTANT_BG;
                prefix = "\ud83e\udd16  Claude";
                yield new Color(8565247);
            }
            case TOOL_USE -> {
                bg = TOOL_USE_BG;
                prefix = "\u2699  Ara\u00e7 \u00e7a\u011fr\u0131s\u0131: " + this.message.getToolName();
                yield new Color(16766287);
            }
            case TOOL_RESULT -> {
                bg = this.message.isToolSuccess() ? TOOL_OK_BG : TOOL_ERR_BG;
                prefix = (this.message.isToolSuccess() ? "\u2713  " : "\u2717  ") + this.message.getToolName();
                yield this.message.isToolSuccess() ? new Color(6942894) : new Color(0xFF5252);
            }
            case ERROR -> {
                bg = ERROR_BG;
                prefix = "\u2717  Hata";
                yield new Color(0xFF5252);
            }
            default -> {
                bg = SYSTEM_BG;
                prefix = "\u2139  Sistem";
                yield new Color(11583173);
            }
        };
        JPanel bubble = new JPanel(new BorderLayout(0, 4)){

            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D)g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fill(new RoundRectangle2D.Float(0.0f, 0.0f, this.getWidth(), this.getHeight(), 12.0f, 12.0f));
                g2.dispose();
            }
        };
        bubble.setOpaque(false);
        bubble.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        JLabel prefixLabel = new JLabel((String)prefix);
        prefixLabel.setForeground(prefixColor);
        prefixLabel.setFont(prefixLabel.getFont().deriveFont(1, 12.0f));
        header.add((Component)prefixLabel, "West");
        JLabel timeLabel = new JLabel(this.message.getFormattedTime());
        timeLabel.setForeground(TIME_COLOR);
        timeLabel.setFont(timeLabel.getFont().deriveFont(10.0f));
        header.add((Component)timeLabel, "East");
        bubble.add((Component)header, "North");
        this.textArea = new JTextArea(this.message.getContent() != null ? this.message.getContent() : "");
        this.textArea.setEditable(false);
        this.textArea.setLineWrap(true);
        this.textArea.setWrapStyleWord(true);
        this.textArea.setOpaque(false);
        this.textArea.setForeground(TEXT_COLOR);
        this.textArea.setFont(this.getContentFont(this.message.getType()));
        this.textArea.setBorder(null);
        this.textArea.setCursor(Cursor.getDefaultCursor());
        boolean isBubbleType = this.message.getType() == ChatMessage.Type.USER || this.message.getType() == ChatMessage.Type.ASSISTANT;
        int targetWidth = isBubbleType ? 760 : 660;
        this.textArea.setSize(new Dimension(targetWidth, Short.MAX_VALUE));
        Dimension wrapped = this.textArea.getPreferredSize();
        this.textArea.setPreferredSize(new Dimension(targetWidth, wrapped.height));
        JPopupMenu popup = new JPopupMenu();
        JMenuItem copy = new JMenuItem("Kopyala");
        copy.addActionListener(e -> {
            this.textArea.selectAll();
            this.textArea.copy();
            this.textArea.select(0, 0);
        });
        popup.add(copy);
        this.textArea.setComponentPopupMenu(popup);
        bubble.add((Component)this.textArea, "Center");
        JPanel outer = new JPanel(new BorderLayout());
        outer.setOpaque(false);
        JPanel row = new JPanel(new FlowLayout(this.message.getType() == ChatMessage.Type.USER ? 2 : 0, 8, 4));
        row.setOpaque(false);
        bubble.setMaximumSize(null);
        bubble.setPreferredSize(null);
        row.add(bubble);
        outer.add((Component)row, "Center");
        outer.setMaximumSize(new Dimension(920, Integer.MAX_VALUE));
        JPanel centerWrap = new JPanel();
        centerWrap.setOpaque(false);
        centerWrap.setLayout(new BoxLayout(centerWrap, BoxLayout.X_AXIS));
        centerWrap.add(Box.createHorizontalGlue());
        centerWrap.add(outer);
        centerWrap.add(Box.createHorizontalGlue());
        this.add((Component)centerWrap, "Center");
    }

    private Font getContentFont(ChatMessage.Type type) {
        Font base = UIManager.getFont("Label.font");
        if (base == null) {
            base = new Font("SansSerif", 0, 14);
        }
        return switch (type) {
            case TOOL_USE, TOOL_RESULT -> new Font("Monospaced", 0, 12);
            case USER -> base.deriveFont(14.0f);
            default -> base.deriveFont(14.0f);
        };
    }

    public void appendText(String text) {
        if (this.textArea != null) {
            this.textArea.append(text);
        }
    }

    public void setText(String text) {
        if (this.textArea != null) {
            this.textArea.setText(text);
        }
    }
}

