/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import com.aiclient.AnthropicClient;
import com.aiclient.gui.AppSettings;
import com.aiclient.gui.ChatMessage;
import com.aiclient.tools.Tool;
import com.aiclient.tools.ToolRegistry;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class GUIAgent {
    private final AnthropicClient client;
    private final ToolRegistry toolRegistry;
    private final List<JsonObject> conversationHistory;
    private String currentModel;
    private String systemPrompt;
    private int maxTokens;
    private int maxToolIterations;
    private int totalInputTokens;
    private int totalOutputTokens;
    private final Gson gson;
    private Consumer<String> onTextChunk;
    private Consumer<String[]> onToolUse;
    private Consumer<String[]> onToolResult;
    private Runnable onDone;
    private Consumer<String> onError;
    private volatile boolean cancelled = false;

    public GUIAgent(AnthropicClient client, AppSettings settings) {
        this.client = client;
        this.toolRegistry = new ToolRegistry();
        this.conversationHistory = new ArrayList<JsonObject>();
        this.currentModel = settings.getModel();
        this.systemPrompt = settings.getSystemPrompt();
        this.maxTokens = settings.getMaxTokens();
        this.maxToolIterations = settings.getMaxToolIterations();
        this.gson = new GsonBuilder().create();
    }

    public void setCallbacks(Consumer<String> onTextChunk, Consumer<String[]> onToolUse, Consumer<String[]> onToolResult, Runnable onDone, Consumer<String> onError) {
        this.onTextChunk = onTextChunk;
        this.onToolUse = onToolUse;
        this.onToolResult = onToolResult;
        this.onDone = onDone;
        this.onError = onError;
    }

    public void cancel() {
        this.cancelled = true;
    }

    public void resetCancel() {
        this.cancelled = false;
    }

    public void chat(String userMessage) {
        block13: {
            this.cancelled = false;
            JsonObject userMsg = new JsonObject();
            userMsg.addProperty("role", "user");
            userMsg.addProperty("content", userMessage);
            this.conversationHistory.add(userMsg);
            try {
                int iterations = 0;
                StringBuilder fullResponse = new StringBuilder();
                while (iterations < this.maxToolIterations && !this.cancelled) {
                    ++iterations;
                    AnthropicClient.ApiResponse response = this.client.sendMessages(this.currentModel, this.systemPrompt, this.conversationHistory, this.toolRegistry.toApiFormat(), this.maxTokens);
                    this.totalInputTokens += response.usage().inputTokens();
                    this.totalOutputTokens += response.usage().outputTokens();
                    JsonObject assistantMsg = new JsonObject();
                    assistantMsg.addProperty("role", "assistant");
                    assistantMsg.add("content", response.content());
                    this.conversationHistory.add(assistantMsg);
                    for (JsonElement elem : response.content()) {
                        String text;
                        if (elem == null || !elem.isJsonObject()) {
                            if (elem != null && elem.isJsonPrimitive()) {
                                text = elem.getAsString();
                                if (!text.isBlank()) {
                                    fullResponse.append(text);
                                    if (this.onTextChunk != null) {
                                        this.onTextChunk.accept(text);
                                    }
                                }
                            }
                            continue;
                        }
                        JsonObject block = elem.getAsJsonObject();
                        String type = block.has("type") ? block.get("type").getAsString() : "";
                        if (!"text".equals(type) || !block.has("text") || (text = block.get("text").getAsString()).isBlank()) continue;
                        fullResponse.append(text);
                        if (this.onTextChunk == null) continue;
                        this.onTextChunk.accept(text);
                    }
                    if (this.cancelled) break;
                    String stopReason = response.stopReason();
                    if ("max_tokens".equals(stopReason)) {
                        JsonObject continueMsg = new JsonObject();
                        continueMsg.addProperty("role", "user");
                        continueMsg.addProperty("content", "Devam et (yanıtın kesildi, kaldığın yerden devam et).");
                        this.conversationHistory.add(continueMsg);
                        continue;
                    }
                    if (!"tool_use".equals(stopReason)) break;
                    ArrayList<JsonObject> toolResults = new ArrayList<JsonObject>();
                    for (JsonElement elem3 : response.content()) {
                        Object toolResult;
                        JsonObject toolInput;
                        if (elem3 == null || !elem3.isJsonObject()) {
                            continue;
                        }
                        JsonObject block = elem3.getAsJsonObject();
                        if (!block.has("type") || !"tool_use".equals(block.get("type").getAsString())) continue;
                        String toolId = block.get("id").getAsString();
                        String toolName = block.get("name").getAsString();
                        JsonObject jsonObject = toolInput = block.has("input") && block.get("input").isJsonObject() ? block.getAsJsonObject("input") : new JsonObject();
                        if (this.onToolUse != null) {
                            this.onToolUse.accept(new String[]{toolName, toolId});
                        }
                        boolean success = true;
                        try {
                            if (this.cancelled) break;
                            Tool tool = this.toolRegistry.get(toolName);
                            if (tool == null) {
                                toolResult = "HATA: Bilinmeyen ara\u00e7: " + toolName;
                                success = false;
                            } else {
                                toolResult = tool.execute(toolInput);
                            }
                        }
                        catch (Exception e) {
                            toolResult = "HATA: " + e.getMessage();
                            success = false;
                        }
                        if (this.onToolResult != null) {
                            this.onToolResult.accept(new String[]{toolName, String.valueOf(success), String.valueOf(toolResult)});
                        }
                        JsonObject resultContent = new JsonObject();
                        resultContent.addProperty("type", "tool_result");
                        resultContent.addProperty("tool_use_id", toolId);
                        resultContent.addProperty("content", (String)toolResult);
                        toolResults.add(resultContent);
                    }
                    if (toolResults.isEmpty() || this.cancelled) continue;
                    JsonObject toolResultMsg = new JsonObject();
                    toolResultMsg.addProperty("role", "user");
                    JsonArray contentArray = new JsonArray();
                    for (JsonObject r : toolResults) {
                        contentArray.add(r);
                    }
                    toolResultMsg.add("content", contentArray);
                    this.conversationHistory.add(toolResultMsg);
                }
                if (this.onDone != null) {
                    this.onDone.run();
                }
            }
            catch (Exception e) {
                if (this.onError == null) break block13;
                this.onError.accept(e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName());
            }
        }
    }

    public void resetHistory() {
        this.conversationHistory.clear();
        this.totalInputTokens = 0;
        this.totalOutputTokens = 0;
    }

    public void loadHistory(List<JsonObject> history) {
        this.conversationHistory.clear();
        if (history != null) {
            this.conversationHistory.addAll(history);
        }
    }

    public void rebuildHistoryFromMessages(List<ChatMessage> messages) {
        this.conversationHistory.clear();
        this.totalInputTokens = 0;
        this.totalOutputTokens = 0;
        for (ChatMessage msg : messages) {
            JsonObject o;
            if (msg.getType() == ChatMessage.Type.USER) {
                o = new JsonObject();
                o.addProperty("role", "user");
                o.addProperty("content", msg.getContent() != null ? msg.getContent() : "");
                this.conversationHistory.add(o);
                continue;
            }
            if (msg.getType() != ChatMessage.Type.ASSISTANT) continue;
            o = new JsonObject();
            o.addProperty("role", "assistant");
            JsonArray contentArr = new JsonArray();
            JsonObject textBlock = new JsonObject();
            textBlock.addProperty("type", "text");
            textBlock.addProperty("text", msg.getContent() != null ? msg.getContent() : "");
            contentArr.add(textBlock);
            o.add("content", contentArr);
            this.conversationHistory.add(o);
        }
    }

    public void setModel(String model) {
        this.currentModel = model;
    }

    public String getModel() {
        return this.currentModel;
    }

    public void setSystemPrompt(String sp) {
        this.systemPrompt = sp;
    }

    public void setMaxTokens(int mt) {
        this.maxTokens = mt;
    }

    public void setMaxToolIterations(int mti) {
        this.maxToolIterations = mti;
    }

    public int getTotalInputTokens() {
        return this.totalInputTokens;
    }

    public int getTotalOutputTokens() {
        return this.totalOutputTokens;
    }

    public int getTotalTokens() {
        return this.totalInputTokens + this.totalOutputTokens;
    }

    public int getHistorySize() {
        return this.conversationHistory.size();
    }

    public AnthropicClient getClient() {
        return this.client;
    }
}

