/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import java.awt.Color;
import java.awt.datatransfer.DataFlavor;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import javax.swing.JComponent;
import javax.swing.TransferHandler;

public class FileDropHandler
extends TransferHandler {
    private static final long MAX_TEXT_SIZE = 500000L;
    private static final Set<String> TEXT_EXTENSIONS = Set.of("txt", "md", "java", "py", "js", "ts", "jsx", "tsx", "json", "xml", "yaml", "yml", "toml", "ini", "cfg", "conf", "properties", "env", "html", "htm", "css", "scss", "sql", "sh", "bat", "cmd", "ps1", "c", "cpp", "h", "hpp", "cs", "go", "rs", "rb", "php", "swift", "kt", "gradle", "log", "csv", "gitignore", "dockerfile", "makefile", "readme", "license", "changelog", "r", "m", "tex");
    private final Consumer<String> onFileDrop;
    private final JComponent dropTarget;
    private Color originalBg;
    private static final Color DRAG_OVER_COLOR = new Color(1718876);

    public FileDropHandler(JComponent dropTarget, Consumer<String> onFileDrop) {
        this.dropTarget = dropTarget;
        this.onFileDrop = onFileDrop;
    }

    @Override
    public boolean canImport(TransferHandler.TransferSupport support) {
        boolean can = support.isDataFlavorSupported(DataFlavor.javaFileListFlavor);
        if (can) {
            if (this.originalBg == null) {
                this.originalBg = this.dropTarget.getBackground();
            }
            this.dropTarget.setBackground(DRAG_OVER_COLOR);
            this.dropTarget.repaint();
        }
        return can;
    }

    @Override
    public boolean importData(TransferHandler.TransferSupport support) {
        if (this.originalBg != null) {
            this.dropTarget.setBackground(this.originalBg);
            this.dropTarget.repaint();
        }
        if (!this.canImport(support)) {
            return false;
        }
        try {
            List<File> files = (List<File>)support.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
            StringBuilder message = new StringBuilder();
            for (File file : files) {
                if (file.isDirectory()) {
                    message.append(this.buildDirectoryInfo(file));
                } else {
                    message.append(this.buildFileInfo(file));
                }
                if (files.size() <= 1) continue;
                message.append("\n\n---\n\n");
            }
            if (this.onFileDrop != null && !message.isEmpty()) {
                this.onFileDrop.accept(message.toString().trim());
            }
            return true;
        }
        catch (Exception e) {
            if (this.onFileDrop != null) {
                this.onFileDrop.accept("[Dosya okunamad\u0131: " + e.getMessage() + "]");
            }
            return false;
        }
    }

    private String buildFileInfo(File file) throws IOException {
        String name = file.getName();
        String ext = this.getExtension(name).toLowerCase();
        long size = file.length();
        StringBuilder sb = new StringBuilder();
        sb.append("\ud83d\udcce Dosya: ").append(file.getAbsolutePath()).append("\n");
        sb.append("Boyut: ").append(this.formatSize(size)).append("\n");
        if (this.isTextFile(ext, size)) {
            Object content = Files.readString(file.toPath());
            if ((long)((String)content).length() > 500000L) {
                content = ((String)content).substring(0, 500000) + "\n... (dosya k\u0131salt\u0131ld\u0131)";
            }
            int lineCount = ((String)content).split("\n", -1).length;
            sb.append("Sat\u0131r: ").append(lineCount).append("\n");
            sb.append("\u2500".repeat(50)).append("\n");
            sb.append((String)content);
        } else {
            sb.append("(Binary dosya \u2014 i\u00e7erik g\u00f6sterilemiyor)\n");
            sb.append("Bu dosyay\u0131 i\u015flememi ister misin?");
        }
        return sb.toString();
    }

    private String buildDirectoryInfo(File dir) {
        StringBuilder sb = new StringBuilder();
        sb.append("\ud83d\udcc1 Klas\u00f6r: ").append(dir.getAbsolutePath()).append("\n");
        File[] files = dir.listFiles();
        if (files == null || files.length == 0) {
            sb.append("(Klas\u00f6r bo\u015f)");
            return sb.toString();
        }
        Arrays.sort(files, Comparator.comparing(File::isDirectory).reversed().thenComparing(File::getName));
        sb.append("\u0130\u00e7erik (").append(files.length).append(" \u00f6\u011fe):\n");
        int shown = Math.min(files.length, 50);
        for (int i = 0; i < shown; ++i) {
            File f = files[i];
            sb.append(f.isDirectory() ? "  \ud83d\udcc1 " : "  \ud83d\udcc4 ").append(f.getName());
            if (!f.isDirectory()) {
                sb.append(" (").append(this.formatSize(f.length())).append(")");
            }
            sb.append("\n");
        }
        if (files.length > 50) {
            sb.append("  ... ve ").append(files.length - 50).append(" \u00f6\u011fe daha");
        }
        return sb.toString();
    }

    private boolean isTextFile(String ext, long size) {
        if (size > 1000000L) {
            return false;
        }
        if (ext.isEmpty()) {
            return size < 50000L;
        }
        return TEXT_EXTENSIONS.contains(ext);
    }

    private String getExtension(String name) {
        int dot = name.lastIndexOf(46);
        return dot >= 0 ? name.substring(dot + 1) : "";
    }

    private String formatSize(long bytes) {
        if (bytes < 1024L) {
            return bytes + " B";
        }
        if (bytes < 0x100000L) {
            return String.format("%.1f KB", (double)bytes / 1024.0);
        }
        return String.format("%.1f MB", (double)bytes / 1048576.0);
    }
}

