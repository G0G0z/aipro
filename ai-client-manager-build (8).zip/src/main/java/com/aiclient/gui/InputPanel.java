/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import com.aiclient.gui.FileDropHandler;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class InputPanel
extends JPanel {
    private final JTextArea inputArea;
    private final JButton sendButton;
    private final JButton cancelButton;
    private final JLabel statusLabel;
    private JLabel dropHint;
    private Consumer<String> onSend;
    private Runnable onCancel;
    private static final Color PANEL_BG = new Color(1711395);
    private static final Color INPUT_BG = new Color(2172461);
    private static final Color SEND_BG = new Color(2328118);
    private static final Color CANCEL_BG = new Color(9116186);
    private static final Color TEXT_FG = new Color(15264502);

    public InputPanel() {
        this.setLayout(new BorderLayout(0, 0));
        this.setBackground(PANEL_BG);
        this.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(3159613)), BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        this.statusLabel = new JLabel(" ");
        this.statusLabel.setForeground(new Color(0x9E9E9E));
        this.statusLabel.setFont(this.statusLabel.getFont().deriveFont(10.0f));
        this.add((Component)this.statusLabel, "North");
        this.inputArea = new JTextArea(3, 50);
        this.inputArea.setLineWrap(true);
        this.inputArea.setWrapStyleWord(true);
        this.inputArea.setBackground(INPUT_BG);
        this.inputArea.setForeground(TEXT_FG);
        this.inputArea.setCaretColor(TEXT_FG);
        this.inputArea.setFont(new Font("SansSerif", 0, 14));
        this.inputArea.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        this.inputArea.addKeyListener(new KeyAdapter(){

            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == 10 && !e.isShiftDown()) {
                    e.consume();
                    InputPanel.this.send();
                }
            }
        });
        FileDropHandler dropHandler = new FileDropHandler(this.inputArea, droppedText -> {
            String current = this.inputArea.getText();
            if (current.isBlank()) {
                this.inputArea.setText((String)droppedText);
            } else {
                this.inputArea.setText(current + "\n\n" + droppedText);
            }
            this.inputArea.setCaretPosition(this.inputArea.getText().length());
            this.dropHint.setVisible(false);
        });
        this.inputArea.setTransferHandler(dropHandler);
        JScrollPane inputScroll = new JScrollPane(this.inputArea);
        inputScroll.setBorder(BorderFactory.createLineBorder(new Color(3159613), 1));
        inputScroll.setBackground(INPUT_BG);
        inputScroll.getViewport().setBackground(INPUT_BG);
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 0, 6));
        buttonPanel.setBackground(PANEL_BG);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 0));
        this.sendButton = this.createButton("G\u00f6nder \u23ce", SEND_BG);
        this.sendButton.setToolTipText("G\u00f6nder (Enter)");
        this.sendButton.addActionListener(e -> this.send());
        this.cancelButton = this.createButton("Durdur \u2715", CANCEL_BG);
        this.cancelButton.setToolTipText("AI yan\u0131t\u0131n\u0131 durdur");
        this.cancelButton.setEnabled(false);
        this.cancelButton.addActionListener(e -> {
            if (this.onCancel != null) {
                this.onCancel.run();
            }
        });
        buttonPanel.add(this.sendButton);
        buttonPanel.add(this.cancelButton);
        JPanel center = new JPanel(new BorderLayout(8, 0));
        center.setBackground(PANEL_BG);
        center.setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));
        center.add((Component)inputScroll, "Center");
        center.add((Component)buttonPanel, "East");
        this.add((Component)center, "Center");
        JPanel hintBar = new JPanel(new BorderLayout());
        hintBar.setBackground(PANEL_BG);
        hintBar.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));
        JLabel hint = new JLabel("Enter: g\u00f6nder  |  Shift+Enter: yeni sat\u0131r  |  Sa\u011f t\u0131k: kopyala");
        hint.setForeground(new Color(0x616161));
        hint.setFont(hint.getFont().deriveFont(9.0f));
        hintBar.add((Component)hint, "West");
        this.dropHint = new JLabel("\ud83d\udcce Dosya veya klas\u00f6r b\u0131rakabilirsiniz");
        this.dropHint.setForeground(new Color(5227511));
        this.dropHint.setFont(this.dropHint.getFont().deriveFont(2, 9.0f));
        this.dropHint.setVisible(false);
        hintBar.add((Component)this.dropHint, "East");
        this.add((Component)hintBar, "South");
    }

    private JButton createButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 14, 8, 14));
        btn.setFont(btn.getFont().deriveFont(1, 12.0f));
        btn.setCursor(Cursor.getPredefinedCursor(12));
        return btn;
    }

    private void send() {
        String text = this.inputArea.getText().trim();
        if (text.isEmpty()) {
            return;
        }
        if (this.onSend != null) {
            this.inputArea.setText("");
            this.onSend.accept(text);
        }
    }

    public void setProcessing(boolean processing) {
        this.sendButton.setEnabled(!processing);
        this.cancelButton.setEnabled(processing);
        this.inputArea.setEnabled(!processing);
    }

    public void setStatus(String text) {
        this.statusLabel.setText(text);
    }

    public void setOnSend(Consumer<String> cb) {
        this.onSend = cb;
    }

    public void setOnCancel(Runnable cb) {
        this.onCancel = cb;
    }

    public void focus() {
        this.inputArea.requestFocusInWindow();
    }
}

