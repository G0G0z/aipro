/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import com.aiclient.gui.AppSettings;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.UIManager;

public class SettingsDialog
extends JDialog {
    private final AppSettings settings;
    private JTextField aerolinkKeyField;
    private JTextField aerolinkKeyField2;
    private JTextField anthropicKeyField;
    private JComboBox<String> modelCombo;
    private JTextArea systemPromptArea;
    private JSpinner maxTokensSpinner;
    private JSpinner maxIterationsSpinner;
    private JRadioButton aerolinkRadio;
    private JRadioButton anthropicRadio;
    private JTextField workingDirField;
    private boolean confirmed = false;
    private static final String[] MODELS = new String[]{"claude-sonnet-4-6", "claude-opus-4-5", "claude-haiku-3-5", "claude-3-5-sonnet-20241022", "claude-3-opus-20240229", "gpt-4o", "gpt-4o-mini"};

    public SettingsDialog(Frame parent, AppSettings settings) {
        super(parent, "\u2699  Ayarlar", true);
        this.settings = settings;
        this.buildUI();
        this.loadValues();
        this.pack();
        this.setMinimumSize(new Dimension(620, 600));
        this.setLocationRelativeTo(parent);
    }

    private void buildUI() {
        this.setLayout(new BorderLayout(0, 0));
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));
        tabs.addTab("\ud83d\udd11  API", this.buildApiTab());
        tabs.addTab("\ud83e\udd16  Model", this.buildModelTab());
        tabs.addTab("\ud83d\udcdd  Sistem Prompt", this.buildSystemPromptTab());
        tabs.addTab("\ud83d\udcc1  Genel", this.buildGeneralTab());
        this.add((Component)tabs, "Center");
        this.add((Component)this.buildButtonBar(), "South");
    }

    private JPanel buildApiTab() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = 2;
        gc.insets = new Insets(4, 4, 4, 4);
        gc.gridx = 0;
        gc.gridy = 0;
        gc.gridwidth = 2;
        JPanel providerPanel = new JPanel(new FlowLayout(0, 12, 0));
        providerPanel.setBorder(BorderFactory.createTitledBorder("API Sa\u011flay\u0131c\u0131s\u0131"));
        ButtonGroup bg = new ButtonGroup();
        this.aerolinkRadio = new JRadioButton("Aerolink (capi.aerolink.lat)");
        this.anthropicRadio = new JRadioButton("Anthropic (api.anthropic.com)");
        bg.add(this.aerolinkRadio);
        bg.add(this.anthropicRadio);
        providerPanel.add(this.aerolinkRadio);
        providerPanel.add(this.anthropicRadio);
        p.add((Component)providerPanel, gc);
        gc.gridx = 0;
        gc.gridy = 1;
        gc.gridwidth = 1;
        gc.weightx = 0.0;
        p.add((Component)new JLabel("Aerolink API Key (1):"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        this.aerolinkKeyField = new JPasswordField(40);
        this.aerolinkKeyField.setToolTipText("aero_live_... format\u0131nda \u2014 birincil anahtar");
        p.add((Component)this.aerolinkKeyField, gc);
        gc.gridx = 0;
        gc.gridy = 2;
        gc.weightx = 0.0;
        p.add((Component)new JLabel("Aerolink API Key (2):"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        this.aerolinkKeyField2 = new JPasswordField(40);
        this.aerolinkKeyField2.setToolTipText("aero_live_... format\u0131nda \u2014 1. limit dolunca devreye girer");
        p.add((Component)this.aerolinkKeyField2, gc);
        gc.gridx = 0;
        gc.gridy = 3;
        gc.weightx = 0.0;
        p.add((Component)new JLabel("Anthropic API Key:"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        this.anthropicKeyField = new JPasswordField(40);
        this.anthropicKeyField.setToolTipText("sk-ant-... format\u0131nda");
        p.add((Component)this.anthropicKeyField, gc);
        gc.gridx = 0;
        gc.gridy = 4;
        gc.gridwidth = 2;
        JLabel hint = new JLabel("<html><small><i>\ud83d\udca1 1. Aerolink anahtar\u0131 limit doldu\u011funda otomatik olarak 2. anahtara ge\u00e7ilir.</i></small></html>");
        hint.setForeground(UIManager.getColor("Label.disabledForeground"));
        p.add((Component)hint, gc);
        gc.gridy = 5;
        gc.weighty = 1.0;
        p.add(Box.createVerticalGlue(), gc);
        return p;
    }

    private JPanel buildModelTab() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = 2;
        gc.insets = new Insets(6, 4, 6, 4);
        gc.gridx = 0;
        gc.gridy = 0;
        gc.weightx = 0.0;
        p.add((Component)new JLabel("Model:"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        this.modelCombo = new JComboBox<String>(MODELS);
        this.modelCombo.setEditable(true);
        this.modelCombo.setToolTipText("Modeli se\u00e7in veya do\u011frudan yaz\u0131n");
        p.add(this.modelCombo, gc);
        gc.gridx = 0;
        gc.gridy = 1;
        gc.weightx = 0.0;
        p.add((Component)new JLabel("Maks. Token:"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        this.maxTokensSpinner = new JSpinner(new SpinnerNumberModel(8096, 256, 100000, 256));
        p.add((Component)this.maxTokensSpinner, gc);
        gc.gridx = 0;
        gc.gridy = 2;
        gc.weightx = 0.0;
        p.add((Component)new JLabel("Maks. Ara\u00e7 D\u00f6ng\u00fcs\u00fc:"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        this.maxIterationsSpinner = new JSpinner(new SpinnerNumberModel(50, 1, 200, 5));
        p.add((Component)this.maxIterationsSpinner, gc);
        gc.gridx = 0;
        gc.gridy = 3;
        gc.gridwidth = 2;
        JLabel modelHint = new JLabel("<html><small><i>\ud83d\udca1 Model ad\u0131n\u0131 do\u011frudan yazabilirsiniz (\u00f6rn: claude-opus-4-5)</i></small></html>");
        modelHint.setForeground(UIManager.getColor("Label.disabledForeground"));
        p.add((Component)modelHint, gc);
        gc.gridy = 4;
        gc.weighty = 1.0;
        p.add(Box.createVerticalGlue(), gc);
        return p;
    }

    private JPanel buildSystemPromptTab() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));
        JPanel topBar = new JPanel(new FlowLayout(0, 6, 0));
        topBar.add(new JLabel("Sistem Promptu:"));
        JButton resetBtn = new JButton("Varsay\u0131lana S\u0131f\u0131rla");
        resetBtn.addActionListener(e -> this.systemPromptArea.setText(AppSettings.getDefaultSystemPrompt()));
        topBar.add(resetBtn);
        p.add((Component)topBar, "North");
        this.systemPromptArea = new JTextArea(10, 50);
        this.systemPromptArea.setLineWrap(true);
        this.systemPromptArea.setWrapStyleWord(true);
        this.systemPromptArea.setFont(new Font("Monospaced", 0, 12));
        p.add((Component)new JScrollPane(this.systemPromptArea), "Center");
        return p;
    }

    private JPanel buildGeneralTab() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = 2;
        gc.insets = new Insets(6, 4, 6, 4);
        gc.gridx = 0;
        gc.gridy = 0;
        gc.weightx = 0.0;
        p.add((Component)new JLabel("\u00c7al\u0131\u015fma Dizini:"), gc);
        gc.gridx = 1;
        gc.weightx = 1.0;
        this.workingDirField = new JTextField(30);
        p.add((Component)this.workingDirField, gc);
        gc.gridx = 2;
        gc.weightx = 0.0;
        JButton browseBtn = new JButton("G\u00f6zat...");
        browseBtn.addActionListener(e -> {
            JFileChooser fc = new JFileChooser(this.workingDirField.getText());
            fc.setFileSelectionMode(1);
            if (fc.showOpenDialog(this) == 0) {
                this.workingDirField.setText(fc.getSelectedFile().getAbsolutePath());
            }
        });
        p.add((Component)browseBtn, gc);
        gc.gridx = 0;
        gc.gridy = 1;
        gc.gridwidth = 3;
        gc.weighty = 1.0;
        p.add(Box.createVerticalGlue(), gc);
        return p;
    }

    private JPanel buildButtonBar() {
        JPanel bar = new JPanel(new FlowLayout(2, 8, 8));
        bar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIManager.getColor("Separator.foreground")));
        JButton cancelBtn = new JButton("\u0130ptal");
        cancelBtn.addActionListener(e -> this.dispose());
        JButton saveBtn = new JButton("Kaydet");
        saveBtn.setBackground(new Color(2981190));
        saveBtn.addActionListener(e -> this.save());
        this.getRootPane().setDefaultButton(saveBtn);
        bar.add(cancelBtn);
        bar.add(saveBtn);
        return bar;
    }

    private void loadValues() {
        this.aerolinkKeyField.setText(this.settings.getAerolinkApiKey());
        this.aerolinkKeyField2.setText(this.settings.getAerolinkApiKey2());
        this.anthropicKeyField.setText(this.settings.getAnthropicApiKey());
        if (this.settings.isUseAerolink()) {
            this.aerolinkRadio.setSelected(true);
        } else {
            this.anthropicRadio.setSelected(true);
        }
        this.modelCombo.setSelectedItem(this.settings.getModel());
        this.systemPromptArea.setText(this.settings.getSystemPrompt());
        this.maxTokensSpinner.setValue(this.settings.getMaxTokens());
        this.maxIterationsSpinner.setValue(this.settings.getMaxToolIterations());
        this.workingDirField.setText(this.settings.getWorkingDirectory());
    }

    private void save() {
        this.settings.setAerolinkApiKey(this.aerolinkKeyField.getText().trim());
        this.settings.setAerolinkApiKey2(this.aerolinkKeyField2.getText().trim());
        this.settings.setAnthropicApiKey(this.anthropicKeyField.getText().trim());
        this.settings.setUseAerolink(this.aerolinkRadio.isSelected());
        this.settings.setModel(this.modelCombo.getSelectedItem() != null ? this.modelCombo.getSelectedItem().toString().trim() : "claude-sonnet-4-6");
        this.settings.setSystemPrompt(this.systemPromptArea.getText());
        this.settings.setMaxTokens((Integer)this.maxTokensSpinner.getValue());
        this.settings.setMaxToolIterations((Integer)this.maxIterationsSpinner.getValue());
        this.settings.setWorkingDirectory(this.workingDirField.getText().trim());
        this.settings.save();
        this.confirmed = true;
        this.dispose();
    }

    public boolean isConfirmed() {
        return this.confirmed;
    }
}

