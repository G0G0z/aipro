/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.util.ArrayList;
import java.util.List;

public class AppSettings {
    private static final String SETTINGS_FILE = System.getProperty("user.home") + File.separator + ".ai-client-manager" + File.separator + "settings.json";
    private String aerolinkApiKey = envOrEmpty("AEROLINK_API_KEY");
    private String aerolinkApiKey2 = envOrEmpty("AEROLINK_API_KEY_2");
    private String anthropicApiKey = envOrEmpty("ANTHROPIC_API_KEY");
    private String baseUrl = "https://capi.aerolink.lat";
    private String model = "claude-opus-4-8";

    private static String envOrEmpty(String key) {
        String v = System.getenv(key);
        return v != null ? v : "";
    }
    private String systemPrompt = "Sen geli\u015fmi\u015f bir yapay zeka asistan\u0131s\u0131n ve tam dosya sistemi ile kabuk eri\u015fimine sahipsin.\n\nSahip oldu\u011fun yetenekler:\n- Dosya okuma, yazma, olu\u015fturma, d\u00fczenleme ve silme\n- Dizin olu\u015fturma, listeleme ve gezinme\n- Dosyalar i\u00e7inde metin/regex arama\n- Kabuk komutlar\u0131 \u00e7al\u0131\u015ft\u0131rma (bash)\n- Dosya/dizin ta\u015f\u0131ma ve yeniden adland\u0131rma\n- Dosya meta bilgilerini g\u00f6r\u00fcnt\u00fcleme\n\nKullan\u0131c\u0131ya T\u00fcrk\u00e7e olarak yan\u0131t ver.\n\n\u00d6nemli kurallar:\n1. Kod yazmadan \u00f6nce mevcut kodu oku\n2. De\u011fi\u015fiklik yaparken dikkatli ve \u00f6zenli ol\n3. Silme i\u015flemlerinden \u00f6nce kullan\u0131c\u0131y\u0131 uyar\n4. Uzun \u00e7\u0131kt\u0131lar\u0131 \u00f6zetle ve en \u00f6nemli k\u0131s\u0131mlar\u0131 vurgula\n5. Hata durumunda hatan\u0131n sebebini a\u00e7\u0131kla ve \u00e7\u00f6z\u00fcm \u00f6ner\n";
    private List<String> savedSystemPrompts = new ArrayList<String>();
    private int maxTokens = 8096;
    private int maxToolIterations = 50;
    private boolean useAerolink = true;
    private String workingDirectory = System.getProperty("user.home");
    private static final String DEFAULT_SYSTEM_PROMPT = "Sen geli\u015fmi\u015f bir yapay zeka asistan\u0131s\u0131n ve tam dosya sistemi ile kabuk eri\u015fimine sahipsin.\n\nSahip oldu\u011fun yetenekler:\n- Dosya okuma, yazma, olu\u015fturma, d\u00fczenleme ve silme\n- Dizin olu\u015fturma, listeleme ve gezinme\n- Dosyalar i\u00e7inde metin/regex arama\n- Kabuk komutlar\u0131 \u00e7al\u0131\u015ft\u0131rma (bash)\n- Dosya/dizin ta\u015f\u0131ma ve yeniden adland\u0131rma\n- Dosya meta bilgilerini g\u00f6r\u00fcnt\u00fcleme\n\nKullan\u0131c\u0131ya T\u00fcrk\u00e7e olarak yan\u0131t ver.\n\n\u00d6nemli kurallar:\n1. Kod yazmadan \u00f6nce mevcut kodu oku\n2. De\u011fi\u015fiklik yaparken dikkatli ve \u00f6zenli ol\n3. Silme i\u015flemlerinden \u00f6nce kullan\u0131c\u0131y\u0131 uyar\n4. Uzun \u00e7\u0131kt\u0131lar\u0131 \u00f6zetle ve en \u00f6nemli k\u0131s\u0131mlar\u0131 vurgula\n5. Hata durumunda hatan\u0131n sebebini a\u00e7\u0131kla ve \u00e7\u00f6z\u00fcm \u00f6ner\n";
    private static AppSettings instance;

    private AppSettings() {
    }

    public static AppSettings getInstance() {
        if (instance == null) {
            instance = AppSettings.load();
        }
        return instance;
    }

    public static AppSettings load() {
        AppSettings settings = new AppSettings();
        File file = new File(SETTINGS_FILE);
        if (!file.exists()) {
            return settings;
        }
        try {
            String json = Files.readString(file.toPath());
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            if (obj.has("aerolinkApiKey")) {
                settings.aerolinkApiKey = obj.get("aerolinkApiKey").getAsString();
            }
            if (obj.has("aerolinkApiKey2")) {
                settings.aerolinkApiKey2 = obj.get("aerolinkApiKey2").getAsString();
            }
            if (obj.has("anthropicApiKey")) {
                settings.anthropicApiKey = obj.get("anthropicApiKey").getAsString();
            }
            if (obj.has("baseUrl")) {
                settings.baseUrl = obj.get("baseUrl").getAsString();
            }
            if (obj.has("model")) {
                settings.model = obj.get("model").getAsString();
            }
            if (obj.has("systemPrompt")) {
                settings.systemPrompt = obj.get("systemPrompt").getAsString();
            }
            if (obj.has("maxTokens")) {
                settings.maxTokens = obj.get("maxTokens").getAsInt();
            }
            if (obj.has("maxToolIterations")) {
                settings.maxToolIterations = obj.get("maxToolIterations").getAsInt();
            }
            if (obj.has("useAerolink")) {
                settings.useAerolink = obj.get("useAerolink").getAsBoolean();
            }
            if (obj.has("workingDirectory")) {
                settings.workingDirectory = obj.get("workingDirectory").getAsString();
            }
            if (obj.has("savedSystemPrompts")) {
                JsonArray arr = obj.getAsJsonArray("savedSystemPrompts");
                for (JsonElement e : arr) {
                    settings.savedSystemPrompts.add(e.getAsString());
                }
            }
        }
        catch (Exception e) {
            System.err.println("Ayarlar y\u00fcklenemedi: " + e.getMessage());
        }
        return settings;
    }

    public void save() {
        try {
            File file = new File(SETTINGS_FILE);
            file.getParentFile().mkdirs();
            JsonObject obj = new JsonObject();
            obj.addProperty("aerolinkApiKey", this.aerolinkApiKey);
            obj.addProperty("aerolinkApiKey2", this.aerolinkApiKey2);
            obj.addProperty("anthropicApiKey", this.anthropicApiKey);
            obj.addProperty("baseUrl", this.baseUrl);
            obj.addProperty("model", this.model);
            obj.addProperty("systemPrompt", this.systemPrompt);
            obj.addProperty("maxTokens", this.maxTokens);
            obj.addProperty("maxToolIterations", this.maxToolIterations);
            obj.addProperty("useAerolink", this.useAerolink);
            obj.addProperty("workingDirectory", this.workingDirectory);
            JsonArray arr = new JsonArray();
            for (String p : this.savedSystemPrompts) {
                arr.add(p);
            }
            obj.add("savedSystemPrompts", arr);
            Files.writeString(file.toPath(), (CharSequence)new GsonBuilder().setPrettyPrinting().create().toJson(obj), new OpenOption[0]);
        }
        catch (Exception e) {
            System.err.println("Ayarlar kaydedilemedi: " + e.getMessage());
        }
    }

    public String getEffectiveApiKey() {
        if (this.useAerolink && !this.aerolinkApiKey.isBlank()) {
            return this.aerolinkApiKey;
        }
        return this.anthropicApiKey;
    }

    public String getEffectiveBaseUrl() {
        if (this.useAerolink && !this.aerolinkApiKey.isBlank()) {
            return "https://capi.aerolink.lat";
        }
        return "https://api.anthropic.com";
    }

    public String getAerolinkApiKey() {
        return this.aerolinkApiKey;
    }

    public void setAerolinkApiKey(String v) {
        this.aerolinkApiKey = v;
    }

    public String getAerolinkApiKey2() {
        return this.aerolinkApiKey2;
    }

    public void setAerolinkApiKey2(String v) {
        this.aerolinkApiKey2 = v;
    }

    public String getAerolinkFallbackKey() {
        if (!this.aerolinkApiKey2.isBlank() && !this.aerolinkApiKey2.equals(this.aerolinkApiKey)) {
            return this.aerolinkApiKey2;
        }
        return null;
    }

    public String getAnthropicApiKey() {
        return this.anthropicApiKey;
    }

    public void setAnthropicApiKey(String v) {
        this.anthropicApiKey = v;
    }

    public String getBaseUrl() {
        return this.baseUrl;
    }

    public void setBaseUrl(String v) {
        this.baseUrl = v;
    }

    public String getModel() {
        return this.model;
    }

    public void setModel(String v) {
        this.model = v;
    }

    public String getSystemPrompt() {
        return this.systemPrompt;
    }

    public void setSystemPrompt(String v) {
        this.systemPrompt = v;
    }

    public List<String> getSavedSystemPrompts() {
        return this.savedSystemPrompts;
    }

    public int getMaxTokens() {
        return this.maxTokens;
    }

    public void setMaxTokens(int v) {
        this.maxTokens = v;
    }

    public int getMaxToolIterations() {
        return this.maxToolIterations;
    }

    public void setMaxToolIterations(int v) {
        this.maxToolIterations = v;
    }

    public boolean isUseAerolink() {
        return this.useAerolink;
    }

    public void setUseAerolink(boolean v) {
        this.useAerolink = v;
    }

    public String getWorkingDirectory() {
        return this.workingDirectory;
    }

    public void setWorkingDirectory(String v) {
        this.workingDirectory = v;
    }

    public boolean hasApiKey() {
        return !this.getEffectiveApiKey().isBlank();
    }

    public static String getDefaultSystemPrompt() {
        return DEFAULT_SYSTEM_PROMPT;
    }
}

