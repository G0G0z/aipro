/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.UIManager;

public class TokenBar
extends JPanel {
    private final JLabel modelLabel;
    private final JLabel tokenLabel;
    private final JLabel connLabel;
    private static final Color BAR_BG = new Color(1448738);
    private static final Color FG = new Color(9147550);

    public TokenBar() {
        this.setLayout(new BorderLayout(0, 0));
        this.setBackground(BAR_BG);
        this.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(2172461)), BorderFactory.createEmptyBorder(3, 10, 3, 10)));
        this.setPreferredSize(new Dimension(0, 24));
        Font small = UIManager.getFont("Label.font");
        small = small != null ? small.deriveFont(10.0f) : new Font("SansSerif", 0, 10);
        this.modelLabel = new JLabel("Model: \u2014");
        this.modelLabel.setForeground(FG);
        this.modelLabel.setFont(small);
        this.tokenLabel = new JLabel("Token: \u2014");
        this.tokenLabel.setForeground(FG);
        this.tokenLabel.setFont(small);
        this.connLabel = new JLabel("\u26aa  Ba\u011flant\u0131 yok");
        this.connLabel.setForeground(FG);
        this.connLabel.setFont(small);
        this.add((Component)this.modelLabel, "West");
        this.add((Component)this.tokenLabel, "Center");
        JPanel right = new JPanel(new FlowLayout(2, 0, 0));
        right.setBackground(BAR_BG);
        right.add(this.connLabel);
        this.add((Component)right, "East");
    }

    public void update(String model, int input, int output, boolean connected) {
        this.modelLabel.setText("Model: " + model);
        if (input + output > 0) {
            this.tokenLabel.setText("  Token \u2014 Girdi: " + input + "  \u00c7\u0131kt\u0131: " + output + "  Toplam: " + (input + output));
        } else {
            this.tokenLabel.setText("  Token: \u2014");
        }
        this.connLabel.setText(connected ? "\ud83d\udfe2  Ba\u011fl\u0131" : "\u26aa  Ba\u011flant\u0131 yok");
        this.connLabel.setForeground(connected ? new Color(4176208) : FG);
    }
}

