/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import com.aiclient.gui.ConversationHistory;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.function.Consumer;
import javax.swing.BorderFactory;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;

public class SidebarPanel
extends JPanel {
    private final DefaultListModel<ConversationHistory> listModel;
    private final JList<ConversationHistory> historyList;
    private Consumer<ConversationHistory> onSelect;
    private Runnable onNewChat;
    private Consumer<ConversationHistory> onDelete;
    private static final Color SIDEBAR_BG = new Color(1711395);
    private static final Color ITEM_BG = new Color(2172461);
    private static final Color ITEM_SEL_BG = new Color(2963272);
    private static final Color TITLE_COLOR = new Color(15264502);
    private static final Color DATE_COLOR = new Color(0x757575);
    private static final Color ACCENT = new Color(5227511);

    public SidebarPanel() {
        this.setLayout(new BorderLayout(0, 0));
        this.setBackground(SIDEBAR_BG);
        this.setPreferredSize(new Dimension(240, 0));
        this.setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(3159613)));
        JPanel header = new JPanel(new BorderLayout(8, 0));
        header.setBackground(SIDEBAR_BG);
        header.setBorder(BorderFactory.createEmptyBorder(12, 12, 8, 12));
        JLabel title = new JLabel("\ud83d\udcac  Sohbetler");
        title.setForeground(TITLE_COLOR);
        title.setFont(title.getFont().deriveFont(1, 14.0f));
        header.add((Component)title, "West");
        JButton newBtn = new JButton("+");
        newBtn.setToolTipText("Yeni Sohbet");
        newBtn.setFont(newBtn.getFont().deriveFont(1, 16.0f));
        newBtn.setForeground(ACCENT);
        newBtn.setBackground(new Color(2764864));
        newBtn.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
        newBtn.setCursor(Cursor.getPredefinedCursor(12));
        newBtn.setFocusPainted(false);
        newBtn.addActionListener(e -> {
            if (this.onNewChat != null) {
                this.onNewChat.run();
            }
        });
        header.add((Component)newBtn, "East");
        this.add((Component)header, "North");
        this.listModel = new DefaultListModel();
        this.historyList = new JList<ConversationHistory>(this.listModel);
        this.historyList.setBackground(SIDEBAR_BG);
        this.historyList.setSelectionBackground(ITEM_SEL_BG);
        this.historyList.setForeground(TITLE_COLOR);
        this.historyList.setCellRenderer(new HistoryCellRenderer());
        this.historyList.setFixedCellHeight(60);
        this.historyList.setBorder(null);
        this.historyList.addListSelectionListener(e -> {
            ConversationHistory sel;
            if (!e.getValueIsAdjusting() && this.onSelect != null && (sel = this.historyList.getSelectedValue()) != null) {
                this.onSelect.accept(sel);
            }
        });
        JPopupMenu popup = new JPopupMenu();
        JMenuItem deleteItem = new JMenuItem("\ud83d\uddd1  Sohbeti Sil");
        deleteItem.addActionListener(e -> {
            int r;
            ConversationHistory sel = this.historyList.getSelectedValue();
            if (sel != null && this.onDelete != null && (r = JOptionPane.showConfirmDialog(this, "\"" + sel.getTitle() + "\" silinsin mi?", "Sohbeti Sil", 0)) == 0) {
                this.onDelete.accept(sel);
            }
        });
        popup.add(deleteItem);
        this.historyList.setComponentPopupMenu(popup);
        JScrollPane scroll = new JScrollPane(this.historyList);
        scroll.setBorder(null);
        scroll.setBackground(SIDEBAR_BG);
        scroll.getViewport().setBackground(SIDEBAR_BG);
        this.add((Component)scroll, "Center");
    }

    public void loadHistory() {
        this.listModel.clear();
        List<ConversationHistory> all = ConversationHistory.loadAll();
        for (ConversationHistory h : all) {
            this.listModel.addElement(h);
        }
    }

    public void addConversation(ConversationHistory h) {
        this.listModel.insertElementAt(h, 0);
        this.historyList.setSelectedIndex(0);
    }

    public void refreshTop(ConversationHistory h) {
        int idx = this.listModel.indexOf(h);
        if (idx >= 0) {
            this.listModel.set(idx, h);
        }
    }

    public void removeConversation(ConversationHistory h) {
        this.listModel.removeElement(h);
    }

    public void selectFirst() {
        if (!this.listModel.isEmpty()) {
            this.historyList.setSelectedIndex(0);
        }
    }

    public void setOnSelect(Consumer<ConversationHistory> cb) {
        this.onSelect = cb;
    }

    public void setOnNewChat(Runnable cb) {
        this.onNewChat = cb;
    }

    public void setOnDelete(Consumer<ConversationHistory> cb) {
        this.onDelete = cb;
    }

    private class HistoryCellRenderer
    extends JPanel
    implements ListCellRenderer<ConversationHistory> {
        private final JLabel titleLabel = new JLabel();
        private final JLabel dateLabel = new JLabel();

        HistoryCellRenderer() {
            this.setLayout(new BorderLayout(0, 3));
            this.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(3159613)), BorderFactory.createEmptyBorder(8, 12, 8, 8)));
            this.titleLabel.setFont(this.titleLabel.getFont().deriveFont(0, 12.0f));
            this.dateLabel.setFont(this.dateLabel.getFont().deriveFont(10.0f));
            this.dateLabel.setForeground(DATE_COLOR);
            this.add((Component)this.titleLabel, "Center");
            this.add((Component)this.dateLabel, "South");
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends ConversationHistory> list, ConversationHistory value, int index, boolean isSelected, boolean cellHasFocus) {
            this.setBackground(isSelected ? ITEM_SEL_BG : SIDEBAR_BG);
            this.titleLabel.setBackground(this.getBackground());
            this.dateLabel.setBackground(this.getBackground());
            this.setOpaque(true);
            Object title = value.getTitle();
            if (((String)title).length() > 28) {
                title = ((String)title).substring(0, 28) + "\u2026";
            }
            this.titleLabel.setText((String)title);
            this.titleLabel.setForeground(isSelected ? ACCENT : TITLE_COLOR);
            String date = value.getUpdatedAt().format(DateTimeFormatter.ofPattern("d MMM, HH:mm"));
            this.dateLabel.setText(date);
            return this;
        }
    }
}

