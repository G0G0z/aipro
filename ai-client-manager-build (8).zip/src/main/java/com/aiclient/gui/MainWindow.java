/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient.gui;

import com.aiclient.AnthropicClient;
import com.aiclient.gui.AppSettings;
import com.aiclient.gui.ChatMessage;
import com.aiclient.gui.ChatPanel;
import com.aiclient.gui.ConversationHistory;
import com.aiclient.gui.FileDropHandler;
import com.aiclient.gui.GUIAgent;
import com.aiclient.gui.InputPanel;
import com.aiclient.gui.MessageBubble;
import com.aiclient.gui.SettingsDialog;
import com.aiclient.gui.SidebarPanel;
import com.aiclient.gui.TokenBar;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.datatransfer.DataFlavor;
import java.awt.dnd.DropTarget;
import java.awt.dnd.DropTargetAdapter;
import java.awt.dnd.DropTargetDragEvent;
import java.awt.dnd.DropTargetDropEvent;
import java.awt.dnd.DropTargetEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import javax.swing.KeyStroke;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.border.EmptyBorder;

public class MainWindow
extends JFrame {
    private final AppSettings settings = AppSettings.getInstance();
    private GUIAgent agent;
    private final SidebarPanel sidebar;
    private final ChatPanel chatPanel;
    private final InputPanel inputPanel;
    private final TokenBar tokenBar;
    private ConversationHistory currentConversation;
    private MessageBubble streamingBubble;
    private SwingWorker<Void, Object[]> currentWorker;
    private static final Color WIN_BG = new Color(856343);
    private static final Color TOP_BG = new Color(1448738);
    private JLabel dropOverlay;

    public MainWindow() {
        super("AI Client Manager v2.0");
        this.setDefaultCloseOperation(3);
        this.setPreferredSize(new Dimension(1100, 720));
        this.setMinimumSize(new Dimension(800, 560));
        this.getContentPane().setBackground(WIN_BG);
        this.sidebar = new SidebarPanel();
        this.chatPanel = new ChatPanel();
        this.inputPanel = new InputPanel();
        this.tokenBar = new TokenBar();
        this.buildLayout();
        this.bindEvents();
        this.loadHistory();
        this.updateTokenBar();
        this.initAgent();
        this.pack();
        this.setLocationRelativeTo(null);
        this.setupWindowDropTarget();
        if (!this.settings.hasApiKey()) {
            SwingUtilities.invokeLater(this::openSettings);
        }
    }

    private void buildLayout() {
        this.setJMenuBar(this.buildMenuBar());
        JSplitPane split = new JSplitPane(1, this.sidebar, this.buildCenterPanel());
        split.setDividerLocation(240);
        split.setDividerSize(1);
        split.setBorder(null);
        split.setBackground(WIN_BG);
        this.add((Component)split, "Center");
        this.add((Component)this.tokenBar, "South");
    }

    private JPanel buildCenterPanel() {
        JPanel center = new JPanel(new BorderLayout(0, 0));
        center.setBackground(WIN_BG);
        center.add((Component)this.buildTopBar(), "North");
        center.add((Component)this.chatPanel, "Center");
        center.add((Component)this.inputPanel, "South");
        return center;
    }

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout(8, 0));
        bar.setBackground(TOP_BG);
        bar.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(3159613)), new EmptyBorder(8, 12, 8, 12)));
        JLabel title = new JLabel("\ud83e\udd16  AI Client Manager");
        title.setForeground(new Color(15264502));
        title.setFont(title.getFont().deriveFont(1, 15.0f));
        bar.add((Component)title, "West");
        JPanel right = new JPanel(new FlowLayout(2, 8, 0));
        right.setBackground(TOP_BG);
        String[] models = new String[]{"claude-sonnet-4-6", "claude-opus-4-5", "claude-haiku-3-5", "claude-3-5-sonnet-20241022", "gpt-4o", "gpt-4o-mini"};
        JComboBox<String> modelBox = new JComboBox<String>(models);
        modelBox.setEditable(true);
        modelBox.setSelectedItem(this.settings.getModel());
        modelBox.setToolTipText("Modeli de\u011fi\u015ftir");
        modelBox.setPreferredSize(new Dimension(200, 28));
        modelBox.addActionListener(e -> {
            String m;
            String string = m = modelBox.getSelectedItem() != null ? modelBox.getSelectedItem().toString() : "";
            if (!m.isBlank()) {
                this.settings.setModel(m);
                this.settings.save();
                if (this.agent != null) {
                    this.agent.setModel(m);
                }
                this.updateTokenBar();
            }
        });
        right.add(modelBox);
        JButton clearBtn = this.topButton("\ud83d\uddd1  Temizle");
        clearBtn.setToolTipText("Mevcut sohbeti temizle");
        clearBtn.addActionListener(e -> this.clearCurrentChat());
        right.add(clearBtn);
        JButton settingsBtn = this.topButton("\u2699  Ayarlar");
        settingsBtn.addActionListener(e -> this.openSettings());
        right.add(settingsBtn);
        bar.add((Component)right, "East");
        return bar;
    }

    private JButton topButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(new Color(2172461));
        btn.setForeground(new Color(13226457));
        btn.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(3159613)), BorderFactory.createEmptyBorder(4, 10, 4, 10)));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(12));
        return btn;
    }

    private JMenuBar buildMenuBar() {
        JMenuBar mb = new JMenuBar();
        mb.setBackground(new Color(1448738));
        mb.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(3159613)));
        JMenu fileMenu = new JMenu("Dosya");
        fileMenu.setForeground(new Color(13226457));
        this.addMenuItem(fileMenu, "Yeni Sohbet", "ctrl N", e -> this.newChat());
        this.addMenuItem(fileMenu, "Sohbeti Kaydet", "ctrl S", e -> this.saveCurrentConversation());
        fileMenu.addSeparator();
        this.addMenuItem(fileMenu, "\u00c7\u0131k\u0131\u015f", "ctrl Q", e -> System.exit(0));
        JMenu viewMenu = new JMenu("G\u00f6r\u00fcn\u00fcm");
        viewMenu.setForeground(new Color(13226457));
        this.addMenuItem(viewMenu, "Sohbeti Temizle", null, e -> this.clearCurrentChat());
        this.addMenuItem(viewMenu, "Ge\u00e7mi\u015fi Yenile", "F5", e -> this.loadHistory());
        JMenu helpMenu = new JMenu("Yard\u0131m");
        helpMenu.setForeground(new Color(13226457));
        this.addMenuItem(helpMenu, "Kullan\u0131m K\u0131lavuzu", null, e -> this.showHelp());
        this.addMenuItem(helpMenu, "Hakk\u0131nda", null, e -> this.showAbout());
        mb.add(fileMenu);
        mb.add(viewMenu);
        mb.add(helpMenu);
        return mb;
    }

    private void addMenuItem(JMenu menu, String text, String accel, ActionListener al) {
        JMenuItem item = new JMenuItem(text);
        if (accel != null) {
            item.setAccelerator(KeyStroke.getKeyStroke(accel));
        }
        item.addActionListener(al);
        menu.add(item);
    }

    private void bindEvents() {
        this.sidebar.setOnSelect(this::loadConversation);
        this.sidebar.setOnNewChat(this::newChat);
        this.sidebar.setOnDelete(h -> {
            h.delete();
            this.sidebar.removeConversation((ConversationHistory)h);
            if (this.currentConversation == h) {
                this.newChat();
            }
        });
        this.inputPanel.setOnSend(this::sendMessage);
        this.inputPanel.setOnCancel(this::cancelMessage);
    }

    private void initAgent() {
        if (!this.settings.hasApiKey()) {
            return;
        }
        try {
            String fallbackKey = this.settings.isUseAerolink() ? this.settings.getAerolinkFallbackKey() : null;
            AnthropicClient client = new AnthropicClient(this.settings.getEffectiveApiKey(), this.settings.getEffectiveBaseUrl(), fallbackKey);
            this.agent = new GUIAgent(client, this.settings);
            com.aiclient.tools.AskUserQuestionTool.setHandler(new GuiUserInteractionHandler(this));
        }
        catch (Exception e) {
            this.showError("Agent ba\u015flat\u0131lamad\u0131: " + e.getMessage());
        }
    }

    private void sendMessage(final String text) {
        if (this.agent == null) {
            this.openSettings();
            return;
        }
        if (this.currentConversation == null) {
            this.newChat();
        }
        ChatMessage userMsg = new ChatMessage(ChatMessage.Type.USER, text);
        this.chatPanel.addMessage(userMsg);
        this.currentConversation.addMessage(userMsg);
        this.sidebar.refreshTop(this.currentConversation);
        this.streamingBubble = this.chatPanel.startStreamingMessage();
        final StringBuilder streamBuffer = new StringBuilder();
        this.inputPanel.setProcessing(true);
        this.inputPanel.setStatus("\u27f3  Yan\u0131t bekleniyor\u2026");
        this.currentWorker = new SwingWorker<Void, Object[]>(){

            @Override
            protected Void doInBackground() {
                MainWindow.this.agent.resetCancel();
                MainWindow.this.agent.setCallbacks(chunk -> this.publish(new Object[]{"TEXT", chunk}), data -> this.publish(new Object[]{"TOOL_USE", data[0], data[1]}), data -> this.publish(new Object[]{"TOOL_RESULT", data[0], data[1], data[2]}), () -> this.publish(new Object[]{"DONE"}), err -> this.publish(new Object[]{"ERROR", err}));
                MainWindow.this.agent.chat(text);
                return null;
            }

            @Override
            protected void process(List<Object[]> chunks) {
                for (Object[] ev : chunks) {
                    String type;
                    switch (type = (String)ev[0]) {
                        case "TEXT": {
                            String chunk = (String)ev[1];
                            streamBuffer.append(chunk);
                            MainWindow.this.streamingBubble.setText(streamBuffer.toString());
                            MainWindow.this.chatPanel.scrollToBottom();
                            break;
                        }
                        case "TOOL_USE": {
                            ChatMessage tm = new ChatMessage(ChatMessage.Type.TOOL_USE, "Ara\u00e7 \u00e7al\u0131\u015ft\u0131r\u0131l\u0131yor\u2026", (String)ev[1], false);
                            MainWindow.this.chatPanel.addMessage(tm);
                            MainWindow.this.currentConversation.addMessage(tm);
                            MainWindow.this.inputPanel.setStatus("\u2699  Ara\u00e7: " + String.valueOf(ev[1]));
                            break;
                        }
                        case "TOOL_RESULT": {
                            boolean ok = "true".equals(ev[2]);
                            String result = (String)ev[3];
                            String preview = result != null && result.length() > 300 ? result.substring(0, 300) + "\n\u2026 (\u00e7\u0131kt\u0131 k\u0131salt\u0131ld\u0131)" : result;
                            ChatMessage rm = new ChatMessage(ChatMessage.Type.TOOL_RESULT, preview, (String)ev[1], ok);
                            MainWindow.this.chatPanel.addMessage(rm);
                            MainWindow.this.currentConversation.addMessage(rm);
                            MainWindow.this.inputPanel.setStatus("\u27f3  Yan\u0131t devam ediyor\u2026");
                            break;
                        }
                        case "DONE": {
                            MainWindow.this.onChatDone(streamBuffer.toString(), null);
                            break;
                        }
                        case "ERROR": {
                            MainWindow.this.onChatDone(null, (String)ev[1]);
                        }
                    }
                }
            }

            @Override
            protected void done() {
                if (this.isCancelled()) {
                    MainWindow.this.onChatDone(streamBuffer.toString(), null);
                }
            }
        };
        this.currentWorker.execute();
    }

    private void onChatDone(String finalText, String error) {
        this.chatPanel.finalizeStreamingMessage();
        if (error != null) {
            ChatMessage errMsg = new ChatMessage(ChatMessage.Type.ERROR, error);
            this.chatPanel.addMessage(errMsg);
            this.currentConversation.addMessage(errMsg);
        } else if (finalText != null && !finalText.isBlank()) {
            ChatMessage assistantMsg = new ChatMessage(ChatMessage.Type.ASSISTANT, finalText);
            this.currentConversation.addMessage(assistantMsg);
        }
        this.inputPanel.setProcessing(false);
        this.inputPanel.setStatus(" ");
        this.inputPanel.focus();
        this.updateTokenBar();
        this.saveCurrentConversation();
        this.sidebar.refreshTop(this.currentConversation);
    }

    private void cancelMessage() {
        if (this.agent != null) {
            this.agent.cancel();
        }
        if (this.currentWorker != null) {
            this.currentWorker.cancel(true);
        }
        this.inputPanel.setStatus("\u23f9  Durduruldu");
    }

    private void newChat() {
        this.saveCurrentConversation();
        this.currentConversation = new ConversationHistory();
        this.chatPanel.clearMessages();
        if (this.agent != null) {
            this.agent.resetHistory();
        }
        this.sidebar.addConversation(this.currentConversation);
        this.updateTokenBar();
        this.inputPanel.focus();
    }

    private void loadConversation(ConversationHistory h) {
        this.saveCurrentConversation();
        this.currentConversation = h;
        this.chatPanel.clearMessages();
        for (ChatMessage msg : h.getMessages()) {
            this.chatPanel.addMessage(msg);
        }
        if (this.agent != null) {
            this.agent.rebuildHistoryFromMessages(h.getMessages());
        }
        this.updateTokenBar();
        this.inputPanel.focus();
    }

    private void saveCurrentConversation() {
        if (this.currentConversation != null && !this.currentConversation.getMessages().isEmpty()) {
            this.currentConversation.save();
        }
    }

    private void clearCurrentChat() {
        int r = JOptionPane.showConfirmDialog(this, "Mevcut sohbet temizlensin mi?", "Sohbeti Temizle", 0);
        if (r == 0) {
            this.chatPanel.clearMessages();
            if (this.currentConversation != null) {
                this.currentConversation.clearMessages();
            }
            if (this.agent != null) {
                this.agent.resetHistory();
            }
            this.updateTokenBar();
        }
    }

    private void loadHistory() {
        this.sidebar.loadHistory();
    }

    private void openSettings() {
        SettingsDialog dlg = new SettingsDialog((Frame)this, this.settings);
        dlg.setVisible(true);
        if (dlg.isConfirmed()) {
            this.initAgent();
            this.updateTokenBar();
        }
    }

    private void updateTokenBar() {
        int in = this.agent != null ? this.agent.getTotalInputTokens() : 0;
        int out = this.agent != null ? this.agent.getTotalOutputTokens() : 0;
        boolean connected = this.agent != null && this.settings.hasApiKey();
        this.tokenBar.update(this.settings.getModel(), in, out, connected);
    }

    private void showHelp() {
        String help = "AI Client Manager - Kullan\u0131m K\u0131lavuzu\n\n\u25cf Mesaj g\u00f6ndermek i\u00e7in Enter'a bas\u0131n\n\u25cf Yeni sat\u0131r i\u00e7in Shift + Enter kullan\u0131n\n\u25cf Mesaja sa\u011f t\u0131klayarak kopyalayabilirsiniz\n\nAra\u00e7lar:\n\u2022 read_file     \u2014 Dosya okuma\n\u2022 write_file    \u2014 Dosya yazma/olu\u015fturma\n\u2022 edit_file     \u2014 Dosya d\u00fczenleme\n\u2022 delete_file   \u2014 Dosya silme\n\u2022 list_directory \u2014 Dizin listeleme\n\u2022 search_files  \u2014 Dosyalarda arama\n\u2022 execute_command \u2014 Komut \u00e7al\u0131\u015ft\u0131rma\n\u2022 make_directory \u2014 Klas\u00f6r olu\u015fturma\n\u2022 move_file     \u2014 Dosya ta\u015f\u0131ma\n\u2022 file_info     \u2014 Dosya bilgisi\n\nK\u0131sayollar:\n\u2022 Ctrl+N  \u2014 Yeni sohbet\n\u2022 Ctrl+S  \u2014 Sohbeti kaydet\n\u2022 Ctrl+Q  \u2014 \u00c7\u0131k\u0131\u015f\n\u2022 F5      \u2014 Ge\u00e7mi\u015fi yenile\n";
        JOptionPane.showMessageDialog(this, help, "Yard\u0131m", 1);
    }

    private void showAbout() {
        JOptionPane.showMessageDialog(this, "<html><b>AI Client Manager v2.0</b><br><br>Claude destekli tam yetkili dosya & sistem y\u00f6neticisi<br>Aerolink proxy ve Anthropic API deste\u011fi<br><br><small>Java " + System.getProperty("java.version") + " \u00b7 " + System.getProperty("os.name") + "</small></html>", "Hakk\u0131nda", 1);
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Hata", 0);
    }

    private String buildFileText(File file) throws Exception {
        long size = file.length();
        String name = file.getName();
        String ext = name.contains(".") ? name.substring(name.lastIndexOf(46) + 1).toLowerCase() : "";
        Set<String> textExts = Set.of("txt", "md", "java", "py", "js", "ts", "json", "xml", "yaml", "yml", "toml", "ini", "cfg", "conf", "properties", "env", "html", "htm", "css", "sql", "sh", "bat", "cmd", "c", "cpp", "h", "cs", "go", "rs", "rb", "php", "log", "csv");
        StringBuilder sb = new StringBuilder();
        sb.append("\ud83d\udcce Dosya: ").append(file.getAbsolutePath()).append("\n");
        sb.append("Boyut: ").append(this.formatSize(size)).append("\n");
        if (size < 500000L && (textExts.contains(ext) || ext.isEmpty())) {
            String content = Files.readString(file.toPath());
            sb.append("\u2500".repeat(40)).append("\n").append(content);
        } else {
            sb.append("(Binary/b\u00fcy\u00fck dosya \u2014 i\u00e7erik g\u00f6sterilemiyor)\nBu dosyayla ne yapmam\u0131 istersiniz?");
        }
        return sb.toString();
    }

    private String buildDirText(File dir) {
        File[] files = dir.listFiles();
        StringBuilder sb = new StringBuilder();
        sb.append("\ud83d\udcc1 Klas\u00f6r: ").append(dir.getAbsolutePath()).append("\n");
        if (files == null || files.length == 0) {
            sb.append("(Bo\u015f)");
            return sb.toString();
        }
        Arrays.sort(files, Comparator.comparing(File::isDirectory).reversed().thenComparing(File::getName));
        int shown = Math.min(files.length, 50);
        sb.append("\u0130\u00e7erik (").append(files.length).append(" \u00f6\u011fe):\n");
        for (int i = 0; i < shown; ++i) {
            File f = files[i];
            sb.append(f.isDirectory() ? "  \ud83d\udcc1 " : "  \ud83d\udcc4 ").append(f.getName());
            if (!f.isDirectory()) {
                sb.append(" (").append(this.formatSize(f.length())).append(")");
            }
            sb.append("\n");
        }
        if (files.length > 50) {
            sb.append("  ... ve ").append(files.length - 50).append(" \u00f6\u011fe daha");
        }
        return sb.toString();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024L) {
            return bytes + " B";
        }
        if (bytes < 0x100000L) {
            return String.format("%.1f KB", (double)bytes / 1024.0);
        }
        return String.format("%.1f MB", (double)bytes / 1048576.0);
    }

    private void setupWindowDropTarget() {
        new DropTarget(this, 1, new DropTargetAdapter(){

            @Override
            public void dragEnter(DropTargetDragEvent e) {
                if (e.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
                    e.acceptDrag(1);
                    MainWindow.this.showDropOverlay(true);
                }
            }

            @Override
            public void dragExit(DropTargetEvent e) {
                MainWindow.this.showDropOverlay(false);
            }

            @Override
            public void drop(DropTargetDropEvent e) {
                MainWindow.this.showDropOverlay(false);
                try {
                    e.acceptDrop(1);
                    List<File> files = (List<File>)e.getTransferable().getTransferData(DataFlavor.javaFileListFlavor);
                    if (!files.isEmpty()) {
                        FileDropHandler handler = new FileDropHandler(MainWindow.this.chatPanel, text -> SwingUtilities.invokeLater(() -> MainWindow.this.sendMessage((String)text)));
                        for (File f : files) {
                            try {
                                String content = f.isDirectory() ? MainWindow.this.buildDirText(f) : MainWindow.this.buildFileText(f);
                                SwingUtilities.invokeLater(() -> MainWindow.this.sendMessage(content));
                            }
                            catch (Exception exception) {}
                        }
                    }
                    e.dropComplete(true);
                }
                catch (Exception ex) {
                    e.dropComplete(false);
                }
            }
        });
    }

    private void showDropOverlay(boolean show) {
        if (show && this.dropOverlay == null) {
            this.dropOverlay = new JLabel("<html><center><b style='font-size:18'>\ud83d\udcc2</b><br>Dosyay\u0131 buraya b\u0131rak\u0131n</center></html>", 0);
            this.dropOverlay.setOpaque(true);
            this.dropOverlay.setBackground(new Color(856343, true));
            this.dropOverlay.setForeground(new Color(5227511));
            this.dropOverlay.setFont(this.dropOverlay.getFont().deriveFont(1, 18.0f));
            this.dropOverlay.setBorder(BorderFactory.createLineBorder(new Color(5227511), 2));
            this.dropOverlay.setBounds(10, 10, this.getWidth() - 20, this.getHeight() - 20);
            this.getLayeredPane().add((Component)this.dropOverlay, JLayeredPane.DRAG_LAYER);
        }
        if (this.dropOverlay != null) {
            this.dropOverlay.setVisible(show);
            if (!show) {
                this.getLayeredPane().remove(this.dropOverlay);
                this.dropOverlay = null;
            }
            this.getLayeredPane().revalidate();
            this.getLayeredPane().repaint();
        }
    }
}

