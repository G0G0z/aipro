/*
 * Decompiled with CFR 0.152.
 */
package com.aiclient;

import com.aiclient.gui.MainWindow;
import com.formdev.flatlaf.FlatDarkLaf;
import java.awt.Insets;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;

public class GuiMain {
    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        System.setProperty("sun.java2d.uiScale.enabled", "true");
        SwingUtilities.invokeLater(() -> {
            try {
                FlatDarkLaf.setup();
                UIManager.put("Button.arc", 8);
                UIManager.put("Component.arc", 8);
                UIManager.put("TextComponent.arc", 8);
                UIManager.put("ScrollBar.thumbArc", 999);
                UIManager.put("ScrollBar.thumbInsets", new Insets(2, 2, 2, 2));
                UIManager.put("TabbedPane.tabSeparatorsFullHeight", true);
                UIManager.put("TabbedPane.showTabSeparators", true);
            }
            catch (Exception e) {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                }
                catch (Exception exception) {
                    // empty catch block
                }
            }
            MainWindow window = new MainWindow();
            window.setVisible(true);
        });
    }
}

