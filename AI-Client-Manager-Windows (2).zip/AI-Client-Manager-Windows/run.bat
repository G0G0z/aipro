@echo off
chcp 65001 >nul
echo.
echo ╔══════════════════════════════════════════╗
echo ║       AI Client Manager v2.0             ║
echo ╚══════════════════════════════════════════╝
echo.

:: Java kontrolü
java -version >nul 2>&1
if errorlevel 1 (
    echo [HATA] Java bulunamadı!
    echo Java 17+ sürümünü indirin: https://adoptium.net/
    pause
    exit /b 1
)

:: JAR kontrolü
if not exist "target\ai-client-manager.jar" (
    echo [HATA] JAR dosyası bulunamadı!
    echo Önce build.bat çalıştırın.
    pause
    exit /b 1
)

echo Uygulama başlatılıyor...
echo.

:: Uygulama çalıştır (HiDPI ve GPU hızlandırma ile)
java ^
  -Xmx512m ^
  -Xms128m ^
  -Dfile.encoding=UTF-8 ^
  -Dsun.java2d.uiScale.enabled=true ^
  -Dswing.aatext=true ^
  -Dawt.useSystemAAFontSettings=on ^
  -jar target\ai-client-manager.jar

if errorlevel 1 (
    echo.
    echo [HATA] Uygulama beklenmedik şekilde kapandı.
    pause
)
