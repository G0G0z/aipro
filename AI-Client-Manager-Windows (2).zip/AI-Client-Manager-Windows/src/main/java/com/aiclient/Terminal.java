package com.aiclient;

public class Terminal {
    public static final String RESET   = "\u001B[0m";
    public static final String BOLD    = "\u001B[1m";
    public static final String DIM     = "\u001B[2m";
    public static final String ITALIC  = "\u001B[3m";

    public static final String BLACK   = "\u001B[30m";
    public static final String RED     = "\u001B[31m";
    public static final String GREEN   = "\u001B[32m";
    public static final String YELLOW  = "\u001B[33m";
    public static final String BLUE    = "\u001B[34m";
    public static final String MAGENTA = "\u001B[35m";
    public static final String CYAN    = "\u001B[36m";
    public static final String WHITE   = "\u001B[37m";

    public static final String BG_BLACK   = "\u001B[40m";
    public static final String BG_BLUE    = "\u001B[44m";
    public static final String BG_MAGENTA = "\u001B[45m";

    public static void printBanner() {
        System.out.println();
        System.out.println(BOLD + CYAN +
            "  ╔══════════════════════════════════════════╗" + RESET);
        System.out.println(BOLD + CYAN +
            "  ║" + RESET + BOLD + WHITE +
            "        Java AI Client  v1.0.0             " + RESET + BOLD + CYAN +
            "║" + RESET);
        System.out.println(BOLD + CYAN +
            "  ║" + RESET + DIM +
            "  Claude destekli dosya & shell aracı      " + RESET + BOLD + CYAN +
            "║" + RESET);
        System.out.println(BOLD + CYAN +
            "  ╚══════════════════════════════════════════╝" + RESET);
        System.out.println();
        System.out.println(DIM + "  Araçlar: dosya okuma/yazma/düzenleme/silme," + RESET);
        System.out.println(DIM + "           dizin listeleme, dosya arama, komut çalıştırma" + RESET);
        System.out.println();
        System.out.println(DIM + "  Komutlar: " + RESET + CYAN + "exit" + RESET + DIM + " - çık  |  " + RESET + CYAN + "clear" + RESET + DIM + " - ekranı temizle  |  " + RESET + CYAN + "help" + RESET + DIM + " - yardım" + RESET);
        System.out.println(DIM + "            " + RESET + CYAN + "history" + RESET + DIM + " - geçmiş  |  " + RESET + CYAN + "reset" + RESET + DIM + " - sohbeti sıfırla" + RESET);
        System.out.println();
    }

    public static void printHelp() {
        System.out.println();
        System.out.println(BOLD + YELLOW + "  ─── Kullanılabilir Komutlar ───" + RESET);
        System.out.println(GREEN + "  exit / quit" + RESET + "    : Uygulamadan çık");
        System.out.println(GREEN + "  clear"        + RESET + "          : Ekranı temizle");
        System.out.println(GREEN + "  reset"        + RESET + "          : Sohbet geçmişini sıfırla");
        System.out.println(GREEN + "  history"      + RESET + "        : Sohbet geçmişini göster");
        System.out.println(GREEN + "  model <isim>" + RESET + "   : Modeli değiştir (örn: claude-opus-4-5)");
        System.out.println(GREEN + "  tokens"       + RESET + "         : Kullanılan token sayısını göster");
        System.out.println();
        System.out.println(BOLD + YELLOW + "  ─── Sahip Olduğu Araçlar ───" + RESET);
        System.out.println(CYAN + "  read_file"       + RESET + "      : Dosya içeriğini oku");
        System.out.println(CYAN + "  write_file"      + RESET + "      : Dosyaya yaz (oluştur/üzerine yaz)");
        System.out.println(CYAN + "  edit_file"       + RESET + "       : Dosyada belirli satırları değiştir");
        System.out.println(CYAN + "  delete_file"     + RESET + "     : Dosyayı sil");
        System.out.println(CYAN + "  list_directory"  + RESET + "  : Dizin içeriğini listele");
        System.out.println(CYAN + "  search_files"    + RESET + "    : Dosyalarda metin ara");
        System.out.println(CYAN + "  execute_command" + RESET + "  : Kabuk komutu çalıştır");
        System.out.println(CYAN + "  make_directory"  + RESET + "  : Klasör oluştur");
        System.out.println(CYAN + "  move_file"       + RESET + "       : Dosya taşı/yeniden adlandır");
        System.out.println(CYAN + "  file_info"       + RESET + "       : Dosya bilgilerini görüntüle");
        System.out.println();
    }

    public static void printUserPrompt() {
        System.out.print(BOLD + GREEN + "  Siz" + RESET + BOLD + WHITE + " ❯ " + RESET);
    }

    public static void printAssistantHeader() {
        System.out.println();
        System.out.println(BOLD + BLUE + "  Claude" + RESET + BOLD + WHITE + " ❯" + RESET);
    }

    public static void printToolUse(String toolName, String toolId) {
        System.out.println(BOLD + MAGENTA + "  ⚙  Araç çağrısı: " + RESET + YELLOW + toolName + RESET + DIM + " [" + toolId.substring(0, Math.min(8, toolId.length())) + "...]" + RESET);
    }

    public static void printToolResult(String toolName, boolean success) {
        if (success) {
            System.out.println(GREEN + "  ✓  " + toolName + " tamamlandı" + RESET);
        } else {
            System.out.println(RED + "  ✗  " + toolName + " başarısız" + RESET);
        }
    }

    public static void printError(String message) {
        System.out.println(RED + "  ✗  Hata: " + message + RESET);
    }

    public static void printInfo(String message) {
        System.out.println(DIM + "  ℹ  " + message + RESET);
    }

    public static void printSeparator() {
        System.out.println(DIM + "  ────────────────────────────────────────────" + RESET);
    }

    public static void printTokenUsage(int inputTokens, int outputTokens, int totalTokens) {
        System.out.println(DIM + "  Tokenlar — Girdi: " + inputTokens + "  Çıktı: " + outputTokens + "  Toplam: " + totalTokens + RESET);
    }
}
