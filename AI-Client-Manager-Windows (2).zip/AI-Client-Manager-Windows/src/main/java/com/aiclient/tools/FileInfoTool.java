package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class FileInfoTool implements Tool {

    private static final DateTimeFormatter FMT =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault());

    @Override
    public String getName() { return "file_info"; }

    @Override
    public String getDescription() {
        return "Bir dosya veya dizin hakkında ayrıntılı bilgi gösterir: boyut, oluşturma tarihi, " +
               "değiştirilme tarihi, izinler, sembolik link durumu vb.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();

        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Bilgi alınacak dosya veya dizinin yolu");
        props.add("path", path);

        schema.add("properties", props);
        com.google.gson.JsonArray required = new com.google.gson.JsonArray();
        required.add("path");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String filePath = input.get("path").getAsString();
        Path path = Path.of(filePath);

        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) {
            return "HATA: Dosya/dizin bulunamadı: " + filePath;
        }

        BasicFileAttributes attrs = Files.readAttributes(path, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
        StringBuilder sb = new StringBuilder();

        sb.append("Yol: ").append(path.toAbsolutePath()).append("\n");
        sb.append("Tür: ");
        if (attrs.isDirectory()) sb.append("Dizin");
        else if (attrs.isSymbolicLink()) sb.append("Sembolik bağlantı");
        else if (attrs.isRegularFile()) sb.append("Normal dosya");
        else sb.append("Diğer");
        sb.append("\n");

        if (attrs.isSymbolicLink()) {
            sb.append("Hedef: ").append(Files.readSymbolicLink(path)).append("\n");
        }

        if (!attrs.isDirectory()) {
            sb.append("Boyut: ").append(formatSize(attrs.size())).append(" (").append(attrs.size()).append(" bayt)\n");
        } else {
            long[] dirSize = {0};
            long[] fileCount = {0};
            try {
                Files.walk(path).forEach(p -> {
                    if (Files.isRegularFile(p)) {
                        try { dirSize[0] += Files.size(p); fileCount[0]++; } catch (Exception ignored) {}
                    }
                });
            } catch (Exception ignored) {}
            sb.append("Dizin boyutu: ").append(formatSize(dirSize[0])).append(" (").append(fileCount[0]).append(" dosya)\n");
        }

        sb.append("Oluşturulma: ").append(FMT.format(attrs.creationTime().toInstant())).append("\n");
        sb.append("Değiştirilme: ").append(FMT.format(attrs.lastModifiedTime().toInstant())).append("\n");
        sb.append("Son erişim: ").append(FMT.format(attrs.lastAccessTime().toInstant())).append("\n");

        sb.append("Okunabilir: ").append(Files.isReadable(path) ? "Evet" : "Hayır").append("\n");
        sb.append("Yazılabilir: ").append(Files.isWritable(path) ? "Evet" : "Hayır").append("\n");
        sb.append("Çalıştırılabilir: ").append(Files.isExecutable(path) ? "Evet" : "Hayır").append("\n");
        sb.append("Gizli: ").append(Files.isHidden(path) ? "Evet" : "Hayır").append("\n");

        return sb.toString();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.2f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format("%.2f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }
}
