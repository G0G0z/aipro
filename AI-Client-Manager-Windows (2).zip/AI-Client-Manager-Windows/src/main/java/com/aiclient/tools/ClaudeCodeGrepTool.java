package com.aiclient.tools;

import com.google.gson.JsonObject;

/**
 * Handles the "Grep" tool injected by the Aerolink/Claude Code proxy.
 * Claude Code Grep format: { "pattern": "...", "path": "...", "include": "*.java" }
 */
public class ClaudeCodeGrepTool implements Tool {

    private final SearchFilesTool delegate = new SearchFilesTool();

    @Override public String getName() { return "Grep"; }
    @Override public String getDescription() { return "Search file contents"; }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        JsonObject mapped = new JsonObject();

        if (input.has("pattern")) mapped.addProperty("pattern", input.get("pattern").getAsString());
        if (input.has("query")) mapped.addProperty("pattern", input.get("query").getAsString());

        if (input.has("path")) mapped.addProperty("directory", input.get("path").getAsString());
        else if (input.has("directory")) mapped.addProperty("directory", input.get("directory").getAsString());

        if (input.has("include")) mapped.addProperty("file_pattern", input.get("include").getAsString());
        if (input.has("file_pattern")) mapped.addProperty("file_pattern", input.get("file_pattern").getAsString());

        return delegate.execute(mapped);
    }
}
