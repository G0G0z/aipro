package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class FileReadTool implements Tool {

    @Override
    public String getName() { return "read_file"; }

    @Override
    public String getDescription() {
        return "Bir dosyanın içeriğini okur. İsteğe bağlı olarak belirli satır aralığını okuyabilir. " +
               "Büyük dosyalar için satır aralığı belirtmek tavsiye edilir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();

        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Okunacak dosyanın yolu (mutlak veya göreli)");
        props.add("path", path);

        JsonObject startLine = new JsonObject();
        startLine.addProperty("type", "integer");
        startLine.addProperty("description", "Başlangıç satırı (1'den başlar, isteğe bağlı)");
        props.add("start_line", startLine);

        JsonObject endLine = new JsonObject();
        endLine.addProperty("type", "integer");
        endLine.addProperty("description", "Bitiş satırı (dahil, isteğe bağlı)");
        props.add("end_line", endLine);

        schema.add("properties", props);
        com.google.gson.JsonArray required = new com.google.gson.JsonArray();
        required.add("path");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String filePath = input.get("path").getAsString();
        Path path = Path.of(filePath);

        if (!Files.exists(path)) {
            return "HATA: Dosya bulunamadı: " + filePath;
        }
        if (Files.isDirectory(path)) {
            return "HATA: Bu bir dizin, dosya değil: " + filePath;
        }

        List<String> lines = Files.readAllLines(path);
        int totalLines = lines.size();

        int startLine = 1;
        int endLine = totalLines;

        if (input.has("start_line") && !input.get("start_line").isJsonNull()) {
            startLine = input.get("start_line").getAsInt();
        }
        if (input.has("end_line") && !input.get("end_line").isJsonNull()) {
            endLine = input.get("end_line").getAsInt();
        }

        startLine = Math.max(1, startLine);
        endLine = Math.min(totalLines, endLine);

        StringBuilder sb = new StringBuilder();
        sb.append("Dosya: ").append(filePath).append("\n");
        sb.append("Toplam satır: ").append(totalLines).append("\n");
        if (startLine != 1 || endLine != totalLines) {
            sb.append("Gösterilen satırlar: ").append(startLine).append("-").append(endLine).append("\n");
        }
        sb.append("─".repeat(60)).append("\n");

        for (int i = startLine - 1; i < endLine && i < lines.size(); i++) {
            sb.append(String.format("%4d │ %s%n", i + 1, lines.get(i)));
        }

        long fileSize = Files.size(path);
        sb.append("─".repeat(60)).append("\n");
        sb.append("Dosya boyutu: ").append(formatSize(fileSize));

        return sb.toString();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.1f MB", bytes / (1024.0 * 1024));
    }
}
