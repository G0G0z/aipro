package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.nio.file.*;

public class MoveFileTool implements Tool {

    @Override
    public String getName() { return "move_file"; }

    @Override
    public String getDescription() {
        return "Bir dosyayı veya dizini taşır ya da yeniden adlandırır. " +
               "Kaynak ve hedef farklı dizinlerde olabilir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();

        JsonObject source = new JsonObject();
        source.addProperty("type", "string");
        source.addProperty("description", "Kaynak dosya/dizin yolu");
        props.add("source", source);

        JsonObject destination = new JsonObject();
        destination.addProperty("type", "string");
        destination.addProperty("description", "Hedef dosya/dizin yolu");
        props.add("destination", destination);

        JsonObject overwrite = new JsonObject();
        overwrite.addProperty("type", "boolean");
        overwrite.addProperty("description", "Hedef dosya varsa üzerine yaz (varsayılan: false)");
        props.add("overwrite", overwrite);

        schema.add("properties", props);
        com.google.gson.JsonArray required = new com.google.gson.JsonArray();
        required.add("source");
        required.add("destination");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String sourcePath = input.get("source").getAsString();
        String destPath = input.get("destination").getAsString();
        boolean overwrite = input.has("overwrite") && !input.get("overwrite").isJsonNull()
                            && input.get("overwrite").getAsBoolean();

        Path source = Path.of(sourcePath);
        Path dest = Path.of(destPath);

        if (!Files.exists(source)) {
            return "HATA: Kaynak bulunamadı: " + sourcePath;
        }
        if (Files.exists(dest) && !overwrite) {
            return "HATA: Hedef zaten mevcut: " + destPath + ". Üzerine yazmak için overwrite=true kullanın.";
        }

        if (dest.getParent() != null) {
            Files.createDirectories(dest.getParent());
        }

        CopyOption[] options = overwrite
            ? new CopyOption[]{StandardCopyOption.REPLACE_EXISTING}
            : new CopyOption[]{};
        Files.move(source, dest, options);

        return String.format("Taşındı: %s → %s", sourcePath, destPath);
    }
}
