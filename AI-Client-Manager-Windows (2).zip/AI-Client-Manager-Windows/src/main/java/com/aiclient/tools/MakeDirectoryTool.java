package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.Path;

public class MakeDirectoryTool implements Tool {

    @Override
    public String getName() { return "make_directory"; }

    @Override
    public String getDescription() {
        return "Bir veya daha fazla iç içe klasör oluşturur. " +
               "Ara dizinler otomatik olarak oluşturulur (mkdir -p gibi).";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();

        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Oluşturulacak dizinin yolu");
        props.add("path", path);

        schema.add("properties", props);
        com.google.gson.JsonArray required = new com.google.gson.JsonArray();
        required.add("path");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String dirPath = input.get("path").getAsString();
        Path path = Path.of(dirPath);

        if (Files.exists(path)) {
            return Files.isDirectory(path)
                ? "Dizin zaten mevcut: " + dirPath
                : "HATA: Aynı isimde bir dosya mevcut: " + dirPath;
        }

        Files.createDirectories(path);
        return "Dizin oluşturuldu: " + path.toAbsolutePath();
    }
}
