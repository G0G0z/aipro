package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class FileEditTool implements Tool {

    @Override
    public String getName() { return "edit_file"; }

    @Override
    public String getDescription() {
        return "Bir dosyadaki belirli satır aralığını yeni içerikle değiştirir. " +
               "Satırları silmek için new_content boş bırakın. " +
               "Ayrıca eski metni yeni metinle bul-değiştir yapabilir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();

        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Düzenlenecek dosyanın yolu");
        props.add("path", path);

        JsonObject mode = new JsonObject();
        mode.addProperty("type", "string");
        mode.addProperty("description", "Düzenleme modu: 'lines' (satır aralığı değiştir) veya 'replace' (metin bul-değiştir)");
        com.google.gson.JsonArray modeEnum = new com.google.gson.JsonArray();
        modeEnum.add("lines");
        modeEnum.add("replace");
        mode.add("enum", modeEnum);
        props.add("mode", mode);

        JsonObject startLine = new JsonObject();
        startLine.addProperty("type", "integer");
        startLine.addProperty("description", "Başlangıç satırı (mode=lines için zorunlu, 1'den başlar)");
        props.add("start_line", startLine);

        JsonObject endLine = new JsonObject();
        endLine.addProperty("type", "integer");
        endLine.addProperty("description", "Bitiş satırı (mode=lines için zorunlu, dahil)");
        props.add("end_line", endLine);

        JsonObject newContent = new JsonObject();
        newContent.addProperty("type", "string");
        newContent.addProperty("description", "Değiştirilecek yeni içerik (mode=lines için). Boş ise satırlar silinir.");
        props.add("new_content", newContent);

        JsonObject oldText = new JsonObject();
        oldText.addProperty("type", "string");
        oldText.addProperty("description", "Aranacak metin (mode=replace için zorunlu)");
        props.add("old_text", oldText);

        JsonObject newText = new JsonObject();
        newText.addProperty("type", "string");
        newText.addProperty("description", "Yerine yazılacak metin (mode=replace için zorunlu)");
        props.add("new_text", newText);

        JsonObject replaceAll = new JsonObject();
        replaceAll.addProperty("type", "boolean");
        replaceAll.addProperty("description", "Tüm eşleşmeleri değiştir (mode=replace için, varsayılan: false = sadece ilk eşleşme)");
        props.add("replace_all", replaceAll);

        schema.add("properties", props);
        com.google.gson.JsonArray required = new com.google.gson.JsonArray();
        required.add("path");
        required.add("mode");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String filePath = input.get("path").getAsString();
        String mode = input.has("mode") ? input.get("mode").getAsString() : "lines";
        Path path = Path.of(filePath);

        if (!Files.exists(path)) {
            return "HATA: Dosya bulunamadı: " + filePath;
        }

        if ("replace".equals(mode)) {
            return executeReplace(path, filePath, input);
        } else {
            return executeLines(path, filePath, input);
        }
    }

    private String executeLines(Path path, String filePath, JsonObject input) throws Exception {
        if (!input.has("start_line") || !input.has("end_line")) {
            return "HATA: mode=lines için start_line ve end_line zorunludur.";
        }
        int startLine = input.get("start_line").getAsInt();
        int endLine = input.get("end_line").getAsInt();
        String newContent = input.has("new_content") && !input.get("new_content").isJsonNull()
                            ? input.get("new_content").getAsString() : "";

        List<String> lines = new ArrayList<>(Files.readAllLines(path));
        int total = lines.size();

        if (startLine < 1 || startLine > total) {
            return "HATA: Geçersiz start_line=" + startLine + " (Toplam satır: " + total + ")";
        }
        if (endLine < startLine || endLine > total) {
            return "HATA: Geçersiz end_line=" + endLine;
        }

        List<String> before = lines.subList(0, startLine - 1);
        List<String> after = lines.subList(endLine, lines.size());
        List<String> replacement = newContent.isEmpty() ? List.of() : List.of(newContent.split("\n", -1));

        List<String> result = new ArrayList<>();
        result.addAll(before);
        result.addAll(replacement);
        result.addAll(after);

        Files.write(path, result);

        int removed = endLine - startLine + 1;
        int added = replacement.size();
        return String.format(
            "Düzenlendi: %s\nSatır %d-%d değiştirildi (%d satır silindi, %d satır eklendi)\nYeni toplam: %d satır",
            filePath, startLine, endLine, removed, added, result.size()
        );
    }

    private String executeReplace(Path path, String filePath, JsonObject input) throws Exception {
        if (!input.has("old_text") || !input.has("new_text")) {
            return "HATA: mode=replace için old_text ve new_text zorunludur.";
        }
        String oldText = input.get("old_text").getAsString();
        String newText = input.get("new_text").getAsString();
        boolean replaceAll = input.has("replace_all") && !input.get("replace_all").isJsonNull()
                             && input.get("replace_all").getAsBoolean();

        String content = Files.readString(path);

        if (!content.contains(oldText)) {
            return "HATA: Metin bulunamadı: \"" + truncate(oldText, 50) + "\"";
        }

        int count = 0;
        String result;
        if (replaceAll) {
            count = countOccurrences(content, oldText);
            result = content.replace(oldText, newText);
        } else {
            count = 1;
            result = content.replaceFirst(java.util.regex.Pattern.quote(oldText), java.util.regex.Matcher.quoteReplacement(newText));
        }

        Files.writeString(path, result);
        return String.format(
            "Değiştirildi: %s\n%d adet \"%s\" → \"%s\" olarak değiştirildi",
            filePath, count, truncate(oldText, 30), truncate(newText, 30)
        );
    }

    private int countOccurrences(String text, String pattern) {
        int count = 0;
        int idx = 0;
        while ((idx = text.indexOf(pattern, idx)) != -1) {
            count++;
            idx += pattern.length();
        }
        return count;
    }

    private String truncate(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}
