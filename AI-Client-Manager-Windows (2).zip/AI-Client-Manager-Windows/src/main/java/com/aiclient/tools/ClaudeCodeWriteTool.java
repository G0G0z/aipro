package com.aiclient.tools;

import com.google.gson.JsonObject;

/**
 * Handles the "Write" tool injected by the Aerolink/Claude Code proxy.
 * Claude Code Write format: { "file_path": "...", "content": "..." }
 */
public class ClaudeCodeWriteTool implements Tool {

    private final FileWriteTool delegate = new FileWriteTool();

    @Override public String getName() { return "Write"; }
    @Override public String getDescription() { return "Write a file"; }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        JsonObject mapped = new JsonObject();

        String path = input.has("file_path") ? input.get("file_path").getAsString()
                    : input.has("path") ? input.get("path").getAsString() : null;
        if (path != null) mapped.addProperty("path", path);

        String content = input.has("content") ? input.get("content").getAsString() : "";
        mapped.addProperty("content", content);

        return delegate.execute(mapped);
    }
}
