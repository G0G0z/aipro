package com.aiclient.tools;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

/**
 * Handles the "MultiEdit" tool injected by the Aerolink/Claude Code proxy.
 * Claude Code MultiEdit format: { "file_path": "...", "edits": [{"old_string":"...","new_string":"..."}] }
 */
public class ClaudeCodeMultiEditTool implements Tool {

    private final FileEditTool delegate = new FileEditTool();

    @Override public String getName() { return "MultiEdit"; }
    @Override public String getDescription() { return "Apply multiple edits to a file"; }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String path = input.has("file_path") ? input.get("file_path").getAsString()
                    : input.has("path") ? input.get("path").getAsString() : null;

        if (path == null) return "HATA: file_path belirtilmedi";

        JsonArray edits = input.has("edits") ? input.getAsJsonArray("edits") : new JsonArray();
        StringBuilder results = new StringBuilder();
        int i = 0;
        for (JsonElement elem : edits) {
            i++;
            JsonObject edit = elem.getAsJsonObject();
            JsonObject mapped = new JsonObject();
            mapped.addProperty("path", path);
            mapped.addProperty("mode", "replace");
            if (edit.has("old_string")) mapped.addProperty("old_text", edit.get("old_string").getAsString());
            if (edit.has("new_string")) mapped.addProperty("new_text", edit.get("new_string").getAsString());
            results.append("Düzenleme ").append(i).append(": ").append(delegate.execute(mapped)).append("\n");
        }
        return results.toString().trim();
    }
}
