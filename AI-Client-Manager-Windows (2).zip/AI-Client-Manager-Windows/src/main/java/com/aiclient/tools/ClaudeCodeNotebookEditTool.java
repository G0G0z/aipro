package com.aiclient.tools;

import com.google.gson.JsonObject;

/** Handles NotebookEdit injected by proxy — returns informational message. */
public class ClaudeCodeNotebookEditTool implements Tool {

    @Override public String getName() { return "NotebookEdit"; }
    @Override public String getDescription() { return "Edit a notebook cell"; }

    @Override
    public JsonObject getInputSchema() {
        JsonObject s = new JsonObject(); s.addProperty("type","object"); return s;
    }

    @Override
    public String execute(JsonObject input) {
        return "{\"success\":true,\"message\":\"Notebook edit acknowledged\"}";
    }
}
