package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.nio.file.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Handles the "Glob" tool injected by the Aerolink/Claude Code proxy.
 * Claude Code Glob format: { "pattern": "...", "path": "..." }
 */
public class ClaudeCodeGlobTool implements Tool {

    @Override public String getName() { return "Glob"; }
    @Override public String getDescription() { return "Find files matching a glob pattern"; }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String pattern = input.has("pattern") ? input.get("pattern").getAsString() : "**/*";
        String base = input.has("path") ? input.get("path").getAsString() : ".";

        Path basePath = Path.of(base);
        PathMatcher matcher = FileSystems.getDefault().getPathMatcher("glob:" + pattern);

        List<String> matches;
        try (var stream = Files.walk(basePath)) {
            matches = stream
                .filter(Files::isRegularFile)
                .filter(p -> matcher.matches(basePath.relativize(p)))
                .map(Path::toString)
                .sorted()
                .limit(200)
                .collect(Collectors.toList());
        }

        if (matches.isEmpty()) return "Eşleşen dosya bulunamadı: " + pattern;
        StringBuilder sb = new StringBuilder();
        sb.append("Eşleşen ").append(matches.size()).append(" dosya (pattern: ").append(pattern).append("):\n");
        for (String m : matches) sb.append(m).append("\n");
        return sb.toString();
    }
}
