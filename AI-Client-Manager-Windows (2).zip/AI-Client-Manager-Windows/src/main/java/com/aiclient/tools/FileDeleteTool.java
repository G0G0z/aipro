package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.io.IOException;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.Comparator;

public class FileDeleteTool implements Tool {

    @Override
    public String getName() { return "delete_file"; }

    @Override
    public String getDescription() {
        return "Bir dosyayı veya boş olmayan bir dizini siler. " +
               "recursive=true ile dolu dizinleri de silebilir (dikkatli kullanın!).";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();

        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Silinecek dosya veya dizinin yolu");
        props.add("path", path);

        JsonObject recursive = new JsonObject();
        recursive.addProperty("type", "boolean");
        recursive.addProperty("description", "Dizini tüm içeriğiyle birlikte sil (varsayılan: false)");
        props.add("recursive", recursive);

        schema.add("properties", props);
        com.google.gson.JsonArray required = new com.google.gson.JsonArray();
        required.add("path");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String filePath = input.get("path").getAsString();
        boolean recursive = input.has("recursive") && !input.get("recursive").isJsonNull()
                            && input.get("recursive").getAsBoolean();

        Path path = Path.of(filePath);

        if (!Files.exists(path)) {
            return "HATA: Dosya/dizin bulunamadı: " + filePath;
        }

        String type = Files.isDirectory(path) ? "Dizin" : "Dosya";

        if (Files.isDirectory(path)) {
            if (!recursive) {
                try (var stream = Files.list(path)) {
                    if (stream.findAny().isPresent()) {
                        return "HATA: Dizin boş değil. Silmek için recursive=true kullanın: " + filePath;
                    }
                }
            }
            deleteRecursively(path);
        } else {
            Files.delete(path);
        }

        return type + " silindi: " + filePath;
    }

    private void deleteRecursively(Path path) throws IOException {
        Files.walkFileTree(path, new SimpleFileVisitor<>() {
            @Override
            public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                Files.delete(file);
                return FileVisitResult.CONTINUE;
            }
            @Override
            public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                Files.delete(dir);
                return FileVisitResult.CONTINUE;
            }
        });
    }
}
