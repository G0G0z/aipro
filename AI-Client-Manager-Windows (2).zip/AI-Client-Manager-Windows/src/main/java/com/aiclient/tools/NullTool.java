package com.aiclient.tools;

import com.google.gson.JsonObject;

/**
 * Stub tool that accepts any input and returns an empty success response.
 * Used for proxy-injected tools we don't need (query_registry_agentry, etc.)
 */
public class NullTool implements Tool {

    private final String name;

    public NullTool(String name) {
        this.name = name;
    }

    @Override public String getName() { return name; }
    @Override public String getDescription() { return "Internal tool (handled by proxy)"; }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        schema.add("properties", new JsonObject());
        return schema;
    }

    @Override
    public String execute(JsonObject input) {
        return "{\"result\":[],\"success\":true}";
    }
}
