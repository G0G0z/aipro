package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public class FileWriteTool implements Tool {

    @Override
    public String getName() { return "write_file"; }

    @Override
    public String getDescription() {
        return "Bir dosyaya içerik yazar. Dosya yoksa oluşturur, varsa üzerine yazar veya ekler. " +
               "Üst klasörler otomatik oluşturulur.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();

        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Yazılacak dosyanın yolu");
        props.add("path", path);

        JsonObject content = new JsonObject();
        content.addProperty("type", "string");
        content.addProperty("description", "Dosyaya yazılacak içerik");
        props.add("content", content);

        JsonObject append = new JsonObject();
        append.addProperty("type", "boolean");
        append.addProperty("description", "true ise dosyanın sonuna ekle, false ise üzerine yaz (varsayılan: false)");
        props.add("append", append);

        schema.add("properties", props);
        com.google.gson.JsonArray required = new com.google.gson.JsonArray();
        required.add("path");
        required.add("content");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String filePath = input.get("path").getAsString();
        String content = input.get("content").getAsString();
        boolean append = input.has("append") && !input.get("append").isJsonNull()
                         && input.get("append").getAsBoolean();

        Path path = Path.of(filePath);

        if (path.getParent() != null) {
            Files.createDirectories(path.getParent());
        }

        boolean existed = Files.exists(path);

        if (append) {
            Files.writeString(path, content, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } else {
            Files.writeString(path, content, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
        }

        long fileSize = Files.size(path);
        int lineCount = content.split("\n", -1).length;

        return String.format(
            "%s: %s\nİşlem: %s\nSatır sayısı: %d\nDosya boyutu: %s",
            existed ? "Güncellendi" : "Oluşturuldu",
            filePath,
            append ? "Eklendi (append)" : "Üzerine yazıldı (overwrite)",
            lineCount,
            formatSize(fileSize)
        );
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.1f MB", bytes / (1024.0 * 1024));
    }
}
