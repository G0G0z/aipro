package com.aiclient.tools;

import com.google.gson.JsonObject;

public interface Tool {
    String getName();
    String getDescription();
    JsonObject getInputSchema();
    String execute(JsonObject input) throws Exception;
}
