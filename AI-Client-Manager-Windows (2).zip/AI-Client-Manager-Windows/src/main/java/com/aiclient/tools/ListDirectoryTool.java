package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ListDirectoryTool implements Tool {

    private static final DateTimeFormatter FMT =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(ZoneId.systemDefault());

    @Override
    public String getName() { return "list_directory"; }

    @Override
    public String getDescription() {
        return "Bir dizinin içeriğini listeler. Dosya boyutları, türleri ve değiştirilme tarihleri gösterilir. " +
               "Özyinelemeli listeleme ve gizli dosyaları gösterme desteklenir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();

        JsonObject path = new JsonObject();
        path.addProperty("type", "string");
        path.addProperty("description", "Listelenecek dizinin yolu (varsayılan: mevcut dizin '.')");
        props.add("path", path);

        JsonObject recursive = new JsonObject();
        recursive.addProperty("type", "boolean");
        recursive.addProperty("description", "Alt dizinleri de listele (varsayılan: false)");
        props.add("recursive", recursive);

        JsonObject showHidden = new JsonObject();
        showHidden.addProperty("type", "boolean");
        showHidden.addProperty("description", "Nokta ile başlayan gizli dosyaları göster (varsayılan: false)");
        props.add("show_hidden", showHidden);

        JsonObject maxDepth = new JsonObject();
        maxDepth.addProperty("type", "integer");
        maxDepth.addProperty("description", "Maksimum derinlik (recursive=true için, varsayılan: 3)");
        props.add("max_depth", maxDepth);

        schema.add("properties", props);
        com.google.gson.JsonArray required = new com.google.gson.JsonArray();
        required.add("path");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String dirPath = input.has("path") && !input.get("path").isJsonNull()
                         ? input.get("path").getAsString() : ".";
        boolean recursive = input.has("recursive") && !input.get("recursive").isJsonNull()
                            && input.get("recursive").getAsBoolean();
        boolean showHidden = input.has("show_hidden") && !input.get("show_hidden").isJsonNull()
                             && input.get("show_hidden").getAsBoolean();
        int maxDepth = input.has("max_depth") && !input.get("max_depth").isJsonNull()
                       ? input.get("max_depth").getAsInt() : 3;

        Path path = Path.of(dirPath);

        if (!Files.exists(path)) {
            return "HATA: Dizin bulunamadı: " + dirPath;
        }
        if (!Files.isDirectory(path)) {
            return "HATA: Bu bir dosya, dizin değil: " + dirPath;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Dizin: ").append(path.toAbsolutePath()).append("\n");
        sb.append("─".repeat(70)).append("\n");
        sb.append(String.format("%-6s %-10s %-17s %s%n", "TÜR", "BOYUT", "TARİH", "İSİM"));
        sb.append("─".repeat(70)).append("\n");

        int[] counts = {0, 0};

        if (recursive) {
            listRecursive(path, path, sb, showHidden, maxDepth, 0, counts);
        } else {
            listFlat(path, sb, showHidden, counts);
        }

        sb.append("─".repeat(70)).append("\n");
        sb.append(String.format("Toplam: %d dosya, %d klasör", counts[0], counts[1]));

        return sb.toString();
    }

    private void listFlat(Path dir, StringBuilder sb, boolean showHidden, int[] counts) throws Exception {
        List<Path> entries;
        try (Stream<Path> stream = Files.list(dir)) {
            entries = stream
                .filter(p -> showHidden || !p.getFileName().toString().startsWith("."))
                .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase()))
                .collect(Collectors.toList());
        }

        List<Path> dirs = entries.stream().filter(Files::isDirectory).toList();
        List<Path> files = entries.stream().filter(p -> !Files.isDirectory(p)).toList();

        for (Path p : dirs) {
            appendEntry(p, sb, 0);
            counts[1]++;
        }
        for (Path p : files) {
            appendEntry(p, sb, 0);
            counts[0]++;
        }
    }

    private void listRecursive(Path base, Path dir, StringBuilder sb, boolean showHidden, int maxDepth, int depth, int[] counts) throws Exception {
        if (depth > maxDepth) return;

        List<Path> entries;
        try (Stream<Path> stream = Files.list(dir)) {
            entries = stream
                .filter(p -> showHidden || !p.getFileName().toString().startsWith("."))
                .sorted(Comparator.comparing(p -> p.getFileName().toString().toLowerCase()))
                .collect(Collectors.toList());
        }

        List<Path> dirs = entries.stream().filter(Files::isDirectory).toList();
        List<Path> files = entries.stream().filter(p -> !Files.isDirectory(p)).toList();

        for (Path p : dirs) {
            appendEntry(p, sb, depth);
            counts[1]++;
            listRecursive(base, p, sb, showHidden, maxDepth, depth + 1, counts);
        }
        for (Path p : files) {
            appendEntry(p, sb, depth);
            counts[0]++;
        }
    }

    private void appendEntry(Path p, StringBuilder sb, int depth) throws Exception {
        boolean isDir = Files.isDirectory(p);
        String type = isDir ? "📁 DİZ" : "📄 DOS";
        String size = isDir ? "—" : formatSize(Files.size(p));
        String modified;
        try {
            BasicFileAttributes attrs = Files.readAttributes(p, BasicFileAttributes.class);
            modified = FMT.format(attrs.lastModifiedTime().toInstant());
        } catch (Exception e) {
            modified = "—";
        }
        String indent = "  ".repeat(depth);
        String name = indent + p.getFileName().toString() + (isDir ? "/" : "");
        sb.append(String.format("%-6s %-10s %-17s %s%n", type, size, modified, name));
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.1f GB", bytes / (1024.0 * 1024 * 1024));
    }
}
