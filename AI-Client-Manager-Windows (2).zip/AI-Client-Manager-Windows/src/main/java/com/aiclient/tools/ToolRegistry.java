package com.aiclient.tools;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.*;

/**
 * Tool registry that handles both our custom tools and the Claude Code tools
 * injected by the Aerolink proxy (Bash, Read, Write, Edit, LS, Glob, Grep, etc.)
 */
public class ToolRegistry {

    private final Map<String, Tool> tools = new LinkedHashMap<>();
    /** normalized name (lowercase, alpha only) → tool */
    private final Map<String, Tool> normalizedLookup = new LinkedHashMap<>();

    public ToolRegistry() {
        // Our custom tools
        register(new FileReadTool());
        register(new FileWriteTool());
        register(new FileEditTool());
        register(new FileDeleteTool());
        register(new ListDirectoryTool());
        register(new SearchFilesTool());
        register(new ExecuteCommandTool());
        register(new MakeDirectoryTool());
        register(new MoveFileTool());
        register(new FileInfoTool());

        // Claude Code proxy-injected tool adapters
        register(new ClaudeCodeBashTool());
        register(new ClaudeCodeReadTool());
        register(new ClaudeCodeWriteTool());
        register(new ClaudeCodeEditTool());
        register(new ClaudeCodeLsTool());
        register(new ClaudeCodeGlobTool());
        register(new ClaudeCodeGrepTool());
        register(new ClaudeCodeMultiEditTool());
        register(new ClaudeCodeNotebookReadTool());
        register(new ClaudeCodeNotebookEditTool());
        register(new NullTool("query_registry_agentry"));
        register(new NullTool("worker_tree_monitorset"));
        register(new NullTool("TodoRead"));
        register(new NullTool("TodoWrite"));
        register(new NullTool("WebSearch"));
        register(new NullTool("WebFetch"));
    }

    private void register(Tool tool) {
        tools.put(tool.getName(), tool);
        String normalized = tool.getName().toLowerCase().replaceAll("[^a-z]", "");
        normalizedLookup.put(normalized, tool);
    }

    /**
     * Exact match first; fuzzy match for proxy-renamed tools (e.g. CompatListDirectory8d16cf).
     */
    public Tool get(String name) {
        if (name == null) return null;

        // 1. Exact match
        Tool exact = tools.get(name);
        if (exact != null) return exact;

        // 2. Case-insensitive exact match
        for (Map.Entry<String, Tool> e : tools.entrySet()) {
            if (e.getKey().equalsIgnoreCase(name)) return e.getValue();
        }

        // 3. Fuzzy: normalize incoming and check contains
        String incoming = name.toLowerCase().replaceAll("[^a-z]", "");
        for (Map.Entry<String, Tool> entry : normalizedLookup.entrySet()) {
            if (incoming.contains(entry.getKey()) || entry.getKey().contains(incoming)) {
                return entry.getValue();
            }
        }

        return null;
    }

    public List<Tool> getAll() {
        return new ArrayList<>(tools.values());
    }

    public JsonArray toApiFormat() {
        JsonArray array = new JsonArray();
        // Only send our primary custom tools (not the adapters or null tools)
        String[] primary = {"read_file","write_file","edit_file","delete_file",
                            "list_directory","search_files","execute_command",
                            "make_directory","move_file","file_info"};
        for (String name : primary) {
            Tool tool = tools.get(name);
            if (tool == null) continue;
            JsonObject obj = new JsonObject();
            obj.addProperty("name", tool.getName());
            obj.addProperty("description", tool.getDescription());
            obj.add("input_schema", tool.getInputSchema());
            array.add(obj);
        }
        return array;
    }
}
