package com.aiclient.tools;

import com.google.gson.JsonObject;

/**
 * Handles the "LS" tool injected by the Aerolink/Claude Code proxy.
 * Claude Code LS format: { "path": "..." }
 */
public class ClaudeCodeLsTool implements Tool {

    private final ListDirectoryTool delegate = new ListDirectoryTool();

    @Override public String getName() { return "LS"; }
    @Override public String getDescription() { return "List directory"; }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        return delegate.execute(input);
    }
}
