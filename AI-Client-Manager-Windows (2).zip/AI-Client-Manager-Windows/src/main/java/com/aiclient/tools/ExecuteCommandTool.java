package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ExecuteCommandTool implements Tool {

    private static final int DEFAULT_TIMEOUT = 30;
    private static final int MAX_OUTPUT_CHARS = 8000;

    @Override
    public String getName() { return "execute_command"; }

    @Override
    public String getDescription() {
        return "Bir kabuk (shell) komutunu çalıştırır ve çıktısını döndürür. " +
               "stdout ve stderr ayrı ayrı gösterilir. Çalışma dizini belirtilebilir. " +
               "Zaman aşımı varsayılan 30 saniyedir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();

        JsonObject command = new JsonObject();
        command.addProperty("type", "string");
        command.addProperty("description", "Çalıştırılacak kabuk komutu (bash -c ile çalıştırılır)");
        props.add("command", command);

        JsonObject workingDir = new JsonObject();
        workingDir.addProperty("type", "string");
        workingDir.addProperty("description", "Komutun çalıştırılacağı dizin (varsayılan: mevcut dizin)");
        props.add("working_directory", workingDir);

        JsonObject timeout = new JsonObject();
        timeout.addProperty("type", "integer");
        timeout.addProperty("description", "Zaman aşımı saniye olarak (varsayılan: 30, maksimum: 120)");
        props.add("timeout_seconds", timeout);

        schema.add("properties", props);
        com.google.gson.JsonArray required = new com.google.gson.JsonArray();
        required.add("command");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        String command = input.get("command").getAsString();
        String workingDir = input.has("working_directory") && !input.get("working_directory").isJsonNull()
                            ? input.get("working_directory").getAsString() : null;
        int timeoutSeconds = input.has("timeout_seconds") && !input.get("timeout_seconds").isJsonNull()
                             ? Math.min(120, input.get("timeout_seconds").getAsInt()) : DEFAULT_TIMEOUT;

        // OS'a göre uygun shell seç (Windows: cmd, Unix: bash)
        ProcessBuilder pb;
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) {
            pb = new ProcessBuilder("cmd.exe", "/c", command);
        } else {
            pb = new ProcessBuilder("bash", "-c", command);
        }
        pb.redirectErrorStream(false);

        if (workingDir != null) {
            pb.directory(Path.of(workingDir).toFile());
        }

        if (!os.contains("win")) {
            pb.environment().put("TERM", "xterm-256color");
        }

        long startTime = System.currentTimeMillis();
        Process process = pb.start();

        StringBuilder stdout = new StringBuilder();
        StringBuilder stderr = new StringBuilder();

        Thread stdoutThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (stdout.length() < MAX_OUTPUT_CHARS) {
                        stdout.append(line).append("\n");
                    }
                }
            } catch (IOException ignored) {}
        });

        Thread stderrThread = new Thread(() -> {
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getErrorStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (stderr.length() < MAX_OUTPUT_CHARS) {
                        stderr.append(line).append("\n");
                    }
                }
            } catch (IOException ignored) {}
        });

        stdoutThread.start();
        stderrThread.start();

        boolean finished = process.waitFor(timeoutSeconds, TimeUnit.SECONDS);
        stdoutThread.join(1000);
        stderrThread.join(1000);

        long elapsed = System.currentTimeMillis() - startTime;
        StringBuilder result = new StringBuilder();

        result.append("Komut: ").append(command).append("\n");
        if (workingDir != null) result.append("Dizin: ").append(workingDir).append("\n");
        result.append("Süre: ").append(elapsed).append(" ms\n");

        if (!finished) {
            process.destroyForcibly();
            result.append("Durum: ZAMAN AŞIMI (").append(timeoutSeconds).append("s)\n");
        } else {
            int exitCode = process.exitValue();
            result.append("Çıkış kodu: ").append(exitCode).append(exitCode == 0 ? " (başarılı)" : " (hata)").append("\n");
        }

        result.append("─".repeat(50)).append("\n");

        if (!stdout.isEmpty()) {
            result.append("STDOUT:\n");
            String out = stdout.toString();
            if (out.length() > MAX_OUTPUT_CHARS) {
                out = out.substring(0, MAX_OUTPUT_CHARS) + "\n... (çıktı kesildi)";
            }
            result.append(out);
        } else {
            result.append("STDOUT: (boş)\n");
        }

        if (!stderr.isEmpty()) {
            result.append("\nSTDERR:\n").append(stderr);
        }

        return result.toString();
    }
}
