package com.aiclient.tools;

import com.google.gson.JsonObject;

/**
 * Handles the "Bash" tool injected by the Aerolink/Claude Code proxy.
 * Claude Code Bash format: { "command": "...", "description": "...", "timeout": 30000 }
 */
public class ClaudeCodeBashTool implements Tool {

    private final ExecuteCommandTool delegate = new ExecuteCommandTool();

    @Override public String getName() { return "Bash"; }
    @Override public String getDescription() { return "Execute a bash command"; }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();
        JsonObject cmd = new JsonObject();
        cmd.addProperty("type", "string");
        props.add("command", cmd);
        schema.add("properties", props);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        // Map Claude Code Bash format to our execute_command format
        JsonObject mapped = new JsonObject();

        if (input.has("command")) {
            mapped.addProperty("command", input.get("command").getAsString());
        } else if (input.has("cmd")) {
            mapped.addProperty("command", input.get("cmd").getAsString());
        }

        if (input.has("timeout")) {
            int timeoutMs = input.get("timeout").getAsInt();
            mapped.addProperty("timeout_seconds", Math.min(120, timeoutMs / 1000));
        }

        return delegate.execute(mapped);
    }
}
