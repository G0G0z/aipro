package com.aiclient.tools;

import com.google.gson.JsonObject;
import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import java.util.stream.Collectors;

public class SearchFilesTool implements Tool {

    @Override
    public String getName() { return "search_files"; }

    @Override
    public String getDescription() {
        return "Dosyalar içinde metin veya regex pattern arar. grep benzeri işlevsellik. " +
               "Belirli uzantıları filtreler, context satırları gösterir.";
    }

    @Override
    public JsonObject getInputSchema() {
        JsonObject schema = new JsonObject();
        schema.addProperty("type", "object");
        JsonObject props = new JsonObject();

        JsonObject directory = new JsonObject();
        directory.addProperty("type", "string");
        directory.addProperty("description", "Arama yapılacak dizin (varsayılan: mevcut dizin)");
        props.add("directory", directory);

        JsonObject pattern = new JsonObject();
        pattern.addProperty("type", "string");
        pattern.addProperty("description", "Aranacak metin veya regex pattern");
        props.add("pattern", pattern);

        JsonObject filePattern = new JsonObject();
        filePattern.addProperty("type", "string");
        filePattern.addProperty("description", "Dosya adı filtresi, glob formatında (örn: *.java, *.py). Varsayılan: tüm dosyalar");
        props.add("file_pattern", filePattern);

        JsonObject ignoreCase = new JsonObject();
        ignoreCase.addProperty("type", "boolean");
        ignoreCase.addProperty("description", "Büyük/küçük harf farkını görmezden gel (varsayılan: false)");
        props.add("ignore_case", ignoreCase);

        JsonObject contextLines = new JsonObject();
        contextLines.addProperty("type", "integer");
        contextLines.addProperty("description", "Eşleşme etrafında gösterilecek bağlam satırı sayısı (varsayılan: 2)");
        props.add("context_lines", contextLines);

        JsonObject maxResults = new JsonObject();
        maxResults.addProperty("type", "integer");
        maxResults.addProperty("description", "Maksimum sonuç sayısı (varsayılan: 50)");
        props.add("max_results", maxResults);

        schema.add("properties", props);
        com.google.gson.JsonArray required = new com.google.gson.JsonArray();
        required.add("pattern");
        schema.add("required", required);
        return schema;
    }

    @Override
    public String execute(JsonObject input) throws Exception {
        final String directory = input.has("directory") && !input.get("directory").isJsonNull()
                           ? input.get("directory").getAsString() : ".";
        final String patternStr = input.get("pattern").getAsString();
        final String fileGlob = input.has("file_pattern") && !input.get("file_pattern").isJsonNull()
                             ? input.get("file_pattern").getAsString() : null;
        final boolean ignoreCase = input.has("ignore_case") && !input.get("ignore_case").isJsonNull()
                             && input.get("ignore_case").getAsBoolean();
        final int contextLines = input.has("context_lines") && !input.get("context_lines").isJsonNull()
                           ? input.get("context_lines").getAsInt() : 2;
        final int maxResults = input.has("max_results") && !input.get("max_results").isJsonNull()
                         ? input.get("max_results").getAsInt() : 50;

        Path searchDir = Path.of(directory);
        if (!Files.exists(searchDir)) {
            return "HATA: Dizin bulunamadı: " + directory;
        }

        int flags = ignoreCase ? Pattern.CASE_INSENSITIVE : 0;
        Pattern searchPattern;
        try {
            searchPattern = Pattern.compile(Pattern.quote(patternStr), flags);
        } catch (PatternSyntaxException e) {
            try {
                searchPattern = Pattern.compile(patternStr, flags);
            } catch (PatternSyntaxException e2) {
                return "HATA: Geçersiz regex pattern: " + e2.getMessage();
            }
        }
        final Pattern finalPattern = searchPattern;

        PathMatcher matcher = fileGlob != null
            ? FileSystems.getDefault().getPathMatcher("glob:" + fileGlob) : null;

        List<Path> allFiles;
        try (var stream = Files.walk(searchDir)) {
            allFiles = stream
                .filter(Files::isRegularFile)
                .filter(p -> {
                    if (matcher == null) return true;
                    return matcher.matches(p.getFileName());
                })
                .collect(Collectors.toList());
        }

        List<String> results = new ArrayList<>();
        int totalMatches = 0;

        for (Path file : allFiles) {
            if (totalMatches >= maxResults) break;
            try {
                if (Files.size(file) > 5 * 1024 * 1024) continue;
                List<String> lines = Files.readAllLines(file);
                for (int i = 0; i < lines.size() && totalMatches < maxResults; i++) {
                    if (finalPattern.matcher(lines.get(i)).find()) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("\n").append("─".repeat(50)).append("\n");
                        sb.append(file).append(":").append(i + 1).append("\n");
                        int start = Math.max(0, i - contextLines);
                        int end = Math.min(lines.size() - 1, i + contextLines);
                        for (int j = start; j <= end; j++) {
                            String prefix = (j == i) ? "→ " : "  ";
                            sb.append(String.format("%s%4d │ %s%n", prefix, j + 1, lines.get(j)));
                        }
                        results.add(sb.toString());
                        totalMatches++;
                    }
                }
            } catch (Exception ignored) {}
        }

        if (results.isEmpty()) {
            return "Sonuç bulunamadı: \"" + patternStr + "\" — " + directory + " dizininde";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("Arama: \"").append(patternStr).append("\"  Dizin: ").append(directory).append("\n");
        sb.append("Bulunan eşleşme: ").append(totalMatches);
        if (totalMatches >= maxResults) sb.append(" (sınıra ulaşıldı)");
        sb.append("\n");
        for (String r : results) sb.append(r);

        return sb.toString();
    }
}
