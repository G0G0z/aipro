package com.aiclient;

import com.aiclient.tools.Tool;
import com.aiclient.tools.ToolRegistry;
import com.google.gson.*;
import java.util.ArrayList;
import java.util.List;

public class Agent {

    private static final String DEFAULT_MODEL = "claude-opus-4-8";
    private static final int MAX_TOKENS = 8096;
    private static final int MAX_TOOL_ITERATIONS = 50;

    private static final String SYSTEM_PROMPT = """
        Sen gelişmiş bir yapay zeka asistanısın ve tam dosya sistemi ile kabuk erişimine sahipsin.

        Sahip olduğun yetenekler:
        - Dosya okuma, yazma, oluşturma, düzenleme ve silme
        - Dizin oluşturma, listeleme ve gezinme
        - Dosyalar içinde metin/regex arama
        - Kabuk komutları çalıştırma (bash)
        - Dosya/dizin taşıma ve yeniden adlandırma
        - Dosya meta bilgilerini görüntüleme

        Kullanıcıya Türkçe olarak yanıt ver.

        Önemli kurallar:
        1. Kod yazmadan önce mevcut kodu oku (okuma aracını kullan)
        2. Değişiklik yaparken dikkatli ve özenli ol
        3. Silme işlemlerinden önce kullanıcıyı uyar
        4. Uzun çıktıları özetle ve en önemli kısımları vurgula
        5. Hata durumunda hatanın sebebini açıkla ve çözüm öner
        6. Birden fazla adım gerektiren görevlerde adım adım ilerle
        7. Araçları etkin kullan, gereksiz araç çağrısından kaçın

        Mevcut çalışma dizini: kullanıcının başlattığı dizin.
        """;

    private final AnthropicClient client;
    private final ToolRegistry toolRegistry;
    private final List<JsonObject> conversationHistory;
    private String currentModel;
    private int totalInputTokens;
    private int totalOutputTokens;
    private final Gson gson;

    public Agent(AnthropicClient client) {
        this.client = client;
        this.toolRegistry = new ToolRegistry();
        this.conversationHistory = new ArrayList<>();
        this.currentModel = DEFAULT_MODEL;
        this.totalInputTokens = 0;
        this.totalOutputTokens = 0;
        this.gson = new GsonBuilder().create();
    }

    public String chat(String userMessage) throws Exception {
        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", userMessage);
        conversationHistory.add(userMsg);

        StringBuilder finalResponse = new StringBuilder();
        int iterations = 0;

        while (iterations < MAX_TOOL_ITERATIONS) {
            iterations++;

            AnthropicClient.ApiResponse response = client.sendMessages(
                currentModel,
                SYSTEM_PROMPT,
                conversationHistory,
                toolRegistry.toApiFormat(),
                MAX_TOKENS
            );

            totalInputTokens += response.usage().inputTokens();
            totalOutputTokens += response.usage().outputTokens();

            JsonObject assistantMsg = new JsonObject();
            assistantMsg.addProperty("role", "assistant");
            assistantMsg.add("content", response.content());
            conversationHistory.add(assistantMsg);

            boolean hasText = false;
            for (JsonElement elem : response.content()) {
                JsonObject block = elem.getAsJsonObject();
                String type = block.get("type").getAsString();
                if ("text".equals(type)) {
                    String text = block.get("text").getAsString();
                    if (!text.isBlank()) {
                        if (hasText) finalResponse.append("\n");
                        finalResponse.append(text);
                        hasText = true;
                    }
                }
            }

            if (!"tool_use".equals(response.stopReason())) {
                break;
            }

            List<JsonObject> toolResults = new ArrayList<>();
            for (JsonElement elem : response.content()) {
                JsonObject block = elem.getAsJsonObject();
                if (!"tool_use".equals(block.get("type").getAsString())) continue;

                String toolId = block.get("id").getAsString();
                String toolName = block.get("name").getAsString();
                JsonObject toolInput = block.has("input") && block.get("input").isJsonObject()
                    ? block.getAsJsonObject("input") : new JsonObject();

                Terminal.printToolUse(toolName, toolId);

                String toolResult;
                boolean success = true;
                try {
                    Tool tool = toolRegistry.get(toolName);
                    if (tool == null) {
                        toolResult = "HATA: Bilinmeyen araç: " + toolName;
                        success = false;
                    } else {
                        toolResult = tool.execute(toolInput);
                    }
                } catch (Exception e) {
                    toolResult = "HATA: " + e.getMessage();
                    success = false;
                }

                Terminal.printToolResult(toolName, success);

                JsonObject resultContent = new JsonObject();
                resultContent.addProperty("type", "tool_result");
                resultContent.addProperty("tool_use_id", toolId);
                resultContent.addProperty("content", toolResult);
                toolResults.add(resultContent);
            }

            if (!toolResults.isEmpty()) {
                JsonObject toolResultMsg = new JsonObject();
                toolResultMsg.addProperty("role", "user");
                JsonArray contentArray = new JsonArray();
                for (JsonObject r : toolResults) contentArray.add(r);
                toolResultMsg.add("content", contentArray);
                conversationHistory.add(toolResultMsg);
            }
        }

        if (iterations >= MAX_TOOL_ITERATIONS) {
            finalResponse.append("\n[Uyarı: Maksimum araç döngüsüne ulaşıldı]");
        }

        return finalResponse.toString().trim();
    }

    public void resetHistory() {
        conversationHistory.clear();
        Terminal.printInfo("Sohbet geçmişi temizlendi.");
    }

    public void printHistory() {
        if (conversationHistory.isEmpty()) {
            Terminal.printInfo("Sohbet geçmişi boş.");
            return;
        }
        System.out.println();
        int msgNum = 0;
        for (JsonObject msg : conversationHistory) {
            String role = msg.get("role").getAsString();
            if ("user".equals(role) && msg.get("content").isJsonPrimitive()) {
                msgNum++;
                String content = msg.get("content").getAsString();
                System.out.println(Terminal.BOLD + Terminal.GREEN + "  [" + msgNum + "] Siz: " + Terminal.RESET
                    + content.substring(0, Math.min(80, content.length()))
                    + (content.length() > 80 ? "..." : ""));
            } else if ("assistant".equals(role)) {
                JsonArray content = msg.getAsJsonArray("content");
                if (content != null) {
                    for (JsonElement e : content) {
                        JsonObject block = e.getAsJsonObject();
                        if ("text".equals(block.get("type").getAsString())) {
                            String text = block.get("text").getAsString();
                            System.out.println(Terminal.BOLD + Terminal.BLUE + "  Claude: " + Terminal.RESET
                                + text.substring(0, Math.min(80, text.length()))
                                + (text.length() > 80 ? "..." : ""));
                        }
                    }
                }
            }
        }
        System.out.println();
    }

    public void printTokenUsage() {
        Terminal.printTokenUsage(totalInputTokens, totalOutputTokens, totalInputTokens + totalOutputTokens);
    }

    public void setModel(String model) {
        this.currentModel = model;
        Terminal.printInfo("Model değiştirildi: " + model);
    }

    public String getModel() { return currentModel; }
    public int getHistorySize() { return conversationHistory.size(); }
}
