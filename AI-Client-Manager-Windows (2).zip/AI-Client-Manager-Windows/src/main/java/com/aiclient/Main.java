package com.aiclient;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        AnthropicClient client = AnthropicClient.fromEnvironment();
        Agent agent = new Agent(client);

        Terminal.printBanner();
        System.out.println(Terminal.DIM + "  Model : " + agent.getModel() + Terminal.RESET);
        System.out.println(Terminal.DIM + "  API   : " + client.getBaseUrl() + Terminal.RESET);
        System.out.println();

        Scanner scanner = new Scanner(System.in);

        while (true) {
            Terminal.printUserPrompt();

            String input;
            try {
                input = scanner.nextLine();
            } catch (Exception e) {
                System.out.println();
                Terminal.printInfo("Girdi akışı kapandı. Çıkılıyor...");
                break;
            }

            if (input == null) break;
            input = input.trim();
            if (input.isEmpty()) continue;

            String lower = input.toLowerCase();

            if ("exit".equals(lower) || "quit".equals(lower) || "çıkış".equals(lower)) {
                System.out.println();
                Terminal.printInfo("Görüşmek üzere!");
                break;
            }

            if ("clear".equals(lower) || "cls".equals(lower)) {
                System.out.print("\033[H\033[2J");
                System.out.flush();
                Terminal.printBanner();
                continue;
            }

            if ("help".equals(lower) || "yardım".equals(lower)) {
                Terminal.printHelp();
                continue;
            }

            if ("reset".equals(lower) || "sıfırla".equals(lower)) {
                agent.resetHistory();
                continue;
            }

            if ("history".equals(lower) || "geçmiş".equals(lower)) {
                agent.printHistory();
                continue;
            }

            if ("tokens".equals(lower)) {
                agent.printTokenUsage();
                continue;
            }

            if (lower.startsWith("model ")) {
                String modelName = input.substring(6).trim();
                if (!modelName.isEmpty()) {
                    agent.setModel(modelName);
                } else {
                    Terminal.printError("Model adı girin. Örnek: model claude-sonnet-4-6");
                }
                continue;
            }

            try {
                Terminal.printAssistantHeader();
                System.out.println();

                String response = agent.chat(input);

                if (response != null && !response.isBlank()) {
                    for (String line : response.split("\n")) {
                        System.out.println("  " + line);
                    }
                }

                System.out.println();
                Terminal.printSeparator();
                agent.printTokenUsage();
                System.out.println();

            } catch (Exception e) {
                System.out.println();
                Terminal.printError(e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName());
                if (System.getenv("DEBUG") != null) {
                    e.printStackTrace();
                }
            }
        }

        scanner.close();
    }
}
