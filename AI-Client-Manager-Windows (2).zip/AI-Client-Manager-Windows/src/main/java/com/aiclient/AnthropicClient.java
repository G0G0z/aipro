package com.aiclient;

import com.google.gson.*;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;

public class AnthropicClient {

    private static final String DEFAULT_BASE_URL = "https://api.anthropic.com";
    private static final String API_VERSION = "2023-06-01";

    private final String apiKey;
    private final String baseUrl;
    private final HttpClient httpClient;
    private final Gson gson;

    public record TokenUsage(int inputTokens, int outputTokens) {
        public int total() { return inputTokens + outputTokens; }
    }

    public record ApiResponse(JsonArray content, String stopReason, TokenUsage usage) {}

    public AnthropicClient(String apiKey, String baseUrl) {
        this.apiKey = apiKey;
        this.baseUrl = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
        this.httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(30))
            .build();
        this.gson = new GsonBuilder().create();
    }

    // Varsayılan Aerolink API anahtarı (CLI modu için)
    private static final String DEFAULT_AEROLINK_KEY = "aero_live_37mV9gjodj4NQ8fmwjQ1ecSilR5M_rM-xDYUAJEr6Xs";
    private static final String DEFAULT_AEROLINK_URL = "https://capi.aerolink.lat";

    public static AnthropicClient fromEnvironment() {
        String apiKey = System.getenv("AEROLINK_API_KEY");
        String baseUrl = DEFAULT_AEROLINK_URL;

        // Ortam değişkeni yoksa varsayılan Aerolink anahtarını kullan
        if (apiKey == null || apiKey.isBlank()) {
            apiKey = DEFAULT_AEROLINK_KEY;
        }

        // Anthropic anahtarı açıkça ayarlanmışsa onu kullan
        String anthropicKey = System.getenv("ANTHROPIC_API_KEY");
        if (anthropicKey != null && !anthropicKey.isBlank()) {
            apiKey = anthropicKey;
            baseUrl = DEFAULT_BASE_URL;
        }

        String customBase = System.getenv("ANTHROPIC_BASE_URL");
        if (customBase != null && !customBase.isBlank()) {
            baseUrl = customBase;
        }

        if (apiKey == null || apiKey.isBlank()) {
            Terminal.printError("API anahtarı bulunamadı. AEROLINK_API_KEY veya ANTHROPIC_API_KEY ayarlayın.");
            System.exit(1);
        }

        return new AnthropicClient(apiKey, baseUrl);
    }

    public String getBaseUrl() { return baseUrl; }

    public ApiResponse sendMessages(
            String model,
            String systemPrompt,
            List<JsonObject> messages,
            JsonArray tools,
            int maxTokens) throws Exception {

        JsonObject requestBody = new JsonObject();
        requestBody.addProperty("model", model);
        requestBody.addProperty("max_tokens", maxTokens);

        if (systemPrompt != null && !systemPrompt.isBlank()) {
            requestBody.addProperty("system", systemPrompt);
        }

        if (tools != null && tools.size() > 0) {
            requestBody.add("tools", tools);
        }

        JsonArray messagesArray = new JsonArray();
        for (JsonObject msg : messages) {
            messagesArray.add(msg);
        }
        requestBody.add("messages", messagesArray);

        String requestJson = gson.toJson(requestBody);
        String endpoint = baseUrl + "/v1/messages";

        HttpRequest.Builder reqBuilder = HttpRequest.newBuilder()
            .uri(URI.create(endpoint))
            .header("Content-Type", "application/json")
            .header("anthropic-version", API_VERSION)
            .POST(HttpRequest.BodyPublishers.ofString(requestJson))
            .timeout(Duration.ofSeconds(120));

        if (baseUrl.contains("aerolink.lat")) {
            reqBuilder.header("x-api-key", apiKey);
        } else {
            reqBuilder.header("x-api-key", apiKey);
            reqBuilder.header("Authorization", "Bearer " + apiKey);
        }

        HttpRequest request = reqBuilder.build();
        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

        String responseBody = response.body();

        if (response.statusCode() != 200) {
            JsonObject errorObj;
            try {
                errorObj = JsonParser.parseString(responseBody).getAsJsonObject();
                String errorMsg = errorObj.has("error")
                    ? errorObj.getAsJsonObject("error").get("message").getAsString()
                    : responseBody;
                throw new RuntimeException("API Hatası [" + response.statusCode() + "]: " + errorMsg);
            } catch (JsonSyntaxException e) {
                throw new RuntimeException("API Hatası [" + response.statusCode() + "]: " + responseBody);
            }
        }

        JsonObject responseJson = JsonParser.parseString(responseBody).getAsJsonObject();
        JsonArray content = responseJson.getAsJsonArray("content");
        String stopReason = responseJson.get("stop_reason").getAsString();

        TokenUsage usage = new TokenUsage(0, 0);
        if (responseJson.has("usage")) {
            JsonObject usageObj = responseJson.getAsJsonObject("usage");
            int inputTokens = usageObj.has("input_tokens") ? usageObj.get("input_tokens").getAsInt() : 0;
            int outputTokens = usageObj.has("output_tokens") ? usageObj.get("output_tokens").getAsInt() : 0;
            usage = new TokenUsage(inputTokens, outputTokens);
        }

        return new ApiResponse(content, stopReason, usage);
    }
}
