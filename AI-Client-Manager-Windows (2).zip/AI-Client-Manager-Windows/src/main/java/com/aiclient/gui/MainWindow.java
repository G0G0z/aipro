package com.aiclient.gui;

import com.aiclient.AnthropicClient;
import com.google.gson.JsonObject;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.dnd.*;
import java.awt.datatransfer.*;
import java.awt.event.*;
import java.io.File;
import java.util.List;
import java.util.List;

/**
 * Ana uygulama penceresi.
 */
public class MainWindow extends JFrame {

    private final AppSettings settings;
    private GUIAgent agent;

    private final SidebarPanel sidebar;
    private final ChatPanel chatPanel;
    private final InputPanel inputPanel;
    private final TokenBar tokenBar;

    private ConversationHistory currentConversation;
    private MessageBubble streamingBubble;
    private SwingWorker<Void, Object[]> currentWorker;

    private static final Color WIN_BG  = new Color(0x0D1117);
    private static final Color TOP_BG  = new Color(0x161B22);

    public MainWindow() {
        super("AI Client Manager v2.0");
        this.settings = AppSettings.getInstance();

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setPreferredSize(new Dimension(1100, 720));
        setMinimumSize(new Dimension(800, 560));

        // Genel arka plan
        getContentPane().setBackground(WIN_BG);

        // Bileşenler
        sidebar    = new SidebarPanel();
        chatPanel  = new ChatPanel();
        inputPanel = new InputPanel();
        tokenBar   = new TokenBar();

        buildLayout();
        bindEvents();
        loadHistory();
        updateTokenBar();
        initAgent();

        pack();
        setLocationRelativeTo(null);

        // Tüm pencereye sürükle-bırak desteği
        setupWindowDropTarget();

        // Eğer API anahtarı yoksa ayarları aç
        if (!settings.hasApiKey()) {
            SwingUtilities.invokeLater(this::openSettings);
        }
    }

    // ─── Layout ──────────────────────────────────────────────────────────────

    private void buildLayout() {
        // Araç çubuğu
        setJMenuBar(buildMenuBar());

        // Ana bölünmüş panel
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, sidebar, buildCenterPanel());
        split.setDividerLocation(240);
        split.setDividerSize(1);
        split.setBorder(null);
        split.setBackground(WIN_BG);

        add(split, BorderLayout.CENTER);
        add(tokenBar, BorderLayout.SOUTH);
    }

    private JPanel buildCenterPanel() {
        JPanel center = new JPanel(new BorderLayout(0, 0));
        center.setBackground(WIN_BG);

        // Üst toolbar
        center.add(buildTopBar(), BorderLayout.NORTH);
        center.add(chatPanel,    BorderLayout.CENTER);
        center.add(inputPanel,   BorderLayout.SOUTH);

        return center;
    }

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout(8, 0));
        bar.setBackground(TOP_BG);
        bar.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0x30363D)),
            new EmptyBorder(8, 12, 8, 12)));

        // Sol: başlık
        JLabel title = new JLabel("🤖  AI Client Manager");
        title.setForeground(new Color(0xE8EAF6));
        title.setFont(title.getFont().deriveFont(Font.BOLD, 15f));
        bar.add(title, BorderLayout.WEST);

        // Sağ: model seçici + butonlar
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        right.setBackground(TOP_BG);

        // Model seçici
        String[] models = {"claude-sonnet-4-6", "claude-opus-4-5", "claude-haiku-3-5",
                           "claude-3-5-sonnet-20241022", "gpt-4o", "gpt-4o-mini"};
        JComboBox<String> modelBox = new JComboBox<>(models);
        modelBox.setEditable(true);
        modelBox.setSelectedItem(settings.getModel());
        modelBox.setToolTipText("Modeli değiştir");
        modelBox.setPreferredSize(new Dimension(200, 28));
        modelBox.addActionListener(e -> {
            String m = modelBox.getSelectedItem() != null ? modelBox.getSelectedItem().toString() : "";
            if (!m.isBlank()) {
                settings.setModel(m);
                settings.save();
                if (agent != null) agent.setModel(m);
                updateTokenBar();
            }
        });
        right.add(modelBox);

        // Temizle butonu
        JButton clearBtn = topButton("🗑  Temizle");
        clearBtn.setToolTipText("Mevcut sohbeti temizle");
        clearBtn.addActionListener(e -> clearCurrentChat());
        right.add(clearBtn);

        // Ayarlar butonu
        JButton settingsBtn = topButton("⚙  Ayarlar");
        settingsBtn.addActionListener(e -> openSettings());
        right.add(settingsBtn);

        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    private JButton topButton(String text) {
        JButton btn = new JButton(text);
        btn.setBackground(new Color(0x21262D));
        btn.setForeground(new Color(0xC9D1D9));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(0x30363D)),
            BorderFactory.createEmptyBorder(4, 10, 4, 10)));
        btn.setFocusPainted(false);
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private JMenuBar buildMenuBar() {
        JMenuBar mb = new JMenuBar();
        mb.setBackground(new Color(0x161B22));
        mb.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0x30363D)));

        JMenu fileMenu = new JMenu("Dosya");
        fileMenu.setForeground(new Color(0xC9D1D9));
        addMenuItem(fileMenu, "Yeni Sohbet", "ctrl N", e -> newChat());
        addMenuItem(fileMenu, "Sohbeti Kaydet", "ctrl S", e -> saveCurrentConversation());
        fileMenu.addSeparator();
        addMenuItem(fileMenu, "Çıkış", "ctrl Q", e -> System.exit(0));

        JMenu viewMenu = new JMenu("Görünüm");
        viewMenu.setForeground(new Color(0xC9D1D9));
        addMenuItem(viewMenu, "Sohbeti Temizle", null, e -> clearCurrentChat());
        addMenuItem(viewMenu, "Geçmişi Yenile", "F5", e -> loadHistory());

        JMenu helpMenu = new JMenu("Yardım");
        helpMenu.setForeground(new Color(0xC9D1D9));
        addMenuItem(helpMenu, "Kullanım Kılavuzu", null, e -> showHelp());
        addMenuItem(helpMenu, "Hakkında", null, e -> showAbout());

        mb.add(fileMenu);
        mb.add(viewMenu);
        mb.add(helpMenu);
        return mb;
    }

    private void addMenuItem(JMenu menu, String text, String accel, ActionListener al) {
        JMenuItem item = new JMenuItem(text);
        if (accel != null) item.setAccelerator(KeyStroke.getKeyStroke(accel));
        item.addActionListener(al);
        menu.add(item);
    }

    // ─── Events ──────────────────────────────────────────────────────────────

    private void bindEvents() {
        sidebar.setOnSelect(this::loadConversation);
        sidebar.setOnNewChat(this::newChat);
        sidebar.setOnDelete(h -> {
            h.delete();
            sidebar.removeConversation(h);
            if (currentConversation == h) newChat();
        });

        inputPanel.setOnSend(this::sendMessage);
        inputPanel.setOnCancel(this::cancelMessage);
    }

    // ─── Agent & API ─────────────────────────────────────────────────────────

    private void initAgent() {
        if (!settings.hasApiKey()) return;
        try {
            AnthropicClient client = new AnthropicClient(
                settings.getEffectiveApiKey(),
                settings.getEffectiveBaseUrl());
            agent = new GUIAgent(client, settings);
        } catch (Exception e) {
            showError("Agent başlatılamadı: " + e.getMessage());
        }
    }

    private void sendMessage(String text) {
        if (agent == null) {
            openSettings();
            return;
        }

        // İlk mesajda karşılamayı temizle
        if (currentConversation == null) {
            newChat();
        }

        // Kullanıcı mesajını ekle
        ChatMessage userMsg = new ChatMessage(ChatMessage.Type.USER, text);
        chatPanel.addMessage(userMsg);
        currentConversation.addMessage(userMsg);
        sidebar.refreshTop(currentConversation);

        // Streaming balonunu hazırla
        streamingBubble = chatPanel.startStreamingMessage();
        final StringBuilder streamBuffer = new StringBuilder();

        inputPanel.setProcessing(true);
        inputPanel.setStatus("⟳  Yanıt bekleniyor…");

        currentWorker = new SwingWorker<>() {
            @Override
            protected Void doInBackground() {
                agent.resetCancel();
                agent.setCallbacks(
                    // Metin gelince
                    chunk -> publish(new Object[]{"TEXT", chunk}),
                    // Araç kullanımı
                    data  -> publish(new Object[]{"TOOL_USE", data[0], data[1]}),
                    // Araç sonucu
                    data  -> publish(new Object[]{"TOOL_RESULT", data[0], data[1], data[2]}),
                    // Tamamlandı
                    ()    -> publish(new Object[]{"DONE"}),
                    // Hata
                    err   -> publish(new Object[]{"ERROR", err})
                );
                agent.chat(text);
                return null;
            }

            @Override
            protected void process(List<Object[]> chunks) {
                for (Object[] ev : chunks) {
                    String type = (String) ev[0];
                    switch (type) {
                        case "TEXT" -> {
                            String chunk = (String) ev[1];
                            streamBuffer.append(chunk);
                            streamingBubble.setText(streamBuffer.toString());
                            chatPanel.scrollToBottom();
                        }
                        case "TOOL_USE" -> {
                            // Araç balonu ekle
                            ChatMessage tm = new ChatMessage(ChatMessage.Type.TOOL_USE,
                                "Araç çalıştırılıyor…", (String) ev[1], false);
                            chatPanel.addMessage(tm);
                            currentConversation.addMessage(tm);
                            inputPanel.setStatus("⚙  Araç: " + ev[1]);
                        }
                        case "TOOL_RESULT" -> {
                            boolean ok = "true".equals(ev[2]);
                            String result = (String) ev[3];
                            // Sonucu kıs
                            String preview = result != null && result.length() > 300
                                ? result.substring(0, 300) + "\n… (çıktı kısaltıldı)" : result;
                            ChatMessage rm = new ChatMessage(ChatMessage.Type.TOOL_RESULT,
                                preview, (String) ev[1], ok);
                            chatPanel.addMessage(rm);
                            currentConversation.addMessage(rm);
                            inputPanel.setStatus("⟳  Yanıt devam ediyor…");
                        }
                        case "DONE" -> onChatDone(streamBuffer.toString(), null);
                        case "ERROR" -> onChatDone(null, (String) ev[1]);
                    }
                }
            }

            @Override
            protected void done() {
                // İptal edildiyse temizle
                if (isCancelled()) onChatDone(streamBuffer.toString(), null);
            }
        };

        currentWorker.execute();
    }

    private void onChatDone(String finalText, String error) {
        chatPanel.finalizeStreamingMessage();

        if (error != null) {
            ChatMessage errMsg = new ChatMessage(ChatMessage.Type.ERROR, error);
            chatPanel.addMessage(errMsg);
            currentConversation.addMessage(errMsg);
        } else if (finalText != null && !finalText.isBlank()) {
            ChatMessage assistantMsg = new ChatMessage(ChatMessage.Type.ASSISTANT, finalText);
            currentConversation.addMessage(assistantMsg);
        }

        inputPanel.setProcessing(false);
        inputPanel.setStatus(" ");
        inputPanel.focus();
        updateTokenBar();
        saveCurrentConversation();
        sidebar.refreshTop(currentConversation);
    }

    private void cancelMessage() {
        if (agent != null) agent.cancel();
        if (currentWorker != null) currentWorker.cancel(true);
        inputPanel.setStatus("⏹  Durduruldu");
    }

    // ─── Conversation Management ──────────────────────────────────────────────

    private void newChat() {
        saveCurrentConversation();
        currentConversation = new ConversationHistory();
        chatPanel.clearMessages();
        if (agent != null) agent.resetHistory();
        sidebar.addConversation(currentConversation);
        updateTokenBar();
        inputPanel.focus();
    }

    private void loadConversation(ConversationHistory h) {
        saveCurrentConversation();
        currentConversation = h;
        chatPanel.clearMessages();

        for (ChatMessage msg : h.getMessages()) {
            chatPanel.addMessage(msg);
        }

        // Agent'ı bu sohbetle senkronize et (tüm user/assistant mesajlarını yükle)
        if (agent != null) {
            agent.rebuildHistoryFromMessages(h.getMessages());
        }
        updateTokenBar();
        inputPanel.focus();
    }

    private void saveCurrentConversation() {
        if (currentConversation != null && !currentConversation.getMessages().isEmpty()) {
            currentConversation.save();
        }
    }

    private void clearCurrentChat() {
        int r = JOptionPane.showConfirmDialog(this,
            "Mevcut sohbet temizlensin mi?", "Sohbeti Temizle",
            JOptionPane.YES_NO_OPTION);
        if (r == JOptionPane.YES_OPTION) {
            chatPanel.clearMessages();
            if (currentConversation != null) currentConversation.clearMessages();
            if (agent != null) agent.resetHistory();
            updateTokenBar();
        }
    }

    private void loadHistory() {
        sidebar.loadHistory();
    }

    // ─── Settings ────────────────────────────────────────────────────────────

    private void openSettings() {
        SettingsDialog dlg = new SettingsDialog(this, settings);
        dlg.setVisible(true);
        if (dlg.isConfirmed()) {
            initAgent();
            updateTokenBar();
        }
    }

    // ─── Status Bar ──────────────────────────────────────────────────────────

    private void updateTokenBar() {
        int in = agent != null ? agent.getTotalInputTokens() : 0;
        int out = agent != null ? agent.getTotalOutputTokens() : 0;
        boolean connected = agent != null && settings.hasApiKey();
        tokenBar.update(settings.getModel(), in, out, connected);
    }

    // ─── Help / About ─────────────────────────────────────────────────────────

    private void showHelp() {
        String help = """
            AI Client Manager - Kullanım Kılavuzu
            
            ● Mesaj göndermek için Enter'a basın
            ● Yeni satır için Shift + Enter kullanın
            ● Mesaja sağ tıklayarak kopyalayabilirsiniz
            
            Araçlar:
            • read_file     — Dosya okuma
            • write_file    — Dosya yazma/oluşturma
            • edit_file     — Dosya düzenleme
            • delete_file   — Dosya silme
            • list_directory — Dizin listeleme
            • search_files  — Dosyalarda arama
            • execute_command — Komut çalıştırma
            • make_directory — Klasör oluşturma
            • move_file     — Dosya taşıma
            • file_info     — Dosya bilgisi
            
            Kısayollar:
            • Ctrl+N  — Yeni sohbet
            • Ctrl+S  — Sohbeti kaydet
            • Ctrl+Q  — Çıkış
            • F5      — Geçmişi yenile
            """;
        JOptionPane.showMessageDialog(this, help, "Yardım", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showAbout() {
        JOptionPane.showMessageDialog(this,
            "<html><b>AI Client Manager v2.0</b><br><br>" +
            "Claude destekli tam yetkili dosya & sistem yöneticisi<br>" +
            "Aerolink proxy ve Anthropic API desteği<br><br>" +
            "<small>Java " + System.getProperty("java.version") + " · " +
            System.getProperty("os.name") + "</small></html>",
            "Hakkında", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showError(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Hata", JOptionPane.ERROR_MESSAGE);
    }

    private String buildFileText(File file) throws Exception {
        long size = file.length();
        String name = file.getName();
        String ext = name.contains(".") ? name.substring(name.lastIndexOf('.') + 1).toLowerCase() : "";
        java.util.Set<String> textExts = java.util.Set.of(
            "txt","md","java","py","js","ts","json","xml","yaml","yml","toml",
            "ini","cfg","conf","properties","env","html","htm","css","sql",
            "sh","bat","cmd","c","cpp","h","cs","go","rs","rb","php","log","csv");
        StringBuilder sb = new StringBuilder();
        sb.append("📎 Dosya: ").append(file.getAbsolutePath()).append("\n");
        sb.append("Boyut: ").append(formatSize(size)).append("\n");
        if (size < 500_000 && (textExts.contains(ext) || ext.isEmpty())) {
            String content = java.nio.file.Files.readString(file.toPath());
            sb.append("─".repeat(40)).append("\n").append(content);
        } else {
            sb.append("(Binary/büyük dosya — içerik gösterilemiyor)\nBu dosyayla ne yapmamı istersiniz?");
        }
        return sb.toString();
    }

    private String buildDirText(File dir) {
        File[] files = dir.listFiles();
        StringBuilder sb = new StringBuilder();
        sb.append("📁 Klasör: ").append(dir.getAbsolutePath()).append("\n");
        if (files == null || files.length == 0) { sb.append("(Boş)"); return sb.toString(); }
        java.util.Arrays.sort(files, java.util.Comparator.comparing(File::isDirectory)
            .reversed().thenComparing(File::getName));
        int shown = Math.min(files.length, 50);
        sb.append("İçerik (").append(files.length).append(" öğe):\n");
        for (int i = 0; i < shown; i++) {
            File f = files[i];
            sb.append(f.isDirectory() ? "  📁 " : "  📄 ").append(f.getName());
            if (!f.isDirectory()) sb.append(" (").append(formatSize(f.length())).append(")");
            sb.append("\n");
        }
        if (files.length > 50) sb.append("  ... ve ").append(files.length - 50).append(" öğe daha");
        return sb.toString();
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.1f MB", bytes / (1024.0 * 1024));
    }

    // ─── Window-wide Drag & Drop ──────────────────────────────────────────────

    private void setupWindowDropTarget() {
        new DropTarget(this, DnDConstants.ACTION_COPY, new DropTargetAdapter() {
            @Override
            public void dragEnter(DropTargetDragEvent e) {
                if (e.isDataFlavorSupported(DataFlavor.javaFileListFlavor)) {
                    e.acceptDrag(DnDConstants.ACTION_COPY);
                    showDropOverlay(true);
                }
            }

            @Override
            public void dragExit(DropTargetEvent e) {
                showDropOverlay(false);
            }

            @Override
            public void drop(DropTargetDropEvent e) {
                showDropOverlay(false);
                try {
                    e.acceptDrop(DnDConstants.ACTION_COPY);
                    @SuppressWarnings("unchecked")
                    List<File> files = (List<File>) e.getTransferable()
                            .getTransferData(DataFlavor.javaFileListFlavor);
                    if (!files.isEmpty()) {
                        // Dosyaları FileDropHandler ile işle
                        FileDropHandler handler = new FileDropHandler(chatPanel, text ->
                            SwingUtilities.invokeLater(() -> sendMessage(text)));
                        for (File f : files) {
                            try {
                                String content = f.isDirectory()
                                    ? buildDirText(f)
                                    : buildFileText(f);
                                SwingUtilities.invokeLater(() -> sendMessage(content));
                            } catch (Exception ignored) {}
                        }
                    }
                    e.dropComplete(true);
                } catch (Exception ex) {
                    e.dropComplete(false);
                }
            }
        });
    }

    private JLabel dropOverlay;

    private void showDropOverlay(boolean show) {
        if (show && dropOverlay == null) {
            dropOverlay = new JLabel(
                "<html><center><b style='font-size:18'>📂</b><br>Dosyayı buraya bırakın</center></html>",
                SwingConstants.CENTER);
            dropOverlay.setOpaque(true);
            dropOverlay.setBackground(new Color(0x0D1117, true));
            dropOverlay.setForeground(new Color(0x4FC3F7));
            dropOverlay.setFont(dropOverlay.getFont().deriveFont(Font.BOLD, 18f));
            dropOverlay.setBorder(BorderFactory.createLineBorder(new Color(0x4FC3F7), 2));
            dropOverlay.setBounds(10, 10, getWidth() - 20, getHeight() - 20);
            getLayeredPane().add(dropOverlay, JLayeredPane.DRAG_LAYER);
        }
        if (dropOverlay != null) {
            dropOverlay.setVisible(show);
            if (!show) {
                getLayeredPane().remove(dropOverlay);
                dropOverlay = null;
            }
            getLayeredPane().revalidate();
            getLayeredPane().repaint();
        }
    }
}
