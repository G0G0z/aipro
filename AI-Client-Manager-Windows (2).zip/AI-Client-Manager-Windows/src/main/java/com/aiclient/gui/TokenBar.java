package com.aiclient.gui;

import javax.swing.*;
import java.awt.*;

/**
 * Alt durum çubuğu: token sayaçları, model adı, bağlantı durumu.
 */
public class TokenBar extends JPanel {

    private final JLabel modelLabel;
    private final JLabel tokenLabel;
    private final JLabel connLabel;

    private static final Color BAR_BG = new Color(0x161B22);
    private static final Color FG     = new Color(0x8B949E);

    public TokenBar() {
        setLayout(new BorderLayout(0, 0));
        setBackground(BAR_BG);
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(0x21262D)),
            BorderFactory.createEmptyBorder(3, 10, 3, 10)));
        setPreferredSize(new Dimension(0, 24));

        Font small = UIManager.getFont("Label.font");
        if (small != null) small = small.deriveFont(10f);
        else small = new Font(Font.SANS_SERIF, Font.PLAIN, 10);

        modelLabel = new JLabel("Model: —");
        modelLabel.setForeground(FG);
        modelLabel.setFont(small);

        tokenLabel = new JLabel("Token: —");
        tokenLabel.setForeground(FG);
        tokenLabel.setFont(small);

        connLabel = new JLabel("⚪  Bağlantı yok");
        connLabel.setForeground(FG);
        connLabel.setFont(small);

        add(modelLabel, BorderLayout.WEST);
        add(tokenLabel, BorderLayout.CENTER);

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        right.setBackground(BAR_BG);
        right.add(connLabel);
        add(right, BorderLayout.EAST);
    }

    public void update(String model, int input, int output, boolean connected) {
        modelLabel.setText("Model: " + model);
        if (input + output > 0) {
            tokenLabel.setText("  Token — Girdi: " + input + "  Çıktı: " + output
                    + "  Toplam: " + (input + output));
        } else {
            tokenLabel.setText("  Token: —");
        }
        connLabel.setText(connected ? "🟢  Bağlı" : "⚪  Bağlantı yok");
        connLabel.setForeground(connected ? new Color(0x3FB950) : FG);
    }
}
