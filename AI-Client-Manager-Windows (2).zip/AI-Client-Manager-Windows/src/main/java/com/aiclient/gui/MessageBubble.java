package com.aiclient.gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;

/**
 * Mesaj balonunu temsil eden bileşen.
 */
public class MessageBubble extends JPanel {

    private static final Color USER_BG = new Color(0x2D6A4F);
    private static final Color ASSISTANT_BG = new Color(0x1E2A3A);
    private static final Color TOOL_USE_BG = new Color(0x2A2000);
    private static final Color TOOL_OK_BG = new Color(0x1A3020);
    private static final Color TOOL_ERR_BG = new Color(0x3A1A1A);
    private static final Color SYSTEM_BG = new Color(0x1A1A2E);
    private static final Color ERROR_BG = new Color(0x4A1010);

    private static final Color TEXT_COLOR = new Color(0xE8EAF6);
    private static final Color DIM_COLOR = new Color(0x9E9E9E);
    private static final Color TIME_COLOR = new Color(0x757575);

    private final ChatMessage message;
    private JTextArea textArea;

    public MessageBubble(ChatMessage message) {
        this.message = message;
        setLayout(new BorderLayout(6, 4));
        setOpaque(false);
        buildContent();
    }

    private void buildContent() {
        Color bg;
        String prefix;
        Color prefixColor;

        switch (message.getType()) {
            case USER -> {
                bg = USER_BG;
                prefix = "👤  Siz";
                prefixColor = new Color(0x69F0AE);
            }
            case ASSISTANT -> {
                bg = ASSISTANT_BG;
                prefix = "🤖  Claude";
                prefixColor = new Color(0x82B1FF);
            }
            case TOOL_USE -> {
                bg = TOOL_USE_BG;
                prefix = "⚙  Araç çağrısı: " + message.getToolName();
                prefixColor = new Color(0xFFD54F);
            }
            case TOOL_RESULT -> {
                bg = message.isToolSuccess() ? TOOL_OK_BG : TOOL_ERR_BG;
                prefix = (message.isToolSuccess() ? "✓  " : "✗  ") + message.getToolName();
                prefixColor = message.isToolSuccess() ? new Color(0x69F0AE) : new Color(0xFF5252);
            }
            case ERROR -> {
                bg = ERROR_BG;
                prefix = "✗  Hata";
                prefixColor = new Color(0xFF5252);
            }
            default -> {
                bg = SYSTEM_BG;
                prefix = "ℹ  Sistem";
                prefixColor = new Color(0xB0BEC5);
            }
        }

        JPanel bubble = new JPanel(new BorderLayout(0, 4)) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bg);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.dispose();
            }
        };
        bubble.setOpaque(false);
        bubble.setBorder(BorderFactory.createEmptyBorder(10, 12, 10, 12));

        // Header: prefix + time
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel prefixLabel = new JLabel(prefix);
        prefixLabel.setForeground(prefixColor);
        prefixLabel.setFont(prefixLabel.getFont().deriveFont(Font.BOLD, 12f));
        header.add(prefixLabel, BorderLayout.WEST);

        JLabel timeLabel = new JLabel(message.getFormattedTime());
        timeLabel.setForeground(TIME_COLOR);
        timeLabel.setFont(timeLabel.getFont().deriveFont(10f));
        header.add(timeLabel, BorderLayout.EAST);

        bubble.add(header, BorderLayout.NORTH);

        // Content — always create textArea so streaming setText() calls work
        textArea = new JTextArea(message.getContent() != null ? message.getContent() : "");
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setWrapStyleWord(true);
        textArea.setOpaque(false);
        textArea.setForeground(TEXT_COLOR);
        textArea.setFont(getContentFont(message.getType()));
        textArea.setBorder(null);
        textArea.setCursor(Cursor.getDefaultCursor());

        // Sağ tık kopyalama
        JPopupMenu popup = new JPopupMenu();
        JMenuItem copy = new JMenuItem("Kopyala");
        copy.addActionListener(e -> {
            textArea.selectAll();
            textArea.copy();
            textArea.select(0, 0);
        });
        popup.add(copy);
        textArea.setComponentPopupMenu(popup);

        bubble.add(textArea, BorderLayout.CENTER);

        // Alignment
        JPanel row = new JPanel(new FlowLayout(
            message.getType() == ChatMessage.Type.USER ? FlowLayout.RIGHT : FlowLayout.LEFT, 8, 4));
        row.setOpaque(false);

        int maxWidth = 700;
        bubble.setMaximumSize(new Dimension(maxWidth, Integer.MAX_VALUE));
        bubble.setPreferredSize(null);

        row.add(bubble);
        add(row, BorderLayout.CENTER);
    }

    private Font getContentFont(ChatMessage.Type type) {
        Font base = UIManager.getFont("Label.font");
        if (base == null) base = new Font("SansSerif", Font.PLAIN, 13);
        return switch (type) {
            case TOOL_USE, TOOL_RESULT -> new Font(Font.MONOSPACED, Font.PLAIN, 11);
            case USER -> base.deriveFont(13f);
            default -> base.deriveFont(13f);
        };
    }

    public void appendText(String text) {
        if (textArea != null) {
            textArea.append(text);
        }
    }

    public void setText(String text) {
        if (textArea != null) {
            textArea.setText(text);
        }
    }
}
