package com.aiclient.gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;

public class SettingsDialog extends JDialog {

    private final AppSettings settings;
    private JTextField aerolinkKeyField;
    private JTextField anthropicKeyField;
    private JComboBox<String> modelCombo;
    private JTextArea systemPromptArea;
    private JSpinner maxTokensSpinner;
    private JSpinner maxIterationsSpinner;
    private JRadioButton aerolinkRadio;
    private JRadioButton anthropicRadio;
    private JTextField workingDirField;
    private boolean confirmed = false;

    private static final String[] MODELS = {
        "claude-sonnet-4-6",
        "claude-opus-4-5",
        "claude-haiku-3-5",
        "claude-3-5-sonnet-20241022",
        "claude-3-opus-20240229",
        "gpt-4o",
        "gpt-4o-mini"
    };

    public SettingsDialog(Frame parent, AppSettings settings) {
        super(parent, "⚙  Ayarlar", true);
        this.settings = settings;
        buildUI();
        loadValues();
        pack();
        setMinimumSize(new Dimension(620, 600));
        setLocationRelativeTo(parent);
    }

    private void buildUI() {
        setLayout(new BorderLayout(0, 0));

        JTabbedPane tabs = new JTabbedPane();
        tabs.setBorder(BorderFactory.createEmptyBorder(8, 8, 0, 8));

        tabs.addTab("🔑  API", buildApiTab());
        tabs.addTab("🤖  Model", buildModelTab());
        tabs.addTab("📝  Sistem Prompt", buildSystemPromptTab());
        tabs.addTab("📁  Genel", buildGeneralTab());

        add(tabs, BorderLayout.CENTER);
        add(buildButtonBar(), BorderLayout.SOUTH);
    }

    private JPanel buildApiTab() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = new Insets(4, 4, 4, 4);

        // Sağlayıcı seçimi
        gc.gridx = 0; gc.gridy = 0; gc.gridwidth = 2;
        JPanel providerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 0));
        providerPanel.setBorder(BorderFactory.createTitledBorder("API Sağlayıcısı"));
        ButtonGroup bg = new ButtonGroup();
        aerolinkRadio = new JRadioButton("Aerolink (capi.aerolink.lat)");
        anthropicRadio = new JRadioButton("Anthropic (api.anthropic.com)");
        bg.add(aerolinkRadio);
        bg.add(anthropicRadio);
        providerPanel.add(aerolinkRadio);
        providerPanel.add(anthropicRadio);
        p.add(providerPanel, gc);

        // Aerolink API Key
        gc.gridx = 0; gc.gridy = 1; gc.gridwidth = 1; gc.weightx = 0;
        p.add(new JLabel("Aerolink API Key:"), gc);
        gc.gridx = 1; gc.weightx = 1;
        aerolinkKeyField = new JPasswordField(40);
        aerolinkKeyField.setToolTipText("aero_live_... formatında");
        p.add(aerolinkKeyField, gc);

        // Anthropic API Key
        gc.gridx = 0; gc.gridy = 2; gc.weightx = 0;
        p.add(new JLabel("Anthropic API Key:"), gc);
        gc.gridx = 1; gc.weightx = 1;
        anthropicKeyField = new JPasswordField(40);
        anthropicKeyField.setToolTipText("sk-ant-... formatında");
        p.add(anthropicKeyField, gc);

        // Bilgi notu
        gc.gridx = 0; gc.gridy = 3; gc.gridwidth = 2;
        JLabel hint = new JLabel("<html><small><i>💡 Aerolink seçiliyse ve Aerolink API Key varsa önce o kullanılır.</i></small></html>");
        hint.setForeground(UIManager.getColor("Label.disabledForeground"));
        p.add(hint, gc);

        gc.gridy = 4; gc.weighty = 1;
        p.add(Box.createVerticalGlue(), gc);

        return p;
    }

    private JPanel buildModelTab() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = new Insets(6, 4, 6, 4);

        gc.gridx = 0; gc.gridy = 0; gc.weightx = 0;
        p.add(new JLabel("Model:"), gc);
        gc.gridx = 1; gc.weightx = 1;
        modelCombo = new JComboBox<>(MODELS);
        modelCombo.setEditable(true);
        modelCombo.setToolTipText("Modeli seçin veya doğrudan yazın");
        p.add(modelCombo, gc);

        gc.gridx = 0; gc.gridy = 1; gc.weightx = 0;
        p.add(new JLabel("Maks. Token:"), gc);
        gc.gridx = 1; gc.weightx = 1;
        maxTokensSpinner = new JSpinner(new SpinnerNumberModel(8096, 256, 100000, 256));
        p.add(maxTokensSpinner, gc);

        gc.gridx = 0; gc.gridy = 2; gc.weightx = 0;
        p.add(new JLabel("Maks. Araç Döngüsü:"), gc);
        gc.gridx = 1; gc.weightx = 1;
        maxIterationsSpinner = new JSpinner(new SpinnerNumberModel(50, 1, 200, 5));
        p.add(maxIterationsSpinner, gc);

        gc.gridx = 0; gc.gridy = 3; gc.gridwidth = 2;
        JLabel modelHint = new JLabel("<html><small><i>💡 Model adını doğrudan yazabilirsiniz (örn: claude-opus-4-5)</i></small></html>");
        modelHint.setForeground(UIManager.getColor("Label.disabledForeground"));
        p.add(modelHint, gc);

        gc.gridy = 4; gc.weighty = 1;
        p.add(Box.createVerticalGlue(), gc);

        return p;
    }

    private JPanel buildSystemPromptTab() {
        JPanel p = new JPanel(new BorderLayout(8, 8));
        p.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        JPanel topBar = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        topBar.add(new JLabel("Sistem Promptu:"));
        JButton resetBtn = new JButton("Varsayılana Sıfırla");
        resetBtn.addActionListener(e -> systemPromptArea.setText(AppSettings.getDefaultSystemPrompt()));
        topBar.add(resetBtn);
        p.add(topBar, BorderLayout.NORTH);

        systemPromptArea = new JTextArea(10, 50);
        systemPromptArea.setLineWrap(true);
        systemPromptArea.setWrapStyleWord(true);
        systemPromptArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        p.add(new JScrollPane(systemPromptArea), BorderLayout.CENTER);

        return p;
    }

    private JPanel buildGeneralTab() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBorder(BorderFactory.createEmptyBorder(16, 16, 16, 16));
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.HORIZONTAL;
        gc.insets = new Insets(6, 4, 6, 4);

        gc.gridx = 0; gc.gridy = 0; gc.weightx = 0;
        p.add(new JLabel("Çalışma Dizini:"), gc);

        gc.gridx = 1; gc.weightx = 1;
        workingDirField = new JTextField(30);
        p.add(workingDirField, gc);

        gc.gridx = 2; gc.weightx = 0;
        JButton browseBtn = new JButton("Gözat...");
        browseBtn.addActionListener(e -> {
            JFileChooser fc = new JFileChooser(workingDirField.getText());
            fc.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
            if (fc.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
                workingDirField.setText(fc.getSelectedFile().getAbsolutePath());
            }
        });
        p.add(browseBtn, gc);

        gc.gridx = 0; gc.gridy = 1; gc.gridwidth = 3; gc.weighty = 1;
        p.add(Box.createVerticalGlue(), gc);

        return p;
    }

    private JPanel buildButtonBar() {
        JPanel bar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 8));
        bar.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, UIManager.getColor("Separator.foreground")));

        JButton cancelBtn = new JButton("İptal");
        cancelBtn.addActionListener(e -> dispose());

        JButton saveBtn = new JButton("Kaydet");
        saveBtn.setBackground(new Color(0x2D7D46));
        saveBtn.addActionListener(e -> save());
        getRootPane().setDefaultButton(saveBtn);

        bar.add(cancelBtn);
        bar.add(saveBtn);
        return bar;
    }

    private void loadValues() {
        aerolinkKeyField.setText(settings.getAerolinkApiKey());
        anthropicKeyField.setText(settings.getAnthropicApiKey());

        if (settings.isUseAerolink()) aerolinkRadio.setSelected(true);
        else anthropicRadio.setSelected(true);

        modelCombo.setSelectedItem(settings.getModel());
        systemPromptArea.setText(settings.getSystemPrompt());
        maxTokensSpinner.setValue(settings.getMaxTokens());
        maxIterationsSpinner.setValue(settings.getMaxToolIterations());
        workingDirField.setText(settings.getWorkingDirectory());
    }

    private void save() {
        settings.setAerolinkApiKey(aerolinkKeyField.getText().trim());
        settings.setAnthropicApiKey(anthropicKeyField.getText().trim());
        settings.setUseAerolink(aerolinkRadio.isSelected());
        settings.setModel(modelCombo.getSelectedItem() != null ? modelCombo.getSelectedItem().toString().trim() : "claude-sonnet-4-6");
        settings.setSystemPrompt(systemPromptArea.getText());
        settings.setMaxTokens((Integer) maxTokensSpinner.getValue());
        settings.setMaxToolIterations((Integer) maxIterationsSpinner.getValue());
        settings.setWorkingDirectory(workingDirField.getText().trim());
        settings.save();
        confirmed = true;
        dispose();
    }

    public boolean isConfirmed() { return confirmed; }
}
