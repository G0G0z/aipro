package com.aiclient.gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.function.Consumer;

/**
 * Sol kenar çubuğu: sohbet geçmişi listesi.
 */
public class SidebarPanel extends JPanel {

    private final DefaultListModel<ConversationHistory> listModel;
    private final JList<ConversationHistory> historyList;
    private Consumer<ConversationHistory> onSelect;
    private Runnable onNewChat;
    private Consumer<ConversationHistory> onDelete;

    private static final Color SIDEBAR_BG    = new Color(0x1A1D23);
    private static final Color ITEM_BG       = new Color(0x21262D);
    private static final Color ITEM_SEL_BG   = new Color(0x2D3748);
    private static final Color TITLE_COLOR   = new Color(0xE8EAF6);
    private static final Color DATE_COLOR    = new Color(0x757575);
    private static final Color ACCENT        = new Color(0x4FC3F7);

    public SidebarPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(SIDEBAR_BG);
        setPreferredSize(new Dimension(240, 0));
        setBorder(BorderFactory.createMatteBorder(0, 0, 0, 1, new Color(0x30363D)));

        // Başlık
        JPanel header = new JPanel(new BorderLayout(8, 0));
        header.setBackground(SIDEBAR_BG);
        header.setBorder(BorderFactory.createEmptyBorder(12, 12, 8, 12));

        JLabel title = new JLabel("💬  Sohbetler");
        title.setForeground(TITLE_COLOR);
        title.setFont(title.getFont().deriveFont(Font.BOLD, 14f));
        header.add(title, BorderLayout.WEST);

        JButton newBtn = new JButton("+");
        newBtn.setToolTipText("Yeni Sohbet");
        newBtn.setFont(newBtn.getFont().deriveFont(Font.BOLD, 16f));
        newBtn.setForeground(ACCENT);
        newBtn.setBackground(new Color(0x2A3040));
        newBtn.setBorder(BorderFactory.createEmptyBorder(2, 8, 2, 8));
        newBtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        newBtn.setFocusPainted(false);
        newBtn.addActionListener(e -> { if (onNewChat != null) onNewChat.run(); });
        header.add(newBtn, BorderLayout.EAST);

        add(header, BorderLayout.NORTH);

        // Liste
        listModel = new DefaultListModel<>();
        historyList = new JList<>(listModel);
        historyList.setBackground(SIDEBAR_BG);
        historyList.setSelectionBackground(ITEM_SEL_BG);
        historyList.setForeground(TITLE_COLOR);
        historyList.setCellRenderer(new HistoryCellRenderer());
        historyList.setFixedCellHeight(60);
        historyList.setBorder(null);

        historyList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && onSelect != null) {
                ConversationHistory sel = historyList.getSelectedValue();
                if (sel != null) onSelect.accept(sel);
            }
        });

        // Sağ tık menüsü
        JPopupMenu popup = new JPopupMenu();
        JMenuItem deleteItem = new JMenuItem("🗑  Sohbeti Sil");
        deleteItem.addActionListener(e -> {
            ConversationHistory sel = historyList.getSelectedValue();
            if (sel != null && onDelete != null) {
                int r = JOptionPane.showConfirmDialog(this,
                    "\"" + sel.getTitle() + "\" silinsin mi?", "Sohbeti Sil",
                    JOptionPane.YES_NO_OPTION);
                if (r == JOptionPane.YES_OPTION) onDelete.accept(sel);
            }
        });
        popup.add(deleteItem);
        historyList.setComponentPopupMenu(popup);

        JScrollPane scroll = new JScrollPane(historyList);
        scroll.setBorder(null);
        scroll.setBackground(SIDEBAR_BG);
        scroll.getViewport().setBackground(SIDEBAR_BG);
        add(scroll, BorderLayout.CENTER);
    }

    public void loadHistory() {
        listModel.clear();
        List<ConversationHistory> all = ConversationHistory.loadAll();
        for (ConversationHistory h : all) listModel.addElement(h);
    }

    public void addConversation(ConversationHistory h) {
        listModel.insertElementAt(h, 0);
        historyList.setSelectedIndex(0);
    }

    public void refreshTop(ConversationHistory h) {
        // Güncellenmiş başlığı yenile
        int idx = listModel.indexOf(h);
        if (idx >= 0) {
            listModel.set(idx, h);
        }
    }

    public void removeConversation(ConversationHistory h) {
        listModel.removeElement(h);
    }

    public void selectFirst() {
        if (!listModel.isEmpty()) historyList.setSelectedIndex(0);
    }

    public void setOnSelect(Consumer<ConversationHistory> cb) { this.onSelect = cb; }
    public void setOnNewChat(Runnable cb) { this.onNewChat = cb; }
    public void setOnDelete(Consumer<ConversationHistory> cb) { this.onDelete = cb; }

    // ── Hücre Renderer ──────────────────────────────────────────────────────
    private class HistoryCellRenderer extends JPanel implements ListCellRenderer<ConversationHistory> {
        private final JLabel titleLabel = new JLabel();
        private final JLabel dateLabel  = new JLabel();

        HistoryCellRenderer() {
            setLayout(new BorderLayout(0, 3));
            setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(0x30363D)),
                BorderFactory.createEmptyBorder(8, 12, 8, 8)));

            titleLabel.setFont(titleLabel.getFont().deriveFont(Font.PLAIN, 12f));
            dateLabel.setFont(dateLabel.getFont().deriveFont(10f));
            dateLabel.setForeground(DATE_COLOR);

            add(titleLabel, BorderLayout.CENTER);
            add(dateLabel, BorderLayout.SOUTH);
        }

        @Override
        public Component getListCellRendererComponent(JList<? extends ConversationHistory> list,
                ConversationHistory value, int index, boolean isSelected, boolean cellHasFocus) {
            setBackground(isSelected ? ITEM_SEL_BG : SIDEBAR_BG);
            titleLabel.setBackground(getBackground());
            dateLabel.setBackground(getBackground());
            setOpaque(true);

            String title = value.getTitle();
            if (title.length() > 28) title = title.substring(0, 28) + "…";
            titleLabel.setText(title);
            titleLabel.setForeground(isSelected ? ACCENT : TITLE_COLOR);

            String date = value.getUpdatedAt().format(DateTimeFormatter.ofPattern("d MMM, HH:mm"));
            dateLabel.setText(date);

            return this;
        }
    }
}
