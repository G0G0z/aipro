package com.aiclient.gui;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.function.Consumer;

/**
 * Mesaj giriş paneli - metin alanı, gönder butonu, iptal butonu.
 * Sürükle-bırak dosya desteği vardır.
 */
public class InputPanel extends JPanel {

    private final JTextArea inputArea;
    private final JButton sendButton;
    private final JButton cancelButton;
    private final JLabel statusLabel;
    private JLabel dropHint;
    private Consumer<String> onSend;
    private Runnable onCancel;

    private static final Color PANEL_BG  = new Color(0x1A1D23);
    private static final Color INPUT_BG  = new Color(0x21262D);
    private static final Color SEND_BG   = new Color(0x238636);
    private static final Color CANCEL_BG = new Color(0x8B1A1A);
    private static final Color TEXT_FG   = new Color(0xE8EAF6);

    public InputPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(PANEL_BG);
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(0x30363D)),
            BorderFactory.createEmptyBorder(10, 12, 10, 12)));

        // Durum çubuğu (üstte)
        statusLabel = new JLabel(" ");
        statusLabel.setForeground(new Color(0x9E9E9E));
        statusLabel.setFont(statusLabel.getFont().deriveFont(10f));
        add(statusLabel, BorderLayout.NORTH);

        // Giriş alanı
        inputArea = new JTextArea(3, 50);
        inputArea.setLineWrap(true);
        inputArea.setWrapStyleWord(true);
        inputArea.setBackground(INPUT_BG);
        inputArea.setForeground(TEXT_FG);
        inputArea.setCaretColor(TEXT_FG);
        inputArea.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
        inputArea.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));

        // Enter = gönder, Shift+Enter = yeni satır
        inputArea.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER && !e.isShiftDown()) {
                    e.consume();
                    send();
                }
            }
        });

        // Sürükle-bırak desteği
        FileDropHandler dropHandler = new FileDropHandler(inputArea, droppedText -> {
            String current = inputArea.getText();
            if (current.isBlank()) {
                inputArea.setText(droppedText);
            } else {
                inputArea.setText(current + "\n\n" + droppedText);
            }
            inputArea.setCaretPosition(inputArea.getText().length());
            dropHint.setVisible(false);
        });
        inputArea.setTransferHandler(dropHandler);

        JScrollPane inputScroll = new JScrollPane(inputArea);
        inputScroll.setBorder(BorderFactory.createLineBorder(new Color(0x30363D), 1));
        inputScroll.setBackground(INPUT_BG);
        inputScroll.getViewport().setBackground(INPUT_BG);

        // Butonlar
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 0, 6));
        buttonPanel.setBackground(PANEL_BG);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 0));

        sendButton = createButton("Gönder ⏎", SEND_BG);
        sendButton.setToolTipText("Gönder (Enter)");
        sendButton.addActionListener(e -> send());

        cancelButton = createButton("Durdur ✕", CANCEL_BG);
        cancelButton.setToolTipText("AI yanıtını durdur");
        cancelButton.setEnabled(false);
        cancelButton.addActionListener(e -> { if (onCancel != null) onCancel.run(); });

        buttonPanel.add(sendButton);
        buttonPanel.add(cancelButton);

        JPanel center = new JPanel(new BorderLayout(8, 0));
        center.setBackground(PANEL_BG);
        center.setBorder(BorderFactory.createEmptyBorder(6, 0, 0, 0));
        center.add(inputScroll, BorderLayout.CENTER);
        center.add(buttonPanel, BorderLayout.EAST);

        add(center, BorderLayout.CENTER);

        // Alt ipucu çubuğu
        JPanel hintBar = new JPanel(new BorderLayout());
        hintBar.setBackground(PANEL_BG);
        hintBar.setBorder(BorderFactory.createEmptyBorder(4, 0, 0, 0));

        JLabel hint = new JLabel("Enter: gönder  |  Shift+Enter: yeni satır  |  Sağ tık: kopyala");
        hint.setForeground(new Color(0x616161));
        hint.setFont(hint.getFont().deriveFont(9f));
        hintBar.add(hint, BorderLayout.WEST);

        dropHint = new JLabel("📎 Dosya veya klasör bırakabilirsiniz");
        dropHint.setForeground(new Color(0x4FC3F7));
        dropHint.setFont(dropHint.getFont().deriveFont(Font.ITALIC, 9f));
        dropHint.setVisible(false);
        hintBar.add(dropHint, BorderLayout.EAST);

        add(hintBar, BorderLayout.SOUTH);
    }

    private JButton createButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 14, 8, 14));
        btn.setFont(btn.getFont().deriveFont(Font.BOLD, 12f));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    private void send() {
        String text = inputArea.getText().trim();
        if (text.isEmpty()) return;
        if (onSend != null) {
            inputArea.setText("");
            onSend.accept(text);
        }
    }

    public void setProcessing(boolean processing) {
        sendButton.setEnabled(!processing);
        cancelButton.setEnabled(processing);
        inputArea.setEnabled(!processing);
    }

    public void setStatus(String text) {
        statusLabel.setText(text);
    }

    public void setOnSend(Consumer<String> cb) { this.onSend = cb; }
    public void setOnCancel(Runnable cb) { this.onCancel = cb; }
    public void focus() { inputArea.requestFocusInWindow(); }
}
