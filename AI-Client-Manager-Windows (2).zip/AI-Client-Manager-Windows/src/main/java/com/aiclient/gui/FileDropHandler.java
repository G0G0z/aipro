package com.aiclient.gui;

import javax.swing.*;
import java.awt.*;
import java.awt.datatransfer.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;
import java.util.function.Consumer;

/**
 * Sürükle-bırak dosya işleyici.
 * Metin dosyalarını okur, binary dosyalar için yol bilgisini verir.
 */
public class FileDropHandler extends TransferHandler {

    private static final long MAX_TEXT_SIZE = 500_000; // 500 KB
    private static final Set<String> TEXT_EXTENSIONS = Set.of(
        "txt", "md", "java", "py", "js", "ts", "jsx", "tsx", "json", "xml",
        "yaml", "yml", "toml", "ini", "cfg", "conf", "properties", "env",
        "html", "htm", "css", "scss", "sql", "sh", "bat", "cmd", "ps1",
        "c", "cpp", "h", "hpp", "cs", "go", "rs", "rb", "php", "swift",
        "kt", "gradle", "log", "csv", "gitignore", "dockerfile", "makefile",
        "readme", "license", "changelog", "r", "m", "tex"
    );

    private final Consumer<String> onFileDrop;  // mesaj metnini teslim eder
    private final JComponent dropTarget;
    private Color originalBg;
    private static final Color DRAG_OVER_COLOR = new Color(0x1A3A5C);

    public FileDropHandler(JComponent dropTarget, Consumer<String> onFileDrop) {
        this.dropTarget = dropTarget;
        this.onFileDrop = onFileDrop;
    }

    @Override
    public boolean canImport(TransferSupport support) {
        boolean can = support.isDataFlavorSupported(DataFlavor.javaFileListFlavor);
        // Görsel geri bildirim
        if (can) {
            if (originalBg == null) originalBg = dropTarget.getBackground();
            dropTarget.setBackground(DRAG_OVER_COLOR);
            dropTarget.repaint();
        }
        return can;
    }

    @Override
    public boolean importData(TransferSupport support) {
        // Rengi sıfırla
        if (originalBg != null) {
            dropTarget.setBackground(originalBg);
            dropTarget.repaint();
        }

        if (!canImport(support)) return false;

        try {
            @SuppressWarnings("unchecked")
            List<File> files = (List<File>) support.getTransferable()
                    .getTransferData(DataFlavor.javaFileListFlavor);

            StringBuilder message = new StringBuilder();

            for (File file : files) {
                if (file.isDirectory()) {
                    message.append(buildDirectoryInfo(file));
                } else {
                    message.append(buildFileInfo(file));
                }
                if (files.size() > 1) message.append("\n\n---\n\n");
            }

            if (onFileDrop != null && !message.isEmpty()) {
                onFileDrop.accept(message.toString().trim());
            }
            return true;

        } catch (Exception e) {
            if (onFileDrop != null) {
                onFileDrop.accept("[Dosya okunamadı: " + e.getMessage() + "]");
            }
            return false;
        }
    }

    private String buildFileInfo(File file) throws IOException {
        String name = file.getName();
        String ext = getExtension(name).toLowerCase();
        long size = file.length();

        StringBuilder sb = new StringBuilder();
        sb.append("📎 Dosya: ").append(file.getAbsolutePath()).append("\n");
        sb.append("Boyut: ").append(formatSize(size)).append("\n");

        if (isTextFile(ext, size)) {
            String content = Files.readString(file.toPath());
            if (content.length() > MAX_TEXT_SIZE) {
                content = content.substring(0, (int) MAX_TEXT_SIZE) + "\n... (dosya kısaltıldı)";
            }
            int lineCount = content.split("\n", -1).length;
            sb.append("Satır: ").append(lineCount).append("\n");
            sb.append("─".repeat(50)).append("\n");
            sb.append(content);
        } else {
            sb.append("(Binary dosya — içerik gösterilemiyor)\n");
            sb.append("Bu dosyayı işlememi ister misin?");
        }

        return sb.toString();
    }

    private String buildDirectoryInfo(File dir) {
        StringBuilder sb = new StringBuilder();
        sb.append("📁 Klasör: ").append(dir.getAbsolutePath()).append("\n");

        File[] files = dir.listFiles();
        if (files == null || files.length == 0) {
            sb.append("(Klasör boş)");
            return sb.toString();
        }

        Arrays.sort(files, Comparator.comparing(File::isDirectory)
                .reversed().thenComparing(File::getName));

        sb.append("İçerik (").append(files.length).append(" öğe):\n");
        int shown = Math.min(files.length, 50);
        for (int i = 0; i < shown; i++) {
            File f = files[i];
            sb.append(f.isDirectory() ? "  📁 " : "  📄 ")
              .append(f.getName());
            if (!f.isDirectory()) {
                sb.append(" (").append(formatSize(f.length())).append(")");
            }
            sb.append("\n");
        }
        if (files.length > 50) {
            sb.append("  ... ve ").append(files.length - 50).append(" öğe daha");
        }

        return sb.toString();
    }

    private boolean isTextFile(String ext, long size) {
        if (size > MAX_TEXT_SIZE * 2) return false;
        if (ext.isEmpty()) return size < 50_000; // uzantısız küçük dosyalar metin olabilir
        return TEXT_EXTENSIONS.contains(ext);
    }

    private String getExtension(String name) {
        int dot = name.lastIndexOf('.');
        return dot >= 0 ? name.substring(dot + 1) : "";
    }

    private String formatSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        return String.format("%.1f MB", bytes / (1024.0 * 1024));
    }
}
