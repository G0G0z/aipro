package com.aiclient.gui;

import com.google.gson.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;

/**
 * Uygulama ayarlarını JSON dosyasına kaydeder/yükler.
 */
public class AppSettings {

    private static final String SETTINGS_FILE = System.getProperty("user.home") + File.separator + ".ai-client-manager" + File.separator + "settings.json";

    private String aerolinkApiKey = "aero_live_37mV9gjodj4NQ8fmwjQ1ecSilR5M_rM-xDYUAJEr6Xs";
    private String anthropicApiKey = "";
    private String baseUrl = "https://capi.aerolink.lat";
    private String model = "claude-opus-4-8";
    private String systemPrompt = DEFAULT_SYSTEM_PROMPT;
    private List<String> savedSystemPrompts = new ArrayList<>();
    private int maxTokens = 8096;
    private int maxToolIterations = 50;
    private boolean useAerolink = true;
    private String workingDirectory = System.getProperty("user.home");

    private static final String DEFAULT_SYSTEM_PROMPT = """
            Sen gelişmiş bir yapay zeka asistanısın ve tam dosya sistemi ile kabuk erişimine sahipsin.

            Sahip olduğun yetenekler:
            - Dosya okuma, yazma, oluşturma, düzenleme ve silme
            - Dizin oluşturma, listeleme ve gezinme
            - Dosyalar içinde metin/regex arama
            - Kabuk komutları çalıştırma (bash)
            - Dosya/dizin taşıma ve yeniden adlandırma
            - Dosya meta bilgilerini görüntüleme

            Kullanıcıya Türkçe olarak yanıt ver.

            Önemli kurallar:
            1. Kod yazmadan önce mevcut kodu oku
            2. Değişiklik yaparken dikkatli ve özenli ol
            3. Silme işlemlerinden önce kullanıcıyı uyar
            4. Uzun çıktıları özetle ve en önemli kısımları vurgula
            5. Hata durumunda hatanın sebebini açıkla ve çözüm öner
            """;

    private static AppSettings instance;

    private AppSettings() {}

    public static AppSettings getInstance() {
        if (instance == null) {
            instance = load();
        }
        return instance;
    }

    public static AppSettings load() {
        AppSettings settings = new AppSettings();
        File file = new File(SETTINGS_FILE);
        if (!file.exists()) return settings;

        try {
            String json = Files.readString(file.toPath());
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();

            if (obj.has("aerolinkApiKey")) settings.aerolinkApiKey = obj.get("aerolinkApiKey").getAsString();
            if (obj.has("anthropicApiKey")) settings.anthropicApiKey = obj.get("anthropicApiKey").getAsString();
            if (obj.has("baseUrl")) settings.baseUrl = obj.get("baseUrl").getAsString();
            if (obj.has("model")) settings.model = obj.get("model").getAsString();
            if (obj.has("systemPrompt")) settings.systemPrompt = obj.get("systemPrompt").getAsString();
            if (obj.has("maxTokens")) settings.maxTokens = obj.get("maxTokens").getAsInt();
            if (obj.has("maxToolIterations")) settings.maxToolIterations = obj.get("maxToolIterations").getAsInt();
            if (obj.has("useAerolink")) settings.useAerolink = obj.get("useAerolink").getAsBoolean();
            if (obj.has("workingDirectory")) settings.workingDirectory = obj.get("workingDirectory").getAsString();
            if (obj.has("savedSystemPrompts")) {
                JsonArray arr = obj.getAsJsonArray("savedSystemPrompts");
                for (JsonElement e : arr) settings.savedSystemPrompts.add(e.getAsString());
            }
        } catch (Exception e) {
            System.err.println("Ayarlar yüklenemedi: " + e.getMessage());
        }
        return settings;
    }

    public void save() {
        try {
            File file = new File(SETTINGS_FILE);
            file.getParentFile().mkdirs();

            JsonObject obj = new JsonObject();
            obj.addProperty("aerolinkApiKey", aerolinkApiKey);
            obj.addProperty("anthropicApiKey", anthropicApiKey);
            obj.addProperty("baseUrl", baseUrl);
            obj.addProperty("model", model);
            obj.addProperty("systemPrompt", systemPrompt);
            obj.addProperty("maxTokens", maxTokens);
            obj.addProperty("maxToolIterations", maxToolIterations);
            obj.addProperty("useAerolink", useAerolink);
            obj.addProperty("workingDirectory", workingDirectory);

            JsonArray arr = new JsonArray();
            for (String p : savedSystemPrompts) arr.add(p);
            obj.add("savedSystemPrompts", arr);

            Files.writeString(file.toPath(), new GsonBuilder().setPrettyPrinting().create().toJson(obj));
        } catch (Exception e) {
            System.err.println("Ayarlar kaydedilemedi: " + e.getMessage());
        }
    }

    public String getEffectiveApiKey() {
        if (useAerolink && !aerolinkApiKey.isBlank()) return aerolinkApiKey;
        return anthropicApiKey;
    }

    public String getEffectiveBaseUrl() {
        if (useAerolink && !aerolinkApiKey.isBlank()) return "https://capi.aerolink.lat";
        return "https://api.anthropic.com";
    }

    // Getters & Setters
    public String getAerolinkApiKey() { return aerolinkApiKey; }
    public void setAerolinkApiKey(String v) { aerolinkApiKey = v; }

    public String getAnthropicApiKey() { return anthropicApiKey; }
    public void setAnthropicApiKey(String v) { anthropicApiKey = v; }

    public String getBaseUrl() { return baseUrl; }
    public void setBaseUrl(String v) { baseUrl = v; }

    public String getModel() { return model; }
    public void setModel(String v) { model = v; }

    public String getSystemPrompt() { return systemPrompt; }
    public void setSystemPrompt(String v) { systemPrompt = v; }

    public List<String> getSavedSystemPrompts() { return savedSystemPrompts; }

    public int getMaxTokens() { return maxTokens; }
    public void setMaxTokens(int v) { maxTokens = v; }

    public int getMaxToolIterations() { return maxToolIterations; }
    public void setMaxToolIterations(int v) { maxToolIterations = v; }

    public boolean isUseAerolink() { return useAerolink; }
    public void setUseAerolink(boolean v) { useAerolink = v; }

    public String getWorkingDirectory() { return workingDirectory; }
    public void setWorkingDirectory(String v) { workingDirectory = v; }

    public boolean hasApiKey() {
        return !getEffectiveApiKey().isBlank();
    }

    public static String getDefaultSystemPrompt() { return DEFAULT_SYSTEM_PROMPT; }
}
