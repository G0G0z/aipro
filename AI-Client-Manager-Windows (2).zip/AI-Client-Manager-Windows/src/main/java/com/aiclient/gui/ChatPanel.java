package com.aiclient.gui;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Chat mesajlarını gösteren kaydırılabilir panel.
 */
public class ChatPanel extends JPanel {

    private final JPanel messagesContainer;
    private final JScrollPane scrollPane;
    private final List<MessageBubble> bubbles = new ArrayList<>();
    private MessageBubble streamingBubble;

    public ChatPanel() {
        setLayout(new BorderLayout());

        messagesContainer = new JPanel();
        messagesContainer.setLayout(new BoxLayout(messagesContainer, BoxLayout.Y_AXIS));
        messagesContainer.setOpaque(false);
        messagesContainer.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        scrollPane = new JScrollPane(messagesContainer,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.setOpaque(false);
        scrollPane.getVerticalScrollBar().setUnitIncrement(20);

        add(scrollPane, BorderLayout.CENTER);

        // Karşılama mesajı
        showWelcome();
    }

    private void showWelcome() {
        ChatMessage welcome = new ChatMessage(ChatMessage.Type.SYSTEM,
            "Merhaba! Ben Claude destekli AI Client Manager.\n\n" +
            "Dosya sistemi işlemleri, komut çalıştırma ve çok daha fazlası için buradayım.\n" +
            "Başlamak için sağ üstteki ⚙ Ayarlar butonuna tıklayarak API anahtarınızı girin.");
        addMessage(welcome);
    }

    public void clearWelcome() {
        messagesContainer.removeAll();
        bubbles.clear();
        streamingBubble = null;
        revalidate();
        repaint();
    }

    public void addMessage(ChatMessage message) {
        MessageBubble bubble = new MessageBubble(message);
        bubbles.add(bubble);

        bubble.setAlignmentX(Component.LEFT_ALIGNMENT);
        messagesContainer.add(bubble);
        messagesContainer.add(Box.createRigidArea(new Dimension(0, 6)));

        revalidate();
        repaint();
        scrollToBottom();
    }

    /**
     * Streaming için: önce boş bir asistan balonu oluştur, sonra metin ekle.
     */
    public MessageBubble startStreamingMessage() {
        ChatMessage msg = new ChatMessage(ChatMessage.Type.ASSISTANT, "");
        streamingBubble = new MessageBubble(msg);
        streamingBubble.setAlignmentX(Component.LEFT_ALIGNMENT);
        messagesContainer.add(streamingBubble);
        messagesContainer.add(Box.createRigidArea(new Dimension(0, 6)));
        bubbles.add(streamingBubble);
        revalidate();
        repaint();
        return streamingBubble;
    }

    public MessageBubble getStreamingBubble() {
        return streamingBubble;
    }

    public void finalizeStreamingMessage() {
        streamingBubble = null;
        revalidate();
        repaint();
        scrollToBottom();
    }

    public void clearMessages() {
        messagesContainer.removeAll();
        bubbles.clear();
        streamingBubble = null;
        revalidate();
        repaint();
    }

    public void scrollToBottom() {
        SwingUtilities.invokeLater(() -> {
            JScrollBar vert = scrollPane.getVerticalScrollBar();
            vert.setValue(vert.getMaximum());
        });
    }
}
