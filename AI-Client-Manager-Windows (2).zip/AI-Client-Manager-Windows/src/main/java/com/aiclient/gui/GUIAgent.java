package com.aiclient.gui;

import com.aiclient.AnthropicClient;
import com.aiclient.tools.Tool;
import com.aiclient.tools.ToolRegistry;
import com.google.gson.*;
import java.util.*;
import java.util.function.Consumer;

/**
 * GUI için uyarlanmış Agent - event callback'leri ile çalışır.
 */
public class GUIAgent {

    private final AnthropicClient client;
    private final ToolRegistry toolRegistry;
    private final List<JsonObject> conversationHistory;
    private String currentModel;
    private String systemPrompt;
    private int maxTokens;
    private int maxToolIterations;
    private int totalInputTokens;
    private int totalOutputTokens;
    private final Gson gson;

    // Callback'ler
    private Consumer<String> onTextChunk;
    private Consumer<String[]> onToolUse;     // [toolName, toolId]
    private Consumer<String[]> onToolResult;  // [toolName, success, result]
    private Runnable onDone;
    private Consumer<String> onError;

    private volatile boolean cancelled = false;

    public GUIAgent(AnthropicClient client, AppSettings settings) {
        this.client = client;
        this.toolRegistry = new ToolRegistry();
        this.conversationHistory = new ArrayList<>();
        this.currentModel = settings.getModel();
        this.systemPrompt = settings.getSystemPrompt();
        this.maxTokens = settings.getMaxTokens();
        this.maxToolIterations = settings.getMaxToolIterations();
        this.gson = new GsonBuilder().create();
    }

    public void setCallbacks(
            Consumer<String> onTextChunk,
            Consumer<String[]> onToolUse,
            Consumer<String[]> onToolResult,
            Runnable onDone,
            Consumer<String> onError) {
        this.onTextChunk = onTextChunk;
        this.onToolUse = onToolUse;
        this.onToolResult = onToolResult;
        this.onDone = onDone;
        this.onError = onError;
    }

    public void cancel() { this.cancelled = true; }
    public void resetCancel() { this.cancelled = false; }

    public void chat(String userMessage) {
        cancelled = false;

        JsonObject userMsg = new JsonObject();
        userMsg.addProperty("role", "user");
        userMsg.addProperty("content", userMessage);
        conversationHistory.add(userMsg);

        try {
            int iterations = 0;
            StringBuilder fullResponse = new StringBuilder();

            while (iterations < maxToolIterations && !cancelled) {
                iterations++;

                AnthropicClient.ApiResponse response = client.sendMessages(
                    currentModel,
                    systemPrompt,
                    conversationHistory,
                    toolRegistry.toApiFormat(),
                    maxTokens
                );

                totalInputTokens += response.usage().inputTokens();
                totalOutputTokens += response.usage().outputTokens();

                JsonObject assistantMsg = new JsonObject();
                assistantMsg.addProperty("role", "assistant");
                assistantMsg.add("content", response.content());
                conversationHistory.add(assistantMsg);

                // Metin bloklarını işle
                for (JsonElement elem : response.content()) {
                    JsonObject block = elem.getAsJsonObject();
                    String type = block.get("type").getAsString();
                    if ("text".equals(type)) {
                        String text = block.get("text").getAsString();
                        if (!text.isBlank()) {
                            fullResponse.append(text);
                            if (onTextChunk != null) onTextChunk.accept(text);
                        }
                    }
                }

                if (!"tool_use".equals(response.stopReason()) || cancelled) {
                    break;
                }

                // Araçları işle
                List<JsonObject> toolResults = new ArrayList<>();
                for (JsonElement elem : response.content()) {
                    JsonObject block = elem.getAsJsonObject();
                    if (!"tool_use".equals(block.get("type").getAsString())) continue;

                    String toolId = block.get("id").getAsString();
                    String toolName = block.get("name").getAsString();
                    JsonObject toolInput = block.has("input") && block.get("input").isJsonObject()
                        ? block.getAsJsonObject("input") : new JsonObject();

                    if (onToolUse != null) onToolUse.accept(new String[]{toolName, toolId});

                    String toolResult;
                    boolean success = true;
                    try {
                        if (cancelled) break;
                        Tool tool = toolRegistry.get(toolName);
                        if (tool == null) {
                            toolResult = "HATA: Bilinmeyen araç: " + toolName;
                            success = false;
                        } else {
                            toolResult = tool.execute(toolInput);
                        }
                    } catch (Exception e) {
                        toolResult = "HATA: " + e.getMessage();
                        success = false;
                    }

                    if (onToolResult != null) onToolResult.accept(new String[]{toolName, String.valueOf(success), toolResult});

                    JsonObject resultContent = new JsonObject();
                    resultContent.addProperty("type", "tool_result");
                    resultContent.addProperty("tool_use_id", toolId);
                    resultContent.addProperty("content", toolResult);
                    toolResults.add(resultContent);
                }

                if (!toolResults.isEmpty() && !cancelled) {
                    JsonObject toolResultMsg = new JsonObject();
                    toolResultMsg.addProperty("role", "user");
                    JsonArray contentArray = new JsonArray();
                    for (JsonObject r : toolResults) contentArray.add(r);
                    toolResultMsg.add("content", contentArray);
                    conversationHistory.add(toolResultMsg);
                }
            }

            if (onDone != null) onDone.run();

        } catch (Exception e) {
            if (onError != null) onError.accept(e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName());
        }
    }

    public void resetHistory() {
        conversationHistory.clear();
        totalInputTokens = 0;
        totalOutputTokens = 0;
    }

    public void loadHistory(List<JsonObject> history) {
        conversationHistory.clear();
        if (history != null) conversationHistory.addAll(history);
    }

    /**
     * Sohbet geçmişini ChatMessage listesinden yeniden oluşturur.
     * Sadece user/assistant türündeki mesajlar API bağlamına eklenir.
     */
    public void rebuildHistoryFromMessages(java.util.List<ChatMessage> messages) {
        conversationHistory.clear();
        totalInputTokens = 0;
        totalOutputTokens = 0;
        for (ChatMessage msg : messages) {
            if (msg.getType() == ChatMessage.Type.USER) {
                JsonObject o = new JsonObject();
                o.addProperty("role", "user");
                o.addProperty("content", msg.getContent() != null ? msg.getContent() : "");
                conversationHistory.add(o);
            } else if (msg.getType() == ChatMessage.Type.ASSISTANT) {
                JsonObject o = new JsonObject();
                o.addProperty("role", "assistant");
                // API'nin beklediği content array formatı
                JsonArray contentArr = new JsonArray();
                JsonObject textBlock = new JsonObject();
                textBlock.addProperty("type", "text");
                textBlock.addProperty("text", msg.getContent() != null ? msg.getContent() : "");
                contentArr.add(textBlock);
                o.add("content", contentArr);
                conversationHistory.add(o);
            }
        }
    }

    public void setModel(String model) { this.currentModel = model; }
    public String getModel() { return currentModel; }

    public void setSystemPrompt(String sp) { this.systemPrompt = sp; }
    public void setMaxTokens(int mt) { this.maxTokens = mt; }
    public void setMaxToolIterations(int mti) { this.maxToolIterations = mti; }

    public int getTotalInputTokens() { return totalInputTokens; }
    public int getTotalOutputTokens() { return totalOutputTokens; }
    public int getTotalTokens() { return totalInputTokens + totalOutputTokens; }
    public int getHistorySize() { return conversationHistory.size(); }

    public AnthropicClient getClient() { return client; }
}
