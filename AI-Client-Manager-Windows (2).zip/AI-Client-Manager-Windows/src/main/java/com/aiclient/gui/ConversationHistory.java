package com.aiclient.gui;

import com.google.gson.*;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Sohbet geçmişini dosyaya kaydeder ve yükler.
 */
public class ConversationHistory {

    private static final String HISTORY_DIR = System.getProperty("user.home") + File.separator
            + ".ai-client-manager" + File.separator + "conversations";

    private String id;
    private String title;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private List<ChatMessage> messages;

    public ConversationHistory() {
        this.id = generateId();
        this.title = "Yeni Sohbet";
        this.createdAt = LocalDateTime.now();
        this.updatedAt = LocalDateTime.now();
        this.messages = new ArrayList<>();
    }

    private static String generateId() {
        return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS"));
    }

    public void addMessage(ChatMessage msg) {
        messages.add(msg);
        updatedAt = LocalDateTime.now();
        // İlk kullanıcı mesajını başlık yap
        if (title.equals("Yeni Sohbet") && msg.getType() == ChatMessage.Type.USER) {
            String content = msg.getContent();
            title = content.length() > 50 ? content.substring(0, 50) + "..." : content;
        }
    }

    public void save() {
        try {
            Files.createDirectories(Path.of(HISTORY_DIR));
            JsonObject obj = new JsonObject();
            obj.addProperty("id", id);
            obj.addProperty("title", title);
            obj.addProperty("createdAt", createdAt.toString());
            obj.addProperty("updatedAt", updatedAt.toString());

            JsonArray msgs = new JsonArray();
            for (ChatMessage m : messages) {
                JsonObject mo = new JsonObject();
                mo.addProperty("type", m.getType().name());
                mo.addProperty("content", m.getContent());
                mo.addProperty("timestamp", m.getTimestamp().toString());
                if (m.getToolName() != null) mo.addProperty("toolName", m.getToolName());
                mo.addProperty("toolSuccess", m.isToolSuccess());
                msgs.add(mo);
            }
            obj.add("messages", msgs);

            String json = new GsonBuilder().setPrettyPrinting().create().toJson(obj);
            Files.writeString(Path.of(HISTORY_DIR, id + ".json"), json);
        } catch (Exception e) {
            System.err.println("Geçmiş kaydedilemedi: " + e.getMessage());
        }
    }

    public static List<ConversationHistory> loadAll() {
        List<ConversationHistory> list = new ArrayList<>();
        try {
            Path dir = Path.of(HISTORY_DIR);
            if (!Files.exists(dir)) return list;
            try (var stream = Files.list(dir)) {
                stream.filter(p -> p.toString().endsWith(".json"))
                      .sorted(Comparator.reverseOrder())
                      .forEach(p -> {
                          ConversationHistory h = loadFromFile(p);
                          if (h != null) list.add(h);
                      });
            }
        } catch (Exception e) {
            System.err.println("Geçmiş yüklenemedi: " + e.getMessage());
        }
        return list;
    }

    private static ConversationHistory loadFromFile(Path path) {
        try {
            String json = Files.readString(path);
            JsonObject obj = JsonParser.parseString(json).getAsJsonObject();
            ConversationHistory h = new ConversationHistory();
            h.id = obj.get("id").getAsString();
            h.title = obj.get("title").getAsString();
            h.createdAt = LocalDateTime.parse(obj.get("createdAt").getAsString());
            h.updatedAt = LocalDateTime.parse(obj.get("updatedAt").getAsString());
            h.messages = new ArrayList<>();

            JsonArray msgs = obj.getAsJsonArray("messages");
            for (JsonElement e : msgs) {
                JsonObject mo = e.getAsJsonObject();
                ChatMessage.Type type = ChatMessage.Type.valueOf(mo.get("type").getAsString());
                String content = mo.get("content").getAsString();
                String toolName = mo.has("toolName") ? mo.get("toolName").getAsString() : null;
                boolean toolSuccess = mo.has("toolSuccess") && mo.get("toolSuccess").getAsBoolean();
                ChatMessage msg = new ChatMessage(type, content, toolName, toolSuccess);
                h.messages.add(msg);
            }
            return h;
        } catch (Exception e) {
            return null;
        }
    }

    public void delete() {
        try {
            Files.deleteIfExists(Path.of(HISTORY_DIR, id + ".json"));
        } catch (Exception ignored) {}
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }
    public LocalDateTime getCreatedAt() { return createdAt; }
    public LocalDateTime getUpdatedAt() { return updatedAt; }
    public List<ChatMessage> getMessages() { return messages; }
    public void clearMessages() { messages.clear(); }

    @Override
    public String toString() { return title; }
}
