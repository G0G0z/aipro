package com.aiclient;

import com.aiclient.gui.MainWindow;
import com.formdev.flatlaf.FlatDarkLaf;

import javax.swing.*;

public class GuiMain {

    public static void main(String[] args) {
        // Sistem özelliklerini ayarla (HiDPI vb.)
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        System.setProperty("sun.java2d.uiScale.enabled", "true");

        // Uygulamayı EDT'de başlat
        SwingUtilities.invokeLater(() -> {
            try {
                // FlatLaf Dark teması
                FlatDarkLaf.setup();
                // Ek UI ince ayarları
                UIManager.put("Button.arc", 8);
                UIManager.put("Component.arc", 8);
                UIManager.put("TextComponent.arc", 8);
                UIManager.put("ScrollBar.thumbArc", 999);
                UIManager.put("ScrollBar.thumbInsets", new java.awt.Insets(2, 2, 2, 2));
                UIManager.put("TabbedPane.tabSeparatorsFullHeight", true);
                UIManager.put("TabbedPane.showTabSeparators", true);
            } catch (Exception e) {
                // FlatLaf yüklenemezse varsayılan temaya geri dön
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception ignored) {}
            }

            MainWindow window = new MainWindow();
            window.setVisible(true);
        });
    }
}
