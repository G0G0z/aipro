@echo off
chcp 65001 >nul
echo.
echo ╔══════════════════════════════════════════╗
echo ║      AI Client Manager - Build Script    ║
echo ╚══════════════════════════════════════════╝
echo.

:: Java kontrolü
java -version >nul 2>&1
if errorlevel 1 (
    echo [HATA] Java bulunamadı!
    echo Java 17+ sürümünü indirin: https://adoptium.net/
    pause
    exit /b 1
)

:: Maven kontrolü
mvn -version >nul 2>&1
if errorlevel 1 (
    echo [HATA] Maven bulunamadı!
    echo Maven'ı indirin: https://maven.apache.org/download.cgi
    echo Veya JAVA_HOME/bin klasörüne ekleyin.
    pause
    exit /b 1
)

echo [1/2] Proje derleniyor (Maven)...
mvn clean package -q
if errorlevel 1 (
    echo [HATA] Derleme başarısız!
    mvn clean package
    pause
    exit /b 1
)

echo [2/2] Derleme başarılı!
echo.
echo JAR dosyası: target\ai-client-manager.jar
echo.
echo Çalıştırmak için: run.bat
echo.
pause
