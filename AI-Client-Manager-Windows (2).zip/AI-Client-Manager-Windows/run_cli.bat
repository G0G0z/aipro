@echo off
chcp 65001 >nul
echo.
echo ╔══════════════════════════════════════════╗
echo ║   AI Client Manager - Terminal Modu      ║
echo ╚══════════════════════════════════════════╝
echo.

if "%AEROLINK_API_KEY%"=="" (
    if "%ANTHROPIC_API_KEY%"=="" (
        echo [HATA] API anahtarı bulunamadı!
        echo Lütfen aşağıdakilerden birini ayarlayın:
        echo   set AEROLINK_API_KEY=aero_live_...
        echo   set ANTHROPIC_API_KEY=sk-ant-...
        pause
        exit /b 1
    )
)

java ^
  -Dfile.encoding=UTF-8 ^
  -cp target\ai-client-manager.jar ^
  com.aiclient.Main

pause
