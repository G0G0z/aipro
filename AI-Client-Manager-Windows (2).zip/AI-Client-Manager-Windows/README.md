# AI Client Manager v2.0

Modern Java masaüstü uygulaması — Claude destekli tam yetkili AI istemcisi.

## Windows'ta Çalıştırma

### 1. Java Kur (zorunlu)
Java 17+ indir ve kur: https://adoptium.net/
(Temurin JDK 17 veya üzeri)

### 2. Uygulamayı Başlat
`run.bat` dosyasına çift tıkla.

### 3. API Anahtarı Gir
Uygulama açıldıktan sonra **⚙ Ayarlar** butonuna tıkla:
- **Aerolink** için: `aero_live_...` formatında anahtar
- **Anthropic** için: `sk-ant-...` formatında anahtar

---

## Özellikler

| Özellik | Açıklama |
|---------|---------|
| 🎨 Modern koyu arayüz | FlatLaf Dark teması |
| 🤖 Çoklu AI modeli | Claude claude-sonnet-4-6, claude-opus-4-5, GPT-4o vb. |
| 🔑 Çift API desteği | Aerolink + Anthropic |
| 💾 Sohbet geçmişi | Otomatik kaydedilir |
| 📁 Dosya sistemi | Oku, yaz, düzenle, sil |
| ⚡ Komut çalıştırma | Windows cmd / Linux bash |
| 🔍 Dosya arama | İçerik ve ad ile arama |
| 📂 Dizin yönetimi | Listele, oluştur, taşı |

## AI Araçları (Tools)

Claude aşağıdaki araçları otomatik kullanır:

- `read_file` — Dosya içeriği oku
- `write_file` — Dosya yaz / oluştur
- `edit_file` — Dosya satır/metin düzenle
- `delete_file` — Dosyayı sil
- `list_directory` — Klasör içeriğini listele
- `search_files` — Dosyalarda metin ara
- `execute_command` — Komut çalıştır (Windows: cmd, Linux: bash)
- `make_directory` — Klasör oluştur
- `move_file` — Dosya taşı / yeniden adlandır
- `file_info` — Dosya bilgisi görüntüle

## Klavye Kısayolları

| Tuş | Eylem |
|-----|-------|
| `Enter` | Mesaj gönder |
| `Shift + Enter` | Yeni satır |
| `Ctrl + N` | Yeni sohbet |
| `Ctrl + S` | Sohbeti kaydet |
| `Ctrl + Q` | Çıkış |
| `F5` | Geçmişi yenile |
| Sağ tık | Mesajı kopyala |

## Dosya Konumları

- **Ayarlar:** `%USERPROFILE%\.ai-client-manager\settings.json`
- **Sohbet geçmişi:** `%USERPROFILE%\.ai-client-manager\conversations\`

## Terminal Modunda Çalıştırma

```bat
set AEROLINK_API_KEY=aero_live_...
run_cli.bat
```

## Kaynaktan Derleme

```bat
:: Maven ve Java 17+ gerekli
build.bat
```

---

*Java AI Client Manager — Aerolink & Anthropic API desteği ile*
